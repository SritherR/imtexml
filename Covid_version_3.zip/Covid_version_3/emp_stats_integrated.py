"""   Loading Processed employee data to database"""
'''
from utils import (
    yaml,
    MssqlDBUtil,
    pd,
    np,
    LOG,
    emp_bu_comp_list,    
    conf_file)
'''   

import re
import os, os.path
import sys
import csv
import yaml
import time
import shutil
import traceback
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
from collections import OrderedDict
from logger import LOG
from db import MssqlDBUtil
from datetime import datetime
import warnings
import pdb
import glob


# from common_headers import *
warnings.filterwarnings("ignore")

class CountResponse:
    """
       Calculating count of response for each employee
    """
    def __init__(self, conf_file):
        self.conf_file = conf_file
        try:
            with open(conf_file, 'r') as conf_yaml:
                config_detail = yaml.safe_load(conf_yaml)
                self.hr_table = config_detail.get("tables").get("hr_table")
                self.emp_table = config_detail.get("tables").get("emp_table")
                self.last_date = config_detail.get("tables").get("last_ts")
                self.hr_query = """ select * from %s  """ % self.hr_table
                #self.emp_query = """ SELECT * FROM %s """ % self.emp_table
                #self.last_process_date = """ select * from %s """ % self.last_ts
                #self.last_ts= config_detail.get("tables").get("last_ts")
                # self.emp_query = """ (SELECT * FROM %s WHERE
                                    # submitDateTime >= '2021-06-28 00:00:00' and submitDateTime <'2021-07-05 00:00:00'
                                    # )   """ % self.emp_table
                self.emp_query = """SELECT a.* FROM %s a,
                %s b WHERE a.submitDate >= b.last_processed_date and a.submitDate <= (DATEADD(DAY,
                6, b.last_processed_date))""" % (self.emp_table, self.last_date)

        except Exception as e:
            LOG.error("Cannot open config file. The error is \n : %s", str(e))
    
    def update_last_date(self):
        try:
            with MssqlDBUtil(self.conf_file) as mysql_utils:
                conn = mysql_utils.connection
                conn.execute(self.update_last_date)
                LOG.info("Sucessfully written to db")
        except Exception as e:
            LOG.error("Writing last timestamp to mssql is failed. The error is \n : %s", str(e))

            
    def call_emp_stats(self):
        """       Calling below functions for emp_data_loader         """

        LOG.info("EMP STATS has started!")
        #processed_df = self.processing()
        sheet1,hr_list,processed_df,onboard_df,badge_date_df = self.processing()
        LOG.info("Input Data shape is: %s", processed_df.shape)
        LOG.info("Input Data shape is: %s", onboard_df.shape)
        #return processed_df
        return sheet1,hr_list,processed_df,onboard_df,badge_date_df
       
    def read_data(self):
        """
           Loads Data from Database based on input params provided
        """

        df_emp = pd.DataFrame()        
        try:
            with MssqlDBUtil(self.conf_file) as mysql_utils:
                conn = mysql_utils.connection
                df_hr= pd.read_sql(self.hr_query, conn)
                LOG.info("HR_data shape is: %s", df_hr.shape)
                df_hr.rename(columns={'EmployeeID': 'employ_id','EmployeeName': 'legal_name','BU': 'bu','ManagerID': 'manager_id','ManagerName': 'manager_name',
                        'Building':'Location'},inplace=True)
                df_hr.drop(['EmployeeStatus', 'PlanHiredate','Remark','Created','Modified'], axis=1, inplace=True)                     
                ip_df = pd.read_sql(self.emp_query, conn)
                if len(ip_df) != 0:
                    df_emp = ip_df
                else:
                    LOG.warning("No Employee data found from database!")

                conn.close()
                
                LOG.info("EMP_data shape is: %s", df_emp.shape)
                LOG.info("HR_data shape is: %s", df_hr.shape)
                
                df_emp["start_time"]=df_emp["submitDateTime"]
                df_emp.rename(columns={df_emp.columns[0]: "id",
                            df_emp.columns[1]: 'employ_id',
                            df_emp.columns[2]: 'employ_name',
                            df_emp.columns[3]: 'manager_email',
                            df_emp.columns[4]: 'temperature',
                            df_emp.columns[5]: 'symptoms',
                            df_emp.columns[6]: 'completion_time',
                            df_emp.columns[7]: 'date'
                            }, inplace=True)
                cols = ['id','start_time','completion_time','employ_name','employ_id','temperature','symptoms','manager_email','date']
                df_emp=df_emp[cols]
                LOG.info("HR data & Emp data reading from db is successfully completed!")
                return df_emp,df_hr
        except Exception as e:
            LOG.error("Connect to Maria db is failed. "
                      "The error is \n : %s", str(e))
    '''
    def read_data(self):
        """    Loads the hr_data from database and returns the same       """
        try:
            with MssqlDBUtil(self.conf_file) as mysql_utils:
                conn = mysql_utils.connection
                df_hr = pd.read_sql(self.hr_query, conn)
                df_emp= pd.read_sql(self.emp_query,conn)
                LOG.info("EMP_data shape is: %s", df_emp.shape)
                LOG.info("HR_data shape is: %s", df_hr.shape)
                
                df_emp["start_time"]=df_emp["submitDateTime"]
                df_emp.rename(columns={df_emp.columns[0]: "id",
                            df_emp.columns[1]: 'employ_id',
                            df_emp.columns[2]: 'employ_name',
                            df_emp.columns[3]: 'manager_email',
                            df_emp.columns[4]: 'temperature',
                            df_emp.columns[5]: 'symptoms',
                            df_emp.columns[6]: 'completion_time',
                            df_emp.columns[7]: 'date'
                            }, inplace=True)
                cols = ['id','start_time','completion_time','employ_name','employ_id','temperature','symptoms','manager_email','date']
                df_emp=df_emp[cols]
                

                LOG.info("HR data & Emp data reading from db is successfully completed!")
                return df_emp,df_hr

        except Exception as e:
            LOG.error("Connect to mariadb is failed. The error is \n : %s", str(e))
        finally:
            LOG.info("Data extraction completetd!")
    '''

    def exchange_val(self, row):
        """
           Swapping employee id values with employee name  when
           vice-versa values are given
        """
        try:
            row = row
            emp_name = row['employ_name']
            emp_id = row['employ_id']
            if len(emp_id) < 9 and (emp_id.isalpha()) is False:
                return row['employ_id']
            elif re.search("[eE|xX|0-9][0-9]+\\b]", emp_name):
                return emp_name
            else:
                return row['employ_id']
        except Exception as e:
            LOG.error("Error exchanging employ id and employ name")
            LOG.error("The error is \n : {0}".format(e))
            
            
                
    def get_sample_amsea(self):
        shared_folder = r"E:\Covid19\Amsea_security_weekly_report"
       
        listf = glob.glob(r"E:\Covid19\Amsea_security_weekly_report\*")
        file = max(listf,key=os.path.getctime)
        try:
            if file.endswith(".xlsx") or file.endswith(".xls") or file.endswith(".csv"):  ## date part in file name
                xl_file = os.path.join(shared_folder,file)
                sample_amsea = pd.ExcelFile(xl_file)
              
                sample_amsea_df = sample_amsea.parse("Sheet1", header=None, names=['employ_id', 'employ_name', 'some_id','date_time','blank_col','location'])
                #sample_amsea_df = sample_amsea_df[sample_amsea_df['employ_id'].notna()]
                sample_amsea_df=sample_amsea_df.fillna(method="ffill")
                sample_amsea_employid = sample_amsea_df.copy()
                sample_amsea_employid['date_time'] = pd.to_datetime(sample_amsea_employid['date_time']).dt.date
                df1=sample_amsea_employid["employ_id"].str.isalpha()
                df1=df1.fillna(False)
                sample_amsea_employid=sample_amsea_employid[~df1]
                return sample_amsea_employid
                
        except:
            LOG.error("Error while reading badge file")
            
    def check_employee(self, row):
        """
            Removing alphabets and zeroes beside alphabets for  employee id's
            if employee id starts with alphabets
        """
        try:
            val = None
            if row.isnumeric():
                val = row
            elif len(row) <= 2:
                val = 'NC1'
            elif row[0] == 'X' or row[0] == 'x':
                if row[1] == '0' and row[2:].isnumeric():
                    row = 'X0' + row[2:]
                    val = row
                else:
                    # val = 'id_defaulter'
                    val = row

            elif (row[0] == 'C' or row[0] == 'c') and row[1:].isnumeric():
                row = 'C' + row[1:]
                val = row

            elif (row[0] == 'E' or row[0] == 'e') and row[1:].isnumeric():
                row = row[1:]
                val = row

            else:
                # val = 'id_defaulter'
                val = row
            return val
        except Exception as e:
            val = row
            LOG.error("Incorrect employ id entered is %s", row)
            LOG.error("The error is \n : %s", e)
            
            

    def processing(self):
        """   Processing to get the count of response for each Employee  """
        try:
            LOG.info("Emp_stats data processing has started!")        
            sheet1, hr_list = self.read_data()
           
            
            def new_merge(data1,data2):
              
                final_sheet = data1[['emp_id', 'date']]
                df_date = final_sheet['date'].unique()
                df_cnt = final_sheet.groupby(['date', 'emp_id']).size().reset_index()
                df_cnt.rename(columns={0: 'cnt_response'}, inplace=True)
                df_cnt_merge = pd.merge(final_sheet, df_cnt, on=['emp_id', 'date'], how='inner')
               
                df_cnt_merge.to_csv(r"D:\Covid_version_3\df_cnt_merge.csv")
                df_drop_dup = df_cnt_merge.drop_duplicates(subset=['emp_id', 'date'])
                merge_df = pd.DataFrame()
                for date in df_date:
                    df_add = pd.merge(data2[['employ_id', 'employ_id_new', 'legal_name', 'bu',\
                                               'manager_id', 'manager_name', 'Location']],\
                                                df_drop_dup[df_drop_dup['date'] == date],\
                                                left_on='employ_id_new', right_on='emp_id', how='left')
                    df_add['date'] = date
                    df_add['cnt_response'] = df_add['cnt_response'].fillna(0)
                    merge_df = merge_df.append(df_add, ignore_index=True)
                merge_df.loc[merge_df['cnt_response'] >= 2, 'count_label'] = 2
                merge_df.loc[merge_df['cnt_response'] < 2, 'count_label'] = merge_df['cnt_response']
                merge_df.rename(columns={'legal_name': 'employ_name'}, inplace=True)
                return merge_df
                
            sample_amsea_employid = self.get_sample_amsea()  ## edited line ======
            sample_amsea_employid['employ_id'] = sample_amsea_employid['employ_id'].astype(str)
            sample_amsea_employid['employ_id'] = sample_amsea_employid['employ_id'].str.lower()
            sample_amsea_employid['employ_id'] = sample_amsea_employid['employ_id'].apply(lambda x: re.sub('O|o', '0', x))
            sample_amsea_employid['employ_id'] = sample_amsea_employid['employ_id'].apply(lambda x: x.strip())
            sample_amsea_employid['employ_id'] = sample_amsea_employid['employ_id'].apply(
                lambda x: x.encode('ascii', 'ignore').decode("utf-8"))

            badge_date_df = sample_amsea_employid.copy()
            LOG.info("Total count of Employee is: %s", sheet1.shape)
            LOG.info("Total count of HR is: %s", hr_list.shape)
            sheet1['employ_name'] = sheet1['employ_name']. \
                str.replace(r'[^\x00-\x7F]+', '')
            sheet1['employ_id'] = sheet1['employ_id']. \
                str.replace(r'[^\x00-\x7F]+', '')
            if len(sheet1) != 0 and len(hr_list) != 0:
                sheet1['employ_id'] = sheet1['employ_id'].apply(lambda x: str(x).replace(" ", ""))
                sheet1['employ_id'] = sheet1['employ_id'].apply(lambda x: re.sub('O|o', '0', x))
                sheet1['employ_id'] = sheet1['employ_id'].apply(lambda x: x.strip())
                sheet1['employ_id'] = sheet1['employ_id'].apply(
                    lambda x: x.encode('ascii', 'ignore').decode("utf-8"))
            
                sheet1['employ_name'] = sheet1['employ_name'].apply(lambda x: str(x).strip())
                sheet1['employ_name'] = sheet1['employ_name'].apply(lambda x: x.replace(',', ""))
            
                sheet1['employ_id'] = sheet1.apply(self.exchange_val, axis=1)
                sheet1['emp_id'] = sheet1['employ_id'].apply(self.check_employee)
                #sheet1['date'] = sheet1['completion_time'].dt.date
              
                try:
                    sheet1['emp_id'] = sheet1['emp_id'].apply(lambda row: re.sub("[^0-9]", "", row))
                    hr_list['employ_id_new'] = hr_list['employ_id'].astype(str).\
                                               apply(lambda row: re.sub("[^0-9]", "", row))
                    #join between security and hr 
                    sample_amsea_employid["employ_id_new"] = sample_amsea_employid['employ_id'].astype(str).\
                                   apply(lambda row: re.sub("[^0-9]", "", row))
                   
                    sample_amsea_employid.drop_duplicates(["employ_id"],keep="first",inplace=True)
                    new_merge_report = pd.merge(sample_amsea_employid[["employ_id","employ_id_new"]],hr_list[hr_list.columns[1::]],left_on="employ_id_new",right_on='employ_id_new',how='left')
               
                    new_merge_report.rename(columns={"employ_id_new_x":"employ_id_new"},inplace=True)
                    try:
                        new_merge_report.drop("employ_id_new_y",axis=1,inplace=True)
                    except:
                        pass
                   
                except Exception as e:
                    LOG.warning(e)
                    sheet1['emp_id'] = sheet1['emp_id']
                    hr_list['employ_id_new'] = hr_list['employ_id_new'] 
                    sample_amsea_employid["employ_id_new"] = sample_amsea_employid["employ_id_new"]
                    
                badge_merge = new_merge(sheet1,new_merge_report)  
                merge_df = new_merge(sheet1,hr_list)  #
                LOG.info("Shape of the data to be inserted in emp_stats table in db: %s", \
                                                                        merge_df.shape)
                LOG.info("Shape of the data to be inserted in emp_stats table in db: %s", \
                                                                        badge_merge.shape)                                                            
                LOG.info("Emp_stats data processing is completed!")
                return merge_df,badge_merge
            else:
                LOG.warning("WARNING : No Emp/Hr data found in database!")
        except Exception as e:
            LOG.error("The error is \n : %s", e)        
        finally:    
            return sheet1, hr_list, merge_df,badge_merge,badge_date_df

'''
if __name__ == "__main__":
    #conf_file = "conf/db_conf.yaml"
    stats_obj= CountResponse(conf_file)
    print("Process started")
    process_df=stats_obj.processing()
'''

