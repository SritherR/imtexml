# coding: utf-8

from ._log import AMATLogger

log_path = r'D:\Covid_version_3\covid_logs'
#log_path = r'D:\Covid_TRS_deployed\covid_logs'
#LOG = AMATLogger.get_logger(logpath=log_path, filename='covid_report')
LOG = AMATLogger.get_rotating_logger(logpath=log_path, filename='covid_report', interval=1)

__doc__ = """Defines configuration and formatting to produce a homogeneous 
log for the application."""
__author__ = ['Tarun Verma']
__version__ = 2.0
