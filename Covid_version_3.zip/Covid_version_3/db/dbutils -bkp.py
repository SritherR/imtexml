#!/usr/bin/env python
"""Module for working with Databases.
As of now MySQL utilities are dfined for the learning rate
"""

import os
import sys
import yaml
from sqlalchemy import create_engine
import pandas as pd

CURRENT_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.append(os.path.dirname(CURRENT_DIR))

class MariaDBUtil:
    """Utilities for working with MySQL"""

    def __init__(self, config_file):
        with open(config_file, 'r') as conf_yaml:
            conf_details = yaml.load(conf_yaml)
            self.host = conf_details.get("mysql").get("host")
            self.port = conf_details.get("mysql").get("port")
            self.user = conf_details.get("mysql").get("user")
            self.password = conf_details.get("mysql").get("passwd")
            self.data_base = conf_details.get("mysql").get("db")
            #self.log_path = conf_details.get("loggging").get("general_log")
            #self.sensor_list = conf_details.get("rs_tables").get("sensor_list")

        self.connection = None
        self.engine = None
        #self.log_class = AMATLogger()
        #self.log = self.log_class.get_log(self.log_path, "MySQl")

    def __enter__(self):
        self.engine = create_engine("mysql+pymysql://{0}:{1}@{2}:{3}/{4}".format(self.user,
                                                                             self.password,
                                                                             self.host,
                                                                             self.port,
                                                                             self.data_base))

        self.connection = self.engine.connect()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.connection.close()

if __name__ == "__main__":
    config_file = "../conf/db_conf.yaml"
    with MariaDBUtil(config_file) as mysql_utils:
        mysql_conn = mysql_utils.connection

class PgSQLUtil:
    """Utilities for working with MySQL"""

    def __init__(self, config_file):
        print("the config file passed is",config_file)
        with open(config_file, 'r') as conf_yaml:
            conf_details = yaml.safe_load(conf_yaml)
            self.host = conf_details.get("db_test").get("host")
            #self.port = conf_details.get("postgresql").get("port")
            self.user = conf_details.get("db_test").get("user")
            self.password = conf_details.get("db_test").get("password")
            self.data_base = conf_details.get("db_test").get("database")


        self.connection = None
        self.engine = None

    def __enter__(self):
        self.engine = create_engine("postgresql+psycopg2://{0}:{1}@{2}:5432/{3}".format(self.user,
                                                                                        self.password,
                                                                                        self.host,
                                                                                        self.data_base))


        self.connection = self.engine.connect()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.connection.close()


if __name__ == "__main__":
    with PgSQLUtil("../conf/db_conf.yaml") as pgsql_utils:
        pgsql_conn = pgsql_utils.connection
