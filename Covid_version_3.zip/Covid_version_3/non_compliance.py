# -*- coding: utf-8 -*-
"""
Created on Thu Oct  8 15:30:27 2020

@author: 166615a
"""
"""
For Generating Emp/BU Label compliance Report
"""
import re
import os, os.path
import sys
import csv
import yaml
import time
import shutil
import traceback
import pandas as pd
import numpy as np
import pdb
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from datetime import datetime, timedelta
from collections import OrderedDict
from logger import LOG
from db import MssqlDBUtil
from datetime import datetime
#from conf import conf_file
import warnings
from emp_stats_integrated import CountResponse
from get_reports import manual_report_generate
from quarter_report import QuarterReport



class NonCompliance:

    def __init__(self,conf_file):
        self.conf_file = conf_file
        
        try:
            with open(conf_file, 'r') as conf_yaml:
                config_detail = yaml.load(conf_yaml)
                self.start_date = config_detail.get("start_date")
                global get_report_start_date
                get_report_start_date = self.start_date
                self.end_date = config_detail.get("end_date")
                global get_report_end_date
                get_report_end_date = self.end_date
                self.quarter_dict = config_detail.get('quarter_info')
                self.quarter_end= config_detail.get("quarter_end")
                self.quarter_start_date = config_detail.get("quarter_start_date")
                self.cur_qtr_no_comp_table = config_detail.get("tables").get("cur_qtr_no_comp")
                self.hist_no_comp_table = config_detail.get("tables").get("hist_no_comp")
                self.cur_qtr_query = """ SELECT * FROM %s """ % self.cur_qtr_no_comp_table
                LOG.info("Sucessfully read config file")
        except Exception as e:
            LOG.error("Cannot open config file. The error is \n : %s", str(e))

    """
    Generate Non-compliance data weekly
    """

    def load_data(self,conf_file):
        """
           Loads Data from Database based on input params provided
        """
        try:
            date_df = pd.DataFrame()
            stats_obj=CountResponse(self.conf_file)
            sheet1,hr_list,date_df,badge_df,badge_date_df= stats_obj.call_emp_stats()
            LOG.info("Data reading from db is successfully completed:"
                         " %s", date_df.shape)                          
            return sheet1,hr_list,date_df,badge_df,badge_date_df
        except Exception as e:
            LOG.error("No Employee data found from database!. "
                      "The error is \n : %s", str(e))

    def read_data(self):
        """    Loads the current quarter no commpliance data from database and returns the same       """
        self.table_df = pd.DataFrame()
        try:
            with MssqlDBUtil(self.conf_file) as mysql_utils:
                conn = mysql_utils.connection
                self.table_df = pd.read_sql(self.cur_qtr_query, conn)
                LOG.info("cur_qtr_no_comp shape is: %s", self.table_df.shape)
        except Exception as e:
            LOG.error("Connect to mssql is failed. The error is \n : %s", str(e))
        finally:
            LOG.info("Data extraction completetd!")

    def write_data(self,df,table_name):
        """    write table to db       """
        try:
            with MssqlDBUtil(self.conf_file) as mysql_utils:
                conn = mysql_utils.connection
                df.to_sql(table_name, conn, if_exists='append',index=False)
                LOG.info("Sucessfully written to db")
        except Exception as e:
            LOG.error("Writing to mssql is failed. The error is \n : %s", str(e))

    def truncate_table(self):
        try:
            with MssqlDBUtil(self.conf_file) as mysql_utils:
                conn = mysql_utils.connection
                conn.execute(" DELETE from S_current_qtr_no_compliance")
                #conn.execute('TRUNCATE TABLE dbo.S_current_qtr_no_compliance')
                conn.close()
                LOG.info("Sucessfully truncated table")
        except Exception as e:
            LOG.error("Truncation failed. The error is \n : %s", str(e))
            
            
    def get_sample_amsea(self):
        shared_folder = r"E:\Covid19\Amsea_security_weekly_report"
        file_list = os.listdir(shared_folder)
       
        for file in file_list:
            if file.endswith(".xls"):
                xl_file = os.path.join(shared_folder,file)
                sample_amsea = pd.ExcelFile(xl_file)
                sample_amsea_df = sample_amsea.parse("Sheet1", header=None, names=['A', 'B', 'C','D','E','F'])
                sample_amsea_employid = sample_amsea_df[sample_amsea_df['A'].notna()]
                sample_amsea_employid['D'] = pd.to_datetime(sample_amsea_employid['D']).dt.date
              
                
            return sample_amsea_employid        
        
                
                

    def report_process(self,conf_file):
        """ Processing the data to get common input dataframe (total_grouping)
        for report_1() and report_2()

                Parameters
                ----------
                op_table : table
                    Filtered employee table based on user selected start_date,end_date & bu from GUI

                Returns
                -------
                ret : dataframe
                    DataFrame containing common input to report_1() and report_2()
                status : bool
                    True if dataframe is generated else False
        """
        status = False
        ret = ''
        sheet1,hr_list,df,badge_df,badge_date_df = self.load_data(self.conf_file)
        global sheet_1
        sheet_1 = sheet1
        global hrlist
        hrlist = hr_list
        pdb.set_trace()
        #new_merge_report = pd.merge(badge_date_df[["employ_id"]],hr_list[hr_list.columns[1::]],left_on="employ_id",right_on='employ_id_new',how='left')
        #new_merge_report.drop_duplicates(["employ_id"],keep="first",inplace=True)
        pdb.set_trace()
        #print("count new merge report",new_merge_report.shape,"count of hrlist",hr_list.shape,"count of security list",badge_date_df.shape)
       
        #get_report_badge = new_merge_report
        
        if len(badge_df) != 0:
            repo_df = pd.DataFrame()
            repo_df1 = repo_df
            repo_df['employ_id'] = badge_df['employ_id']
            repo_df['date'] = badge_df['date'].astype(str)
            repo_df['count_label'] = badge_df['count_label']
            repo_df2 = repo_df.drop_duplicates(['date', 'employ_id'], keep='first')
            repo_df3 = repo_df2.pivot(index='employ_id', columns='date',
                                      values='count_label').reset_index()
            repo_df1['employ_id'] = badge_df['employ_id'].fillna("")
            repo_df1['employ_name'] = badge_df['employ_name'].fillna("")
            repo_df1['manager_name'] = badge_df['manager_name'].fillna("")
            repo_df1['manager_id'] = badge_df['manager_id'].fillna("")
            repo_df1['Location'] = badge_df['Location'].fillna("")
            repo_df1['bu'] = badge_df['bu'].fillna("")
            repo_df1['manager_name'] = badge_df['manager_name'].fillna("")
            repo_df1 = repo_df1.drop_duplicates('employ_id', keep='first')
            # Merging employee's date columns count responses dataframe &
            # employee's metadata dataframe with employ_id column
            repo_merge1 = pd.merge(repo_df1, repo_df3, how='left', on='employ_id')
            repo_merge1.fillna(0, inplace=True)
            repo_merge1.drop(['date'], axis=1, inplace=True)
            repo_merge1.drop(['count_label'], axis=1, inplace=True)
            repo_merge1.iloc[:, 6:] = repo_merge1.iloc[:, 6:].astype(int)
            repo_merge1['total'] = repo_merge1.iloc[:, 6:].sum(axis=1)
            date_cols = repo_merge1.iloc[:,6:-1].columns
            date_cnt = repo_merge1.iloc[:, 6:-1].count(axis=1).values[0]
            repo_merge1.fillna(0, inplace=True)
            repo_merge1["employ_id"]=repo_merge1["employ_id"].str.lower()
            
            repo_merge1["employ_id"] = repo_merge1["employ_id"]. \
                str.replace(r'[^\x00-\x7F]+', '')
                
            repo_merge1["employ_id"] = repo_merge1["employ_id"].apply(lambda x: str(x).replace(" ", ""))
            repo_merge1["employ_id"] = repo_merge1["employ_id"].apply(lambda x: re.sub('O|o', '0', x))
            repo_merge1["employ_id"] = repo_merge1["employ_id"].apply(lambda x: x.strip())
            repo_merge1["employ_id"] = repo_merge1["employ_id"].apply(
                lambda x: x.encode('ascii', 'ignore').decode("utf-8"))
            global days_present
            days_present =[]
            pdb.set_trace()
            compliance=[]
            #=======================================================================days_entered==========================================
            def days_entered(date1_cnt,date2_cnt,date3_cnt,date4_cnt,date5_cnt,date6_cnt,date7_cnt):
               
                flag=0
                
                days_count =0 
                days_present= [date1_cnt, date2_cnt,date3_cnt,date4_cnt,date5_cnt,date6_cnt,date7_cnt]
                
                
                while '' in days_present:
                    days_present.remove('')    
                
                if sum(days_present)==0:
                    flag = 1
                    days_count = len(days_present)
                else:
                    for i in days_present:
                        if i==2:
                            days_count+=1
                        
                        if i==1 or i==0:
                            flag=1
                            days_count+=1
                            
                compliance.append("No Compliance" if flag==1 else "Full Compliance")
             
                return days_count
            #=======================================================================================================================================
           
            badge_date_df = badge_date_df[["employ_id","date_time"]]
            badge_date_df.drop_duplicates(inplace=True)
            employid=list(set(badge_date_df['employ_id']))
            el_cnt=0
            not_matched=list()
            new_repo_merge1=pd.DataFrame()
            for i in employid:
                df_date=badge_date_df.loc[badge_date_df["employ_id"]==i,"date_time"].values
                df_date=list(df_date)
                
                d=repo_merge1[repo_merge1["employ_id"]==str(i)]
                if not d.empty:
                    date_t=[]
                    for date_for in df_date:
                        try:
                            timestampStr = date_for.strftime("%Y-%b-%d") 
                            t= pd.to_datetime(str(date_for)) 
                            timestring = t.strftime('%Y-%m-%d')
                            date_t.append(timestring)
                        except:
                            pass
                   
                    for k in date_cols:
                        if k in date_t:
                            d[k]=d[k]
                        else:
                            d[k]=""
                            
                    d["total"]=d.iloc[:,6:-1].sum(axis=1)
                  
                    d['Days Entered']= d.apply(lambda row : days_entered(row[date_cols[0]],row[date_cols[1]],row[date_cols[2]],row[date_cols[3]],row[date_cols[4]],
                                row[date_cols[5]], row[date_cols[6]]), axis = 1)
                    new_repo_merge1=new_repo_merge1.append(d)
                else:
                    not_matched.append(i)
                    el_cnt+=1
            pdb.set_trace()
            new_repo_merge1["total_grouping"] = compliance
            LOG.info("Weekly data processing is SUCCESSFUL for generating Reports!")
            self.ret = new_repo_merge1
            self.hr_list = hr_list


    def assign_action(self,week_df):
        try:
           
            df = week_df.copy()
            ## check if date range is quarter start
            quarter_info = pd.DataFrame(self.quarter_dict)
            quarter_info['start_date'] = pd.to_datetime(quarter_info['start_date'])
            if quarter_info['start_date'].isin(df['start_date']).any():
                #self.truncate_table()
                df['action'] = np.where(df['total_grouping']=='No Compliance','X1','C')
                df['final_status'] = df['action'].copy()
                LOG.info("Sucessfully assigned action")
                return df
            else:
                #import previous assigned table
                last_week_df = self.table_df[self.table_df['start_date']==self.table_df['start_date'].max()].copy().reset_index(drop=True)
                df = df.merge(last_week_df[['employ_id','action','final_status']],left_on=['employ_id'],right_on=['employ_id'],how='left')
                df['new_action'] = np.where(((df['total_grouping']=='No Compliance') & (df['action']=='C')),'X1',
                                   np.where(((df['total_grouping']=='No Compliance') &(df['action']=='X1')),'X2',
                                   np.where(((df['total_grouping']=='No Compliance') &(df['action']=='X2')),'X3',
                                   np.where(((df['total_grouping']=='No Compliance') &(df['action']=='X3')),'X4',
                                   np.where(((df['total_grouping']=='No Compliance') &(df['action']=='X4')),'X4',df['action'])))))
                df['new_action'] = np.where(((df['total_grouping']=='No Compliance') &(df['new_action'].isnull())),'X1',
                                   np.where(((df['total_grouping']!='No Compliance') &(df['new_action'].isnull())),'C',df['new_action']))
                df.drop(['action'],1,inplace=True)
                df['final_status'] = df['new_action'].copy()
                df.rename(columns={'new_action':'action'},inplace=True)
                df['final_status'] = np.where((df['total_grouping']!='No Compliance'),'C',df['final_status'])
                LOG.info("Sucessfully assigned action")
            return df
        except Exception as e:
            LOG.error("Cannot assign action. The error is \n : %s", str(e))

    def patchy_partial_ext(self):
        try:
            date_list = pd.date_range(start=self.start_date,end=self.end_date)  #date_list = pd.date_range(start="2020-10-05",end="2022-01-30")
          
            date_df = pd.DataFrame(date_list,columns=['date'])
            date_df['dayname'] = date_df['date'].dt.day_name()
            i = date_df.loc[date_df['date'] == self.start_date,
                                   'date'].dt.day_name().iloc[0]
            date_df['weekno'] = date_df['dayname'].eq(i).cumsum()
            date_df['quarter'] = np.where(date_df['date']==self.quarter_end[0],'Q1',
                            np.where(date_df['date']==self.quarter_end[1],'Q2',
                            np.where(date_df['date']==self.quarter_end[2],'Q3',
                            np.where(date_df['date']==self.quarter_end[3],'Q4',
                            np.where(date_df['date']==self.quarter_end[4],'Q1',None)))))
            date_df['quarter'] = date_df['quarter'].fillna(method='bfill')
            date_df = date_df.merge(date_df.groupby(['weekno'])['date'].agg(
                    ['min','max']).reset_index(),left_on='weekno',
                    right_on='weekno', how='left')
            date_df.rename(columns={'min':'start_date','max':'end_date'},inplace=True)
            date_df.drop(['date','dayname'],1,inplace=True)
            date_df = date_df.drop_duplicates().reset_index(drop=True)   #
          
            df = self.ret.copy()
            columns_to_copy = ['employ_id','employ_name','manager_name',
                               'manager_id','bu','total','total_grouping']  #edited total grouping
            non_df = df[columns_to_copy].copy()
            non_df['start_date'] = pd.to_datetime(df.columns[6])
            non_df['end_date'] = pd.to_datetime(df.columns[12])
            non_df = non_df.merge(date_df,left_on=['start_date','end_date'],right_on=['start_date','end_date'])
            ## read the existing table from database
            
            action_df = self.assign_action(non_df)
            global date_format
            date_format =str(datetime.now()).split(".")[0]
            non_df['employ_id'] = non_df['employ_id'].astype(str).apply(lambda row: re.sub("[^0-9A-Z]", "", row))
            self.hr_list['employ_id'] = self.hr_list['employ_id'].astype(str).apply(lambda row: re.sub("[^0-9A-Z]", "", row))
            #append acion_df to table
            self.hr_list["employ_id"] = self.hr_list["employ_id"].str.lower()
            action_df = action_df.merge(self.hr_list[['employ_id','EmployeeEmail','ManagerEmail']],
                                        left_on=['employ_id'],right_on=['employ_id'],how='left')
            action_df.rename(columns={'EmployeeEmail':'employee_email','ManagerEmail':'manager_email'},inplace=True)
            action_df = action_df[['employ_id', 'employ_name', 'manager_name', 'manager_id', 'bu',
                                   'total', 'total_grouping', 'start_date', 'end_date', 'weekno',
                                   'quarter', 'final_status','action', 'employee_email',
                                   'manager_email']]
            action_df['start_date']=action_df['start_date'].astype(str)
            action_df['end_date']=action_df['end_date'].astype(str)
            action_df['employ_name']=action_df['employ_name'].replace('\'',' ',regex=True)
            action_df['manager_name']=action_df['manager_name'].replace('\'',' ',regex=True)
            LOG.info(f"badge data frame size is:{action_df.shape[0]}")
            not_matched_df=action_df[action_df['manager_name']==""]
            not_matched_df = not_matched_df[not_matched_df.columns[0:8]]
            action_df.drop(not_matched_df.index,inplace=True)
            self.bu_list = action_df["bu"].unique()
            global get_report_bu_list
            get_report_bu_list = self.bu_list
            
            date_format=date_format.replace(":",'.')
            path = os.path.join(r"E:\Covid19\bcp_reports\bcp_reports_V3",str(date_format))
            self.ret = self.ret[self.ret["manager_name"]!=""]
            os.mkdir(path)
            self.weekly_report = action_df.copy()
            self.weekly_report.to_csv(os.path.join(path,'week_report.csv'),index=False)
            LOG.info("Week Report generated")
            pdb.set_trace()
            global new_merge_report
            new_merge_report=pd.merge(self.ret[["employ_id"]],self.hr_list[self.hr_list.columns[1::]],left_on="employ_id",right_on='employ_id_new',how='left')

            self.ret.to_csv(os.path.join(path,'emp_compliance.csv'),index=False)
            LOG.info(f"Employee compliance Report generated: {self.ret.shape[0]}")
            not_matched_df.to_csv(os.path.join(path,"employees_not_present_hr.csv"),index=False)
            LOG.info(f"Not matched employee list:{not_matched_df.shape[0]}")
            LOG.info("Sucessfully generated weekly report")
            self.write_data(self.weekly_report,self.cur_qtr_no_comp_table)
            #self.write_mail()
            #return self.weekly_report
        except Exception as e:
            LOG.error("Error writing to table. The error is \n : %s", str(e))

    def write_mail(self):
        mail_df = self.weekly_report[self.weekly_report['final_status'].isin(['X1','X2'])].copy()
        for row in mail_df.itertuples():
            if row.final_status == 'X1':
                frm_addr = 'AMSEA_EHS@amat.com'
                self.send_first_warning(frm_addr,row.employee_email,row.manager_email)
            elif row.final_status == 'X2':
                frm_addr = 'AMSEA_SLT@AMAT.com'
                self.send_second_warning(frm_addr,row.employee_email,row.manager_email)

    def send_first_warning(self,from_addr,to_addr,cc_addr):
        try:
            msg = MIMEMultipart('alternative')
            msg['Subject'] = "1st Warning - Twice Daily Temperature and Respiratory Symptoms Declaration Non-Compliance"
            msg['From'] = from_addr
            msg['To'] = to_addr
            msg['CC'] = cc_addr
            msg['Bcc'] = from_addr
            html = """\
            <html>
              <head></head>
              <body>
              <p>
                <p>Dear Employee,</p>
        
            <p>AMSEA temperature and respiratory symptoms (TRS) declaration records indicate that you have <b>more than 2 days where no 
            declaration was completed over the last 7 day period</b> (Friday to Thursday, inclusive).<b>If you continue failing to comply,
            your case will be escalated to AMSEA SLT.</b></p>
        
            <p>The TRS measure is <b>mandatory for all AMSEA workforce (RFTs and CWFs) regardless of working location.</b>
            To be fully compliant with this measure, you are required to submit TRS declarations twice-daily, including on weekends.</p>
        
            <p>Please be aware that your failure to comply with this measure increases the risk of exposure to COVID-19 for our colleagues
            and loved ones, by allowing COVID-19 cases to remain undetected. As countries are resuming more activities, it is critical
            we safeguard our worksites to avoid disruptions to our operations caused by confirmed cases.</p>
        
            <p>You can access your declaration history, at <a href ="https://team.amat.com/sites/GISCOVID19Asia/SitePages/SGCovidMyHistory.aspx/">
            My Declaration History</a> from corporate devices connected to Pulse Secure. If you are concerned your declarations are not 
            being captured, please record the date and time and inform your Manager and EHS for us to investigate further.</p>
        
            <p>Let’s stay safe together!</p>
            
            <p>Regards,</p>
            <p></p>
        
        
            <p>AMSEA EHS</p>
                </p>
              </body>
            </html>
            """
            part1 = MIMEText(html, 'html')
            msg.attach(part1)
            s = smtplib.SMTP('mailserver.mis.amat.com',25)
            s.sendmail(from_addr, [to_addr]+[cc_addr]+[from_addr], msg.as_string())
            s.quit()
            LOG.info("Sucessfully sent mail for first warning")
        except Exception as e:
            LOG.error("Error in sending mail. The error is \n : %s", str(e))

    def send_second_warning(self,from_addr,to_addr,cc_addr):
        try:
            cc1 = cc_addr
            cc2 = 'AMSEA_EHS@AMAT.com'
            msg = MIMEMultipart('alternative')
            msg['Subject'] = "2nd Warning - Twice Daily Temperature and Respiratory Symptoms Declaration Non-Compliance"
            msg['From'] = from_addr
            msg['To'] = to_addr
            msg['CC'] = cc1+','+cc2
            html = """\
            <html>
              <head></head>
              <body>
              <p>
                <p>Dear Employee,</p>
        
            <p>AMSEA temperature and respiratory symptoms (TRS) declaration records indicate that you had <b>2 weeks within this quarter
            where no declaration was completed for more than 2 days</b>. This is in spite of the previous warning from AMSEA EHS. 
            <b>If you continue failing to comply, a formal discussion with your manager will be arranged.</b></p>
        
            <p>Full compliance for TRS is important to safeguarding the health and safety of AMSEA employees. More critically, 
            <b>any non-adherence to the above safe management measure puts AMSEA’s operations at risk</b>. Please be reminded that 
            <b>twice-daily completion of this declaration is mandatory for all AMSEA workforce (RFTs and CWFs workforce), regardless 
            of working location, including weekends</b>. The measures introduced in AMSEA can only be effective if everyone takes 
            them seriously and plays their part. Please ensure you submit the TRS declaration twice a day to comply with this 
            measure. </p>
        
            <p>You can access your declaration history, at <a href ="https://team.amat.com/sites/GISCOVID19Asia/SitePages/SGCovidMyHistory.aspx/">
            My Declaration History</a> from corporate devices connected to Pulse Secure. If you are concerned your declarations are not 
            being captured, please record the date and time and inform your Manager and EHS for us to investigate further.</p>
        
            <p>Let’s stay safe together!</p>
            
            <p>Regards,</p>
        
        
            <p>AMSEA SLT</p>
                </p>
              </body>
            </html>
            """
            part1 = MIMEText(html, 'html')
            msg.attach(part1)
            s = smtplib.SMTP('mailserver.mis.amat.com',25)
            s.sendmail(from_addr, [to_addr]+[cc1]+[cc2], msg.as_string())
            s.quit()
            LOG.info("Sucessfully sent mail for second warning")
        except Exception as e:
            LOG.error("Error in sending mail. The error is \n : %s", str(e))
    
if __name__ == "__main__":
   
    conf_file = "conf/db_conf.yaml" 
    no_comp= NonCompliance(conf_file)
    LOG.info("Process started")
    no_comp.load_data(conf_file)
    no_comp.read_data()
    no_comp.report_process(conf_file)
    no_comp.patchy_partial_ext()
    LOG.info("Quarter report started")
    qtr_repo= QuarterReport(conf_file)
    qtr_repo.read_data()
    qtr_repo.generate_report(date_format)
    qtr_repo.update_last_timesamp()
    LOG.info("Get report started")
    
    get_report = manual_report_generate(get_report_start_date,get_report_end_date,get_report_bu_list,sheet_1,new_merge_report,date_format)
    
