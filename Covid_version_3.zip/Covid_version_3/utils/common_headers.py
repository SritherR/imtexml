#!/usr/bin/env python
# common_headers
import re
import os, os.path
import sys
import csv
import yaml
import time
import shutil
import traceback
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
from collections import OrderedDict
from logger import LOG
from db import MariaDBUtil
from datetime import datetime
#from conf import conf_file
import warnings
warnings.filterwarnings("ignore")
import os

#report_compliance.py
print(os.getcwd())
tmp_list = ['35.5', '35.6', '35.7', '35.8', '35.9', '36.0', '36.1', '36.2', '36.3', '36.4', '36.5', '36.6', '36.7',
            '36.8', '36.9', '37.0', '37.1', '37.2', '37.3', '37.4', '37.5', '<35.5', '>37.5']
emp_hr_tmp_list = ['bu', '35.5', '35.6', '35.7', '35.8', '35.9', '36.0', '36.1', '36.2', '36.3', '36.4', '36.5',
                   '36.6', '36.7', '36.8', '36.9', '37.0', '37.1', '37.2', '37.3', '37.4', '37.5', '<35.5', '>37.5']
emp_hr_tmp_grp_list = ['bu', '35.5', '35.6', '35.7', '35.8', '35.9', '36.0', '36.1', '36.2', '36.3', '36.4', '36.5',
                       '36.6','36.7', '36.8', '36.9', '37.0', '37.1', '37.2', '37.3', '37.4', '37.5', '<35.5', '>37.5',
                       'Normal Range Total', 'Grand Total']
symptom_list = ['No', 'Yes']
symptemp_col_list = ['id', 'start_time', 'completion_time', 'email', 'name', 'employ_name', 'orig_employ_id',
                     'temperature', 'symptoms',
                     'manager_email', 'completion_date', 'emp_id', 'employ_id', 'bu']

emp_bu_comp_list = ['bu', 'Full Compliance', 'No Compliance', 'Patchy Partial','Consistent Partial',
                    'Full Compliance_%', 'No_Compliance_%','Patchy Partial_%',
                    'Consistent Partial_%', 'Grand Total']
                    
                    



