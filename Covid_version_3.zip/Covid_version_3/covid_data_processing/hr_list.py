"""  Loading raw HR data into database"""

import warnings
#import pandas as pd
#import yaml
#from utils import MariaDBUtil
#from utils import LOG

warnings.filterwarnings("ignore")

from utils import (
    yaml,
    MariaDBUtil,
    pd,
    np,
    LOG,
    conf_file)

class HRDataLoader:
    """Utilities for working for MangoDB"""

    def __init__(self, conf_file, hr_excel):
        self.conf_file = conf_file
        self.hr_excel = hr_excel
        try:
            with open(self.conf_file, 'r') as conf_yaml:
                config_detail = yaml.safe_load(conf_yaml)
                self.hr_table = config_detail.get("tables").get("hr_table")
        except Exception as e:
            LOG.error("Cannot open config file. The error is \n : %s", e)            
  
    def read_data(self):
        """
        :rtype: reading the excel sheet
        """
        LOG.info("Reading data form excel has started: %s", self.hr_excel)
        df1 = pd.read_excel(self.hr_excel)
        LOG.info("HR data reading is successful and the shape: %s", df1.shape)
        return df1

    def write_data(self, hr_df):
        """
            Load data into postgres tables
        """
        LOG.info("Writing data to DB has started and shape of df is : %s", hr_df.shape)
        hr_list = hr_df
        #UID should be changed
        hr_list.rename(columns={'Employee ID': 'employ_id',
                                'Legal Name': 'legal_name',
                                'Preferred Name':'preferred_name',
                                'Supervisory Org Subtype (HRBU)': 'bu',
                                'Manager ID': 'manager_id',
                                'Manager Name': 'manager_name',
                                'Company - Name': 'company'}, inplace=True)

        LOG.info("Data shape is %s", hr_list.shape)
        hr_list['legal_name'] = hr_list['legal_name'].str.replace(r'[^\x00-\x7F]+', '')
        hr_list['preferred_name'] = hr_list['preferred_name'].str.replace(r'[^\x00-\x7F]+', '')
        hr_list['manager_name'] = hr_list['manager_name'].str.replace(r'[^\x00-\x7F]+', '')

        try:
            with MariaDBUtil(self.conf_file) as mysql_utils:
                conn = mysql_utils.connection
                LOG.info("Connection  to db is successful!")
                hr_list.to_sql(self.hr_table,
                               conn,
                               if_exists='replace',
                               index=False)
                LOG.info("Dumping HR data into db is successful!")
        except Exception as e:
            LOG.error("Connect to pgsql is failed. The error is \n : %s", e)
        finally:
            LOG.info("File processed successfully!")

    def load_hr_data(self):
        """   Loads HR data """
        hr_list = dl_obj.read_data()
        dl_obj.write_data(hr_list)
        
    def runall_hr(self):
        """  Calling all below functions for watchdog_hrloader  """
        LOG.info("Initializing the variables!")
        LOG.info("HR LIST : %s", self.hr_excel)
        LOG.info("Data loading to HR has started!")
        hr_df = self.read_data()
        self.write_data(hr_df)

def fetch_bu_list():
    try:
        with MariaDBUtil(conf_file) as mysql_utils:
            conn = mysql_utils.connection
            LOG.info("Connection  to db is successful!")
            bu_df = pd.read_sql("SELECT DISTINCT(BU) FROM dbo.S_EmpMaster;",
                           conn)
            bu_list = bu_df['BU'].values.tolist()
        LOG.info("Successfully read BU list for UI")
        return bu_list
    except Exception as e:
        LOG.error("Connect to pgsql is failed for BU list. The error is \n : %s", e)


if __name__ == "__main__":
    dl_obj = HRDataLoader(conf_file)
    dl_obj.load_hr_data()