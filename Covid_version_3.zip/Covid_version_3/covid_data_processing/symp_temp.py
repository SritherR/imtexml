"""
    For Generating Symptoms, Temperature Reports
"""
# from utils import (
    # LOG,
    # pd,
    # re,
    # yaml,
    # MariaDBUtil,
    # tmp_list,
    # symptom_list,
    # symptemp_col_list,
    # emp_hr_tmp_list,
    # emp_hr_tmp_grp_list,
    # conf_file)
#from conf import conf_file

from .emp_stats_integrated import CountResponse


def calc_non_compliance(df_date, df_empty, df_temp):
    """
        Calculating the count of Response for each Employee
    """
    flag = 1
    df_empty = df_empty
    df_date = df_date
    df_temp = df_temp
    for date in df_date:
        df_temp['date'] = date
        df_temp['cnt_response'] = 0
        if flag == 1:
            df_empty = df_temp
            flag = 2
        else:
            df_empty = pd.concat([df_empty, df_temp], axis=0)
    return df_empty


def clean_name_col_val(df, col_name):
    """
        Cleaning the employ name column for Employee and HR data
    """
    df[col_name] = df[col_name].str.replace(",", "") #
    df[col_name] = df[col_name].str.replace(".", "")
    df[col_name] = df[col_name].str.replace("/", "")
    df[col_name] = df[col_name].str.replace("-", "")
    df[col_name] = df[col_name].str.replace("@", "")
    df[col_name] = df[col_name].str.replace(" ", "_")
    df[col_name] = df[col_name].str.replace(r"[^a-zA-Z0-9_\s]", "+") #
    df[col_name] = df[col_name].str.extract(pat='([a-zA-Z_]+.)') #
    df[col_name] = df[col_name].str.replace(r"[^a-zA-Z\s]", " ") #
    df[col_name] = df[col_name].str.lower().str.strip() #
    return df


def exchange_val(row):
    """
        Cleaning the employ name column for Employee and HR data
    """
    data = ''
    emp_name = row['employ_name']
    emp_id = row['employ_id']
    if len(emp_id) < 9 and (emp_id.isalpha()) is False:
        # return row['employ_id']
        data = row['employ_id']
    elif re.search("[eE|xX|0-9][0-9]+\\b", emp_name):
        # return emp_name
        data = emp_name
    else:
        # return row['employ_id']
        data = row['employ_id']
    return data


def check_employee(row):
    """
        Cleaning the employ_id column by removing x,c,e
    """
    val = None
    if row.isnumeric():
        val = row
    elif len(row) <= 2:
        val = row
    elif row[0] == 'X' or row[0] == 'x':
        if row[1] == '0' and row[2:].isnumeric():
            row = 'X0' + row[2:]
            val = row
        else:
            val = row
    elif (row[0] == 'C' or row[0] == 'c') and row[1:].isnumeric():
        row = 'C' + row[1:]
        val = row
    elif (row[0] == 'E' or row[0] == 'e') and row[1:].isnumeric():
        row = row[1:]
        val = row
    else:
        val = row
    return val


def create_query(start_date, end_date, bu_list):
    """
        Filtering employ data and HR data based on the user
        selected date range and BU list
    """
    #bu_list = tuple(bu_list)

    try:
        with open(conf_file, 'r') as conf_yaml:
            config_detail = yaml.safe_load(conf_yaml)
            hr_table = config_detail.get("tables").get("hr_table")
            emp_table = config_detail.get("tables").get("emp_table")
            hr_query = \
                """ (select * from %s where bu in %s) """ % (hr_table, bu_list)
            emp_query = """(Select * from %s where submitDate >= "%s"
                        and submitDate <= "%s") """ \
                        % (emp_table, start_date, end_date)
                        
            return hr_query, emp_query
    except Exception as e:
        LOG.error("Opening Conf file failed. The error is \n : %s", str(e))


class SympTempGenerateHandler:
    """
        Symptoms & Compliance Generate Class
    """

    def __init__(self, gui_input_dict,sheet1,hr_list):
        self.gui_input_dict = gui_input_dict
        self.sheet1=sheet1
        self.hr_list=hr_list
        
    
    def load_data(self):
        """
           Loads Data from Database based on input params provided
        """
        try:
            emp_date_df = pd.DataFrame()
            df_hr= pd.DataFrame()
            #stats_obj=CountResponse(conf_file,self.gui_input_dict)
            #emp_date_df, df_hr=stats_obj.read_data()
            #emp_date_df, df_hr, date_df =stats_obj.call_emp_stats()
            emp_date_df=self.sheet1
            df_hr=self.hr_list
            LOG.info("Data reading from db is successfully completed!!,Total count of raw data is --> %s", emp_date_df.shape)
            LOG.info("Data reading from db is successfully completed!!,Total count of hr list is --> %s", df_hr.shape)
            emp_date_df.rename(columns={'date': 'completion_date'}, inplace=True)
            cols = ['id','start_time','completion_time','employ_name','employ_id','temperature','symptoms','manager_email','completion_date']
            emp_date_df=emp_date_df[cols]
            emp_date_df['email']=""
            emp_date_df['name']=""
            return emp_date_df, df_hr
        except Exception as e:
            LOG.error("No Employee data found from database!. "
                      "The error is \n : %s", str(e))

    def read_data(self):
        """  Loading the Employee and HR tables from db based on the user
             selected data range, BU list and returning the same as two data frames
        """
        emp_date_df = pd.DataFrame()
        try:
            with MariaDBUtil(conf_file) as mysql_utils:
                conn = mysql_utils.connection
                for i in self.gui_input_dict['date_list']:
                    hr_query, emp_query = create_query(i['start_date'], i['end_date'],
                                                       self.gui_input_dict['bu_list'])
                    df_emp = pd.read_sql(emp_query, conn)
                    LOG.info("total data read from Employee table is %s", df_emp.shape)
                    if len(df_emp) != 0:
                        emp_date_df = pd.concat([emp_date_df, df_emp], axis=0)
                    else:
                        LOG.warning("No Employee data found from database")
                df_hr = pd.read_sql(hr_query, conn)
                LOG.info("total data read  from HR table is %s", df_hr.shape)
                if len(df_hr) == 0:
                    LOG.warning("WARNING : No HR Data Found for given input")
                conn.close()
                
                emp_date_df["start_time"]=emp_date_df["submitDateTime"]
                emp_date_df.rename(columns={emp_date_df.columns[0]: "id",
                            emp_date_df.columns[1]: 'employ_id',
                            emp_date_df.columns[2]: 'employ_name',
                            emp_date_df.columns[3]: 'manager_email',
                            emp_date_df.columns[4]: 'temperature',
                            emp_date_df.columns[5]: 'symptoms',
                            emp_date_df.columns[6]: 'completion_time',
                            emp_date_df.columns[7]: 'completion_date'
                            }, inplace=True)
                cols = ['id','start_time','completion_time','employ_name','employ_id','temperature','symptoms','manager_email','completion_date']
                emp_date_df=emp_date_df[cols]
                emp_date_df['email']=""
                emp_date_df['name']=""
            return emp_date_df, df_hr
        except Exception as e:
            LOG.error("Connect to maria db is failed. The error is \n : %s", str(e))

    def processing(self):
        """
            BU label 'Symptoms' and 'Temperature' report generation
            Parameters
            ----------
            sheet : dataframe
            DataFrame containing processed employee data
                hr_list : dataframe
            DataFrame containing processed hr data

            Returns
            -------
            status : bool
            True if dataframe is generated else False
                no_match_name_df_2 : dataframe
            DataFrame containing non-available bu count for certain employees
                emp_hr_symp : dataframe
            DataFrame containing BU label 'Symptoms' report
                emp_hr_temp : dataframe
            DataFrame containing BU label 'Temperature' report
        """
        no_match_name_df_2 = ''
        emp_hr_symp = ''
        emp_hr_temp = ''
        status = True
        try:
            # uncomment the below line,
            # if you need to exclude Emp data from Exempt File provided
            # clean_emp_data() --> removes exempt matched Emp ID
            # sheet, hr_list = self.clean_emp_data()
            #sheet, hr_list = self.read_data()
            sheet, hr_list = self.load_data()
            LOG.info("Total count of raw data is --> %s", sheet.shape)
            LOG.info("Total count of hr list is --> %s", hr_list.shape)
            if len(sheet) != 0 and len(hr_list) != 0:
                sheet['employ_id'] = sheet['employ_id'].apply(lambda x: x.replace(" ", ""))
                sheet['employ_id'] = sheet['employ_id'].apply(lambda x: re.sub('O|o', '0', x))
                sheet['employ_id'] = sheet['employ_id'].apply(lambda x: x.strip())
                sheet['employ_id'] = sheet['employ_id'].apply(
                    lambda x: x.encode('ascii', 'ignore').decode("utf-8"))
                sheet['employ_id'] = sheet.apply(exchange_val, axis=1)
                sheet['emp_id'] = sheet['employ_id'].apply(check_employee)
                sheet.rename(columns={'employ_id': 'orig_employ_id', }, inplace=True)
                emp_df = sheet
                LOG.info("Total count of employees after processing is %s", sheet.shape)
                # removing character from the employee ids from both employ and hr sheet
                try:
                    emp_df['emp_id'] = \
                        emp_df['emp_id'].apply(lambda row: re.sub("[^0-9]", "", row))
                except Exception as e:
                    LOG.warning(str(e))
                    emp_df['emp_id'] = emp_df['emp_id']
                #hr_list['legal_name']=hr_list['legal_name'].apply(lambda name:(str(name.split(",")[-1])+" "+str(name.split(",")[0])).strip())
                hr_list = clean_name_col_val(hr_list, 'legal_name')
                hr_list["upd_legal_name"] = \
                    hr_list["legal_name"].apply(lambda i: " ".join(i.split()[::-1]))

                hr_list['employ_id'] = \
                    hr_list['employ_id'].apply(lambda row: re.sub("[^0-9]", "", row))

                #hr_list['employ_id']=hr_list['employ_id'].apply(lambda x:'"'+str(x)+'"')
                #hr_list.to_csv("hr_list.csv",index=False,quotechar='"')
                #emp_df['emp_id']=emp_df['emp_id'].apply(lambda x:'"'+str(x)+'"')
                #emp_df.to_csv("emp_df.csv",index=False)
                emp_hr_df = pd.merge(emp_df,
                                     hr_list[['employ_id', 'bu']],
                                     left_on='emp_id', right_on='employ_id',
                                     how='left')

                emp_hr_df['bu'].fillna('#N/A', inplace=True)
                emp_hr_df['employ_id'].fillna('find_match_name', inplace=True)

                # final_emp_hr --> Emp Id matched
                final_emp_hr = emp_hr_df[emp_hr_df['employ_id'] != 'find_match_name']

                # find_by_name_emp_hr  --> Emp Id not matched
                find_by_name_emp_hr = emp_hr_df[emp_hr_df['employ_id'] == 'find_match_name']
                LOG.info("count of N/A is ----> %s", find_by_name_emp_hr.shape)
                find_by_name_emp_hr = clean_name_col_val(find_by_name_emp_hr, 'employ_name')
                
                # finding employee's based on employ_name & upd_legal_name col
                emp_hr_name_df = pd.merge(find_by_name_emp_hr,
                                          hr_list[['upd_legal_name']],
                                          left_on='employ_name', right_on='upd_legal_name',
                                          how='left')
                emp_hr_name_df['upd_legal_name'].fillna('no_match', inplace=True)
                no_match_name_df = emp_hr_name_df[emp_hr_name_df['upd_legal_name'] == 'no_match']
                LOG.info("count of N/A after matching name in reverse ----> %s",
                         no_match_name_df.shape)
                matched_name_df = emp_hr_name_df[emp_hr_name_df['upd_legal_name'] != 'no_match']

                # finding employee's based on employ_name & legal_name
                emp_hr_name_df_2 = pd.merge(no_match_name_df,
                                            hr_list[['legal_name']],
                                            left_on='employ_name', right_on='legal_name',
                                            how='left')
                emp_hr_name_df_2['legal_name'].fillna('no_match', inplace=True)
                no_match_name_df_2 = emp_hr_name_df_2[emp_hr_name_df_2['legal_name'] == 'no_match']
                matched_name_df_2 = emp_hr_name_df_2[emp_hr_name_df_2['legal_name'] != 'no_match']

                # since bu will be #N/A finding it by merging with hr_list based on Emp name
                bu_df = pd.merge(matched_name_df, hr_list,
                                 left_on='employ_name', right_on='upd_legal_name',
                                 how='left')
                bu_df_2 = pd.merge(matched_name_df_2, hr_list,
                                   left_on='employ_name', right_on='legal_name',
                                   how='left')

                # selecting only required columns to concat
                no_match_name_df = no_match_name_df[symptemp_col_list]
                no_match_name_df["employ_id"].replace({"find_match_name": ""}, inplace=True)
                bu_df.rename(columns={'bu_y': 'bu', 'employ_id_y': 'employ_id'}, inplace=True)
                bu_df = bu_df[symptemp_col_list]
                no_match_name_df_2 = no_match_name_df_2[symptemp_col_list]
                no_match_name_df_2["employ_id"].replace({"find_match_name": ""},
                                                        inplace=True)
                bu_df_2.rename(columns={'bu_y': 'bu', 'employ_id_y': 'employ_id'},
                               inplace=True)
                bu_df_2 = bu_df_2[symptemp_col_list]

                final_emp_hr = \
                    pd.concat([final_emp_hr, no_match_name_df_2, bu_df, bu_df_2, ], axis=0)
                    
                # final_emp_hr --> final data frame need to be sent for
                #**********************generating temperature & Symptoms***************
                
                final_emp_hr = \
                    final_emp_hr[['emp_id', 'symptoms', 'temperature', 'employ_id', 'bu']]

                # *****  For Generating Employee Hr,Symptoms Report ******
                
                emp_hr_symp = final_emp_hr.groupby(['bu'])['symptoms'] \
                    .value_counts().unstack().reset_index().fillna(0)
                for symptom in symptom_list:
                    if symptom not in emp_hr_symp:
                        emp_hr_symp[symptom] = 0
                emp_hr_symp = emp_hr_symp[['bu', 'No', 'Yes']]
                emp_hr_symp['Grand Total'] = emp_hr_symp['No'] + emp_hr_symp['Yes']
                emp_hr_symp.columns = ['bu', 'No', 'Yes', 'Grand Total']
                emp_hr_symp = \
                    emp_hr_symp.append(emp_hr_symp[['No', 'Yes', 'Grand Total']].sum(axis=0),
                                       ignore_index=True).fillna('Grand Total')
                emp_hr_symp = emp_hr_symp.set_index('bu').astype(int)
                
                # ******************************************************************************

                # **** For Generating Employee Hr,Temperature Report ****************************
                
                emp_hr_temp = final_emp_hr.groupby(['bu'])['temperature']. \
                    value_counts().unstack().reset_index().fillna(0)
                for temp in tmp_list:
                    if temp not in emp_hr_temp:
                        emp_hr_temp[temp] = 0
                emp_hr_temp = emp_hr_temp[emp_hr_tmp_list]
                emp_hr_temp.loc[:, 'Grand Total'] = emp_hr_temp.sum(axis=1)
                emp_hr_temp['Normal Range Total'] = emp_hr_temp['Grand Total'] \
                                                    - emp_hr_temp['<35.5'] - emp_hr_temp['>37.5']
                emp_hr_temp = emp_hr_temp[emp_hr_tmp_grp_list]
                emp_hr_temp = emp_hr_temp.set_index('bu').astype(int)
                
                # *********************************************************************************
            else:
                status = False
        except Exception as e:
            LOG.error("ERROR: Exception caught is %s", str(e))
            status = "ERROR"
            no_match_name_df_2 = e
        return status, no_match_name_df_2, emp_hr_symp, emp_hr_temp