"""
Get all Employee, BU compliance, symptoms & temperture Report
"""

import os, sys
CURRENT_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.append(os.path.dirname(CURRENT_DIR))
print("***** curr path***", CURRENT_DIR)

from covid_data_processing import (
    #datetime,
    #os,
    #conf_file,
    #LOG,
    #yaml,
    EmpBUCompGenerateHandler,
    SympTempGenerateHandler
    #bcp_report_path
    )
#from conf import conf_file, bcp_report_path
from  utils import datetime, os, LOG, conf_file, bcp_report_path
REP_DIR = ''


def get_curr_date_time():
    """
    Create a common folder to dump all Reports
    """
    global REP_DIR
    today = datetime.now()
    curr_date = today.strftime('%Y-%m-%d')
    curr_time = today.strftime('%H:%M:%S').replace(':', '.')
    crt_dir = bcp_report_path + '/bcp_reports/' + curr_date + '  ' + curr_time
    try:
        os.makedirs(crt_dir)
    except OSError as e:
        LOG.error("ERROR : Exception caught is %s", str(e))
    else:
        REP_DIR = crt_dir


def fetch_report_1(gui_input_dict):
    """
    Function excepts input dictionary from GUI for genrating Employee Label Week Report
    """
    global REP_DIR
    try:
        repo_gen = EmpBUCompGenerateHandler(gui_input_dict)
        status, report_1,sheet1,hr_list = repo_gen.report_1()
    except Exception as e:
        LOG.error("ERROR : Exception caught is %s", str(e))
        status = "ERROR"
        report_1 = ''
        msg = 'ERROR : Exception caught {0}'.format(e)
    else:
        if status is 'ERROR':
            msg = 'ERROR : Exception caught is {0}'.format(report_1)
            report_1 = ''
            LOG.error(msg)
        elif status is True:
            msg = 'SUCCESS : Employee label weekly report got generated!"'
            report_1.to_csv(REP_DIR + '/emp_compliance.csv', index=False)
            LOG.info(msg)
        else:
            msg = 'WARNING: No Employee Data found for the given Date Range'
            LOG.warning(msg)
    report_1_dict = {'status': status, 'msg': msg, 'df': report_1}
    return report_1_dict,sheet1,hr_list


def fetch_report_2(gui_input_dict):
    """
     Function excepts input dictionary from GUI for genrating BU Label Week Report
    """
    global REP_DIR
    try:
        repo_gen = EmpBUCompGenerateHandler(gui_input_dict)
        status, report_2 = repo_gen.report_2()
    except Exception as e:
        LOG.error("ERROR : Exception caught is %s", str(e))
        status = "ERROR"
        msg = 'ERROR : Exception caught is {0}'.format(e)
    else:
        if status is 'ERROR':
            msg = 'ERROR : Exception caught {0}'.format(report_2)
            LOG.error(msg)
            report_2 = ''
        elif status is True:
            msg = 'SUCCESS : BU label weekly compliance report generated!'
            report_2.to_csv(REP_DIR + '/bu_compliance.csv', index=False)
            LOG.info(msg)
        else:
            msg = 'WARNING: No Employee Data found for the given Date Range'
            LOG.warning(msg)
    report_2_dict = {'status': status, 'msg': msg, 'df': report_2}
    return report_2_dict


def fetch_report_3(gui_input_dict,sheet1,hr_list):
    """
    Function excepts input dictionary from GUI for genrating Emp Symptoms, Temperature Report
    """
    global REP_DIR
    try:
        stats_obj = SympTempGenerateHandler(gui_input_dict,sheet1,hr_list)
        status, na_df, emp_hr_symp, emp_hr_temp = stats_obj.processing()
        
    except Exception as e:
        LOG.error("ERROR : Exception caught is %s", str(e))
        status = 'ERROR'
        na_df = ''
        emp_hr_symp = ''
        emp_hr_temp = ''
        msg = 'ERROR : Exception caught is {0}'.format(e)
    else:
        if status is 'ERROR':
            msg = 'ERROR : Exception caught is {0}'.format(na_df)
            na_df = ''
            emp_hr_symp = ''
            emp_hr_temp = ''
            LOG.error(msg)
        elif status is True:
            msg = 'SUCCESS : Employee, HR symptoms & temperature report generated! '
            na_df.to_csv(REP_DIR + '/no_match_emp_dtls.csv', index=False)
            emp_hr_symp.to_csv(REP_DIR + '/symptoms_report.csv', index=True)
            emp_hr_temp.to_csv(REP_DIR + '/abnormaltemp_report.csv', index=True)
            LOG.info(msg)
        else:
            msg = 'WARNING: No Employee Data found for the given Date Range'
            LOG.warning(msg)
    report_3_dict = {'status': status, 'msg': msg, 'df1': emp_hr_symp, 'df2': emp_hr_temp,
                     'df3': na_df}
    return report_3_dict


def manual_report_generate():
    """
    Manual Report Generation using conf file input
    """
    get_curr_date_time()
    try:
        with open(conf_file, 'r') as conf_yaml:
            config_detail = yaml.safe_load(conf_yaml)
            start_date = config_detail.get("report").get("start_date")
            end_date = config_detail.get("report").get("end_date")
            bu_list = config_detail.get("report").get("bu_list")
    except Exception as e:
        LOG.error("Opening Conf file failed. The error is \n : %s", str(e))
    else:
        manual_data_dict = {
            'bu_list': bu_list,
            'date_list': [
                {
                    'start_date': start_date,
                    'end_date': end_date
                }]}
        report_1_dict,sheet1,hr_list=fetch_report_1(manual_data_dict)
        #fetch_report_1(manual_data_dict)
        fetch_report_2(manual_data_dict)
        fetch_report_3(manual_data_dict,sheet1,hr_list)


if __name__ == '__main__':
    manual_report_generate()
