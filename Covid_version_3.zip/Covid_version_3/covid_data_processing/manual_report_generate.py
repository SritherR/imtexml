"""
manual report Generation
"""

import os, sys
CURRENT_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.append(os.path.dirname(CURRENT_DIR))
print("***** curr path***", CURRENT_DIR)

from covid_data_processing import fetch_report_1, fetch_report_2, fetch_report_3, get_curr_date_time

gui_input_dict = {'bu_list': (
    'FIN', 'SPG', 'AGS', 'QUA', 'IPC', 'WWO', 'NMA', 'DFT',
    'HRM', 'M&C', 'GIS', 'EES', 'LEG', 'CTO', 'ENG'),
                  'date_list':
                      [
                          {'start_date': '2020-06-19', 'end_date': '2020-06-25'}##,
                        ##  {'start_date': '2020-04-10', 'end_date': '2020-04-12'}
                      ]}

if __name__ == "__main__":
    get_curr_date_time()
    report_1_dict,sheet1,hr_list=fetch_report_1(gui_input_dict)
    #fetch_report_1(manual_data_dict)
    fetch_report_2(gui_input_dict)
    fetch_report_3(gui_input_dict,sheet1,hr_list)
