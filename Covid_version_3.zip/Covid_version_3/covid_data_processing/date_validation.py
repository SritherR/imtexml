"""
    For validating input date pairs from GUI
"""
from datetime import datetime
from collections import namedtuple
from flask import flash
from conf import BASE_DIR


# This function should be moved to common function file
def check_report_generation_status(rep_dict,response_list, report_name):
    """
        Function which flashes the msg to GUI
    """
    if rep_dict['status'] is True:
        flash(rep_dict['msg'])
        response_list.append(rep_dict['msg'])
        response_list.append("Reports successfully generated to - {}".format(BASE_DIR))
    elif rep_dict['status'] is False:
        response_list.append(rep_dict['msg'])
    else:
        if report_name is 'emp_report':
            response_list.append("Due to Some Error we Couldn't Generate Employee label Weekly Report")
        elif report_name is 'bu_report':
            response_list.append("Due to Some Error we Couldn't Generate BU label Weekly Compliance Report")
        else:
            response_list.append("Due to Some Error we Couldn't Generate Employee Symptoms, Temperature Report")
    return response_list

def check_date_overlap(check_date_list):
    """
        Function which checks for overlap in Date pairs
    """
    status = True
    msg_list = []
    Range = namedtuple('Range', ['start', 'end'])
    ref_list = check_date_list
    for i in range(len(check_date_list)):
        ch_date = check_date_list[i]
        s_date = ch_date['start_date'].split('-')
        e_date = ch_date['end_date'].split('-')
        for j in range(len(ref_list)):
            ch_ref_date = ref_list[j]
            if ch_date['start_date'] != ch_ref_date['start_date'] \
                    and ch_date['end_date'] != ch_ref_date['end_date']:
                ref_s_date = ch_ref_date['start_date'].split('-')
                ref_e_date = ch_ref_date['end_date'].split('-')
                range_first = Range(start=datetime(int(s_date[0]), int(s_date[1]),
                                                   int(s_date[2])),
                                    end=datetime(int(e_date[0]), int(e_date[1]),
                                                 int(e_date[2])))
                range_second = Range(start=datetime(int(ref_s_date[0]), int(ref_s_date[1]),
                                                    int(ref_s_date[2])),
                                     end=datetime(int(ref_e_date[0]), int(ref_e_date[1]),
                                                  int(ref_e_date[2])))
                latest_start = max(range_first.start, range_second.start)
                earliest_end = min(range_first.end, range_second.end)
                delta = (earliest_end - latest_start).days + 1
                overlap = max(0, delta)
                if overlap != 0:
                    msg = "Date Range {} to {} is Overlapped with Other Date" \
                          " Range Provided from {} to {},". \
                        format(ch_date['start_date'], ch_date['end_date'],
                               ch_ref_date['start_date'], ch_ref_date['end_date'])
                    msg_list.insert(i, msg)
                    status = False
    if not status:
        msg = "WARNING : Invalid Date Range ! Please Select a Proper Date Range,"
        msg_list.insert(0, msg)
    return status, msg_list


def check_start_end_valid(check_date_list):
    """
        Functions which checks start date always < end date
    """
    status = True
    msg_list = []
    error_date_list = \
        [i for i in check_date_list if not i['start_date'] <= i['end_date']]
    if error_date_list:
        for i in range(len(error_date_list)):
            error = error_date_list[i]
            msg = "Your Start Date {} is Greater than End Date {},". \
                format(error['start_date'], error['end_date'])
            msg_list.insert(i, msg)
        msg = "WARNING : Invalid Date Range ! Please Select a Proper Date Range,"
        msg_list.insert(0, msg)
        status = False
    return status, msg_list


def gui_input_validation(gui_input_dict):
    """
        Function which validates inputs like bu, date Pair 
        & send response to python
    """
    validation_dict = {}
    if gui_input_dict['bu_list']:
     
        check_date_list = gui_input_dict['date_list']
        status, valid_msg = check_start_end_valid(check_date_list)
        if status:
            status, overlap_msg = check_date_overlap(check_date_list)
            if status:
                status = True
                print("SUCCESS: Send Dictionary to backend")
                msg = "SUCCESS: Send Dictionary to backend"
            else:
                print("WARNING : Date Range are overlapped with other Provided Date Range !,"
                    "Please Select a Proper Date Range")
                msg = ''.join(overlap_msg)
        else:
            msg = ''.join(valid_msg)
            
    else:
        msg = 'Please Select a BU List provided !' 
        status = False
    validation_dict['msg'] = msg
    validation_dict['status'] = status
    return validation_dict


# Manual date validation/overlapping Test
if __name__ == "__main__":
    # valid check for dates
    gui_input_dict = {'bu_list': (),
                  'date_list': [
                      {'start_date': '2020-13-05', 'end_date': '2020-03-10'},
                      {'start_date': '2020-04-15', 'end_date': '2020-04-20'},
                      {'start_date': '2020-03-07', 'end_date': '2020-03-20'}
                      

                  ]
                  }
    try:
        resp = gui_input_validation(gui_input_dict)
    except Exception as e:
        print("Exception caught is {}". format(e))
    else:
        if resp['status']:
            print("send dictionary to backend")
        else:
            print(resp['msg'])