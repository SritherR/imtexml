"""
Get all Employee, BU compliance, symptoms & temperture Report
"""
import pdb
from emp_stats_integrated import CountResponse
from report_compliance import EmpBUCompGenerateHandler
from logger import LOG
from symp_temp import SympTempGenerateHandler
import os

def fetch_report_3(gui_input_dict,sheet1,hr_list,k):
    """
    Function excepts input dictionary from GUI for genrating Emp Symptoms, Temperature Report
    """
    global REP_DIR

    try:
        stats_obj = SympTempGenerateHandler(gui_input_dict,sheet1,hr_list)   #instead of gui use start date ,end date ,bulist
        status, na_df, emp_hr_symp, emp_hr_temp = stats_obj.processing()
        
    except Exception as e:
        LOG.error("ERROR : Exception caught is %s", str(e))
        status = 'ERROR'
        na_df = ''
        emp_hr_symp = ''
        emp_hr_temp = ''
        msg = 'ERROR : Exception caught is {0}'.format(e)
    else:
        if status is 'ERROR':
            msg = 'ERROR : Exception caught is {0}'.format(na_df)
            na_df = ''
            emp_hr_symp = ''
            emp_hr_temp = ''
            LOG.error(msg)
        elif status is True:
            msg = 'SUCCESS : Employee, HR symptoms & temperature report generated! '
            REP_DIR = os.path.join(r"E:\Covid19\bcp_reports\bcp_reports_V3",k)
            #na_df.to_csv(REP_DIR + '/no_match_emp_dtls.csv', index=False)
            emp_hr_symp.to_csv(REP_DIR + '/symptoms_report.csv', index=True)
            emp_hr_temp.to_csv(REP_DIR + '/abnormaltemp_report.csv', index=True)
            LOG.info(msg)
        else:
            msg = 'WARNING: No Employee Data found for the given Date Range'
            LOG.warning(msg)
    report_3_dict = {'status': status, 'msg': msg, 'df1': emp_hr_symp, 'df2': emp_hr_temp,
                     'df3': na_df}
    return report_3_dict
        
def manual_report_generate(start_date,end_date,bu_list,sheet1,hr_list,k):
    """
    Manual Report Generation using conf file input
    """
  
    manual_data_dict = {
        'bu_list': bu_list,
        'date_list': [
            {
                'start_date': start_date,
                'end_date': end_date
            }]}
    
    fetch_report_3(manual_data_dict,sheet1,hr_list,k)
