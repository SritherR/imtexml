"""
For Generating Emp/BU Label compliance Report
"""

# from utils import (
    # yaml,
    # MariaDBUtil,
    # pd,
    # np,
    # LOG,
    # emp_bu_comp_list,
    # conf_file)
import pdb
import pandas as pd
from logger import LOG
from emp_stats_integrated import CountResponse

'''
def create_query(start_date, end_date, bu_list):
    """
    Filtering a query based on params provided
    """
    try:
        
        with open(conf_file, 'r') as conf_yaml:
            config_detail = yaml.safe_load(conf_yaml)
            op_table = config_detail.get("tables").get("prod_op_table")
            repo_query = """(Select * from %s where date >= "%s" and date <= "%s" and bu in %s
                ) """ % (op_table, start_date, end_date, bu_list)
        return repo_query
    except Exception as e:
        LOG.error("Opening Conf file failed. The error is \n : %s", str(e))
'''

class EmpBUCompGenerateHandler:
    """
    Employee/BU label Compliance Generate Class
    """

    def __init__(self, gui_input_dict):
        pdb.set_trace()
        self.gui_input_dict = gui_input_dict

    def load_data(self):
        """
           Loads Data from Database based on input params provided
        """
        try:
            date_df = pd.DataFrame()
            stats_obj=CountResponse(conf_file,self.gui_input_dict)
            sheet1,hr_list,date_df = stats_obj.call_emp_stats()
            LOG.info("Data reading from db is successfully completed:"
                         " %s", date_df.shape)                          
            return sheet1,hr_list,date_df
        except Exception as e:
            LOG.error("No Employee data found from database!. "
                      "The error is \n : %s", str(e))

    def report_process(self):
        """ Processing the data to get common input dataframe (total_grouping)
        for report_1() and report_2()

                Parameters
                ----------
                op_table : table
                    Filtered employee table based on user selected start_date,end_date & bu from GUI

                Returns
                -------
                ret : dataframe
                    DataFrame containing common input to report_1() and report_2()
                status : bool
                    True if dataframe is generated else False
        """
        status = False
        ret = ''
        sheet1,hr_list,df = self.load_data()
        if len(df) != 0:
            repo_df = pd.DataFrame()
            repo_df1 = repo_df
            repo_df['employ_id'] = df['employ_id']
            repo_df['date'] = df['date'].astype(str)
            repo_df['count_label'] = df['count_label']
            repo_df2 = repo_df.drop_duplicates(['date', 'employ_id'], keep='first')
            repo_df3 = repo_df2.pivot(index='employ_id', columns='date',
                                      values='count_label').reset_index()
            repo_df1['employ_id'] = df['employ_id']
            repo_df1['employ_name'] = df['employ_name']
            repo_df1['manager_name'] = df['manager_name']
            repo_df1['manager_id'] = df['manager_id']
            repo_df1['Location'] = df['Location']
            repo_df1['bu'] = df['bu']
            repo_df1['manager_name'] = df['manager_name']
            repo_df1 = repo_df1.drop_duplicates('employ_id', keep='first')
            # Merging employee's date columns count responses dataframe &
            # employee's metadata dataframe with employ_id column
            repo_merge1 = pd.merge(repo_df1, repo_df3, how='left', on='employ_id')
            repo_merge1.fillna(0, inplace=True)
            repo_merge1.drop(['date'], axis=1, inplace=True)
            repo_merge1.drop(['count_label'], axis=1, inplace=True)
            repo_merge1.iloc[:, 6:] = repo_merge1.iloc[:, 6:].astype(int)
            repo_merge1['total'] = repo_merge1.iloc[:, 6:].sum(axis=1)
            date_cnt = repo_merge1.iloc[:, 6:-1].count(axis=1).values[0]
            repo_merge1.fillna(0, inplace=True)
            repo_merge1.loc[repo_merge1['total'] >= date_cnt * 2,
                            'total_grouping'] = 'Full Compliance'
            col_list = repo_merge1.iloc[:, 6:-2].columns
            for i in col_list:
                repo_merge1.loc[(repo_merge1[i] != 0) & (repo_merge1['total'] < date_cnt * 2),
                                'total_grouping'] = 'Consistent Partial'
            for i in col_list:
                repo_merge1.loc[repo_merge1[i] == 0, 'total_grouping'] = "Patchy Partial"
            ### adding new rule
            repo_merge1['count_zero'] = repo_merge1[col_list].isin([0]).sum(axis=1)
            repo_merge1.loc[repo_merge1['count_zero']>=3,'total_grouping']= 'No Compliance'
            repo_merge1.drop(['count_zero'],1,inplace=True)
#            repo_merge1.loc[repo_merge1['total'] == 0, 'total_grouping'] = 'No Compliance'
            LOG.info("Weekly data processing is SUCCESSFUL for generating Reports!")
            status = True
            ret = repo_merge1
        return status, ret,sheet1,hr_list

    def report_1(self):
        """ Employee Level Compliance Report Generation (report-1)

                Parameters
                ----------
                    ret : dataframe
                      DataFrame containing data after process
                Returns
                -------
                data : dataframe
                    DataFrame containing compliance grouping for each employee
                    ---> generates report-1
                    status : bool
                    True if Report_1 is generated else False
        """
        data = ''
        try:
            LOG.info("Employee label weekly report data processing started!")
            status, emp_comp_df,sheet1,hr_list, = self.report_process()
            if status:
                data = emp_comp_df
            LOG.info("Employee label weekly report data processing completed!")
        except Exception as e:
            LOG.error("Report1 function is not working. The error is \n : %s", str(e))
            status = 'ERROR'
            data = e
        return status, data,sheet1,hr_list

    def report_2(self):
        """  BU Level Compliance Report Generation(report-2)

                Parameters
                ----------
                    ret : dataframe
                       DataFrame containing data after preprocess

                Returns
                -------
                    data : dataframe
                        DataFrame containing compliance grouping for 
                                     each BU ---> generates report-2
                    status : bool
                        True if Report_2 is generated else False
        """
        status = False
        pdb.set_trace()
        data = ''
        try:
            LOG.info("BU label weekly compliance data processing has started! ")
            r_status, repo_bu_df,sheet1,hr_list = self.report_process()
            if r_status:
                bu_df = pd.DataFrame()
                bu_df['bu'] = repo_bu_df['bu']
                bu_df['total_grouping'] = repo_bu_df['total_grouping']
                bu_df['employ_id'] = repo_bu_df['employ_id']
                bu_df['flag'] = 1
                bu_df2 = bu_df.groupby(['bu', 'total_grouping'])['flag'].value_counts()\
                    .unstack().fillna(0).reset_index()
                bu_df2.rename(columns={1: 'cnt'}, inplace=True)
                bu_df3 = bu_df2.pivot(index='bu', columns='total_grouping', values='cnt')\
                    .fillna(0).reset_index()
                bu_df3['Grand Total'] = bu_df3.iloc[:, 1:].sum(axis=1)
                if 'Full Compliance' in bu_df3.columns:
                    bu_df3["Full Compliance_%"] = \
                        (bu_df3["Full Compliance"] / bu_df3["Grand Total"]) * 100
                    bu_df3["Full Compliance_%"] = bu_df3["Full Compliance_%"].apply(np.round)
                else:
                    bu_df3['Full Compliance'] = '0.0'
                    bu_df3['Full Compliance_%'] = '0.0'
                if 'No Compliance' in bu_df3.columns:
                    bu_df3["No_Compliance_%"] = \
                        (bu_df3["No Compliance"] / bu_df3["Grand Total"]) * 100
                    bu_df3["No_Compliance_%"] = bu_df3["No_Compliance_%"].apply(np.round)
                else:
                    bu_df3['No Compliance'] = '0.0'
                    bu_df3['No_Compliance_%'] = '0.0'
                if 'Patchy Partial' in bu_df3.columns:
                    bu_df3["Patchy Partial_%"] = \
                        (bu_df3["Patchy Partial"] / bu_df3["Grand Total"]) * 100
                    bu_df3["Patchy Partial_%"] = bu_df3["Patchy Partial_%"].apply(np.round)
                else:
                    bu_df3['Patchy Partial'] = '0.0'
                    bu_df3['Patchy Partial_%'] = '0.0'
                if 'Consistent Partial' in bu_df3.columns:
                    bu_df3["Consistent Partial_%"] =\
                        (bu_df3["Consistent Partial"] / bu_df3["Grand Total"]) * 100
                    bu_df3["Consistent Partial_%"] = bu_df3["Consistent Partial_%"].apply(np.round)
                else:
                    bu_df3['Consistent Partial'] = '0.0'
                    bu_df3['Consistent Partial_%'] = '0.0'
                status = True
                bu_df3 = bu_df3[emp_bu_comp_list]
                LOG.info("BU label weekly compliance data processing is completed!")
                data = bu_df3
        except Exception as e:
            LOG.error("Report2 function is not working. The error is \n : %s", str(e))
            status = "ERROR"
            data = e
        return status, data