import requests
import os
import logging
import datetime as dt
import time
root = r"/application/code/caliper/logs//"
LOG_FILE = root
if not os.path.exists(LOG_FILE):
    os.makedirs(LOG_FILE)
LOG_FILE = LOG_FILE + "/" + "status.log"
logFormatter = logging.Formatter("%(levelname)s %(asctime)s %(processName)s %(message)s")
fileHandler = logging.FileHandler("{0}".format(LOG_FILE))
fileHandler.setFormatter(logFormatter)
rootLogger = logging.getLogger()
rootLogger.addHandler(fileHandler)
rootLogger.setLevel(logging.INFO)

post_url_list = ["http://vau-lda-016:3090/api/v1/summary_statistics/","http://vau-lda-016:3090/api/v1/measure/","http://vau-lda-016:3090/api/v1/measured_image_status/","http://vau-lda-016:3090/api/v1/auto_pixel_calc","http://vau-lda-016:3090/api/v1/jobs/"]
put_url_list = ["http://vau-lda-016:3090/api/v1/measure/"]
get_url_list = ["http://vau-lda-016:3090/api/v1/algos/''","http://vau-lda-016:3090/api/v1/image_measurement/''"]
result_list = []

def api_status():
  print("spi status started")
  for url in post_url_list:
    response = requests.post(url,json={})
    if response.status_code == 200:
      result_list.append(f"{url} is running , method:post")
    else:
      result_list.append(f"{url} is not running , method:post")

  for url in put_url_list:
    respons = requests.put(url,json={})
    if response.status_code == 200:
      result_list.append(f"{url} is running , method:put")
    else:
      result_list.append(f"{url} is not running , method:put")

  for url in get_url_list:
    respons = requests.get(url)
    if response.status_code == 200:
      result_list.append(f"{url} is running , method:get")
    else:
      result_list.append(f"{url} is not running , method:get")

  return result_list
  

if __name__ == "__main__":
  result = api_status()
  print(result)
  for i in result:
    logging.info(i)

