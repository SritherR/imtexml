uvicorn caliper_api:app --reload --host 0.0.0.0 --port 3090 --ssl-keyfile=ssl/kaqaml.key --ssl-certfile=ssl/kaqaml.crt
#/application/pythonenv/caliper/bin/python3 /application/pythonenv/caliper/bin/uvicorn caliper_api:app --reload --host 0.0.0.0 --port 3090 --ssl-keyfile=ssl/icqpflaskdev.key --ssl-certfile=ssl/icqpflaskdev.crt
