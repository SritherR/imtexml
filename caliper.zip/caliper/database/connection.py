# coding: utf-8

"""Connection Module

1. Create engine connection to postgres.
2. Create raw connection to Postgres.
"""

__author__ = ["Samuel Joshua"]
__version__ = 1.0

# Standard Library
import datetime
import pandas as pd

# Third Party Library
import psycopg2
from sqlalchemy import create_engine
#from config import PGSQL_CONF

PGSQL_CONF = {
  "user": "caliper_su",
  "password":"caliper$123",
  "host":"vau-lda-016",
  "db":"caliper",
  "Port" : "5432"
}

class Connector:
    """
    1. Create engine connection to postgres.
    2. Create raw connection to Postgres.
    """

    
    @classmethod
    def get_engine(cls):
        """Create an engine connection to Postgres."""
        try:
          print("PGSQL_CONF: ", PGSQL_CONF)
#          db_connection_url = "postgresql+psycopg2://" + PGSQL_CONF["user"] + ":" + PGSQL_CONF["password"] + "@" + PGSQL_CONF["host"] + ":" + PGSQL_CONF["Port"] + "/" + PGSQL_CONF["db"]
          db_connection_url = "postgresql+psycopg2://{}:{}@{}:{}/{}".format(
              PGSQL_CONF["user"],
              PGSQL_CONF["password"],
              PGSQL_CONF["host"],
              PGSQL_CONF["Port"],
              PGSQL_CONF["db"]
          )
          print("URL: ", db_connection_url)
          engine = create_engine(db_connection_url)
        except Exception as e:
          raise ConnectionError(e)
        return engine
    
    @classmethod
    def create_connection(cls):
      """Create a raw connection to Postgres."""
      try:
        engine = cls.get_engine()
        conn = engine.raw_connection()
        
      except Exception as e:
        raise ConnectionError(e)
      
      return conn