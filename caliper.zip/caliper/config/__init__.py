# coding: utf-8

"""Configuration Module

Pulls Configuration.
"""

__author__ = ["Divya Shankar","Samuel Joshua","Srither Ranjan"]
__version__ = 1.0

# Standard Library
from os import path

# Application Specific Library
from ._postgres_cons import PG_DEV

PGSQL_CONF = PG_DEV