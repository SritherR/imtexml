from fastapi import FastAPI
from database import Connector
from fastapi.middleware.cors import CORSMiddleware
from typing import Optional
from fastapi import FastAPI, Query
from pydantic import BaseModel
from typing import List, Optional
import requests
import json
from fastapi.responses import JSONResponse
import io
from fastapi.exceptions import HTTPException
#from fastapi import  HTTPException
import os
import os.path
from pytz import timezone
import pytz 
import jwt
from datetime import datetime
import threading
from fastapi import Request
import pandas as pd

import time
import uuid
import base64
import re
#from PIL import Image
#import PIL.Image as Image
import multiprocessing
from multiprocessing import Pool
# Application Specific Library
from utils import caliperApiHelper
app = FastAPI()

"""

@app.middleware("http")
async def validate_authenticity(request: Request, call_next):
  authorization = ''
  try:
 <F3><F6>   authorization = request.headers.get("Authorization")
    if authorization is None:
      raise HTTPException(status_code=404)
  except Exception as e:
    return (HTTPException(status_code=404))

    #return {"status":"error","message":"Authorization token is not passed"}
  #return await call_next(request)
  #return await call_next(request)
  
"""

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

class Caliper_project(BaseModel):
    algo_id: str
    job_id: str
    demo_id: str
    image: int
    image_name: str
    imageObject: str
    inputs: dict
    user_id:str
    uuid:str

def verify_token(token):
  try:
    token = token.split(' ')[1]
    decoded = jwt.decode(token, options={"verify_signature": False})
    user_id = decoded['userid']
    if "mail" in decoded.keys():    
      email_id = decoded['mail']
    else:
      email_id = decoded['email']     
    first_name = decoded['firstname']
    last_name = decoded['lastname']
    user_name = decoded['displayName']
    print("\n\nuser name is", user_name)
    print(decoded)
    return {"status":"success","userid":user_id,"emailid":email_id,"firstname":first_name,"lastname":last_name, "username": user_name}
  except Exception as e:
    return {"status":"error"}
   

def almanac_verify_token(token):
  try:
    token = token.split(' ')[1]
    decoded = jwt.decode(token, options={"verify_signature": False})
    if "mail" in decoded.keys():    
      email_id = decoded['mail']
    else:
      email_id = decoded['email']
    print("Almanac Token : ", decoded)
    return {"status":"success","emailid":email_id}
  except Exception as e:
    return {"status":"error"}

 
def verify_xlims(token):
  try:
    decode_token = jwt.decode(token,options={"verify_signature": False})
    timestamp = decode_token['exp']
    dt_object = datetime.fromtimestamp(timestamp)
    server_timezone = timezone("US/Pacific")
    date = server_timezone.localize(dt_object)
    date = dt_object.astimezone(server_timezone)
    dt_object = date
    dt_object=dt_object.strftime("%Y-%m-%d %H:%M:%S")
    now= datetime.now()
    now=now.strftime("%Y-%m-%d %H:%M:%S")
    print(dt_object,now,"times")
    if dt_object > now:
      return {"status":"success"}
    else:
      return {"status":"error"}
  except:
    return {"status":"error"}
      
#get job id api
@app.post("/api/v1/jobs/")
async def get_job_id(request:Request):
    header_info  = request.headers.get("Authorization")
    token_status = verify_token(header_info)
    if token_status['status'] == 'success':
      response_list = list()
      try:
        job_list = await request.json()
      except Exception as e:
        raise HTTPException(400,detail = 'Bad Request') 
      print("job_list",job_list)
      if len(job_list) != 0:
        for i in job_list:
          response = caliperApiHelper.get_job_id_status(i)
          response_list.extend(response)
        return response_list
      else:
        raise HTTPException(400,detail = "Bad Request")
    else:
      raise HTTPException(401, detail="Invalid Authorization Token")


#get multiple uuid image measurement api
@app.post("/api/v1/image_measure_uuid/")
async def get_uuid_id_list(request:Request):
    header_info  = request.headers.get("Authorization")
    token_status = verify_token(header_info)
    if token_status['status'] == 'success':

      response_list = list()
      try:
        req = await request.json()
      except Exception as e:
        raise HTTPException(400,detail = 'Bad Request')
      if len(req)!=0:
        for i in req:
          try:
            response = caliperApiHelper.get_image_measure_multi_uuid(i['uuid'])
          except Exception as e:
            raise HTTPException(400,detail = 'Bad Request:Getting empty dictionary request')

          response_list.append(response)
        return response_list
      else:
        raise HTTPException(400,detail = 'Bad Request')
    else:
      raise HTTPException(401, detail="Invalid Authorization Token")


# API 4: get image measurement api
@app.get("/api/v1/image_measurement/{uuid}")
def read_image_measurement(uuid:str, request:Request):
    header_info  = request.headers.get("Authorization")
    token_status = verify_token(header_info)
    if token_status['status'] == 'success':
      response = caliperApiHelper.get_measurements_pickle_file(uuid)
      if "error" in response.keys():
        raise HTTPException(500,detail =response['error'])
      return response
    else:
      raise HTTPException(401, detail="Invalid Authorization Token")
  
#API 3: get image measurement status api
@app.post("/api/v1/measured_image_status/")
async def measured_image_status(request : Request):
    header_info  = request.headers.get("Authorization")
    token_status = verify_token(header_info)
    if token_status['status'] == 'success':
      try:
        req=await request.json()
      except Exception as e:
        raise HTTPException(400,detail = 'Bad Request')
      print("req",req)
      response_list = list()
      if len(req)!=0:
        
        for i in req:
          try:
            response = caliperApiHelper.get_image_status(i["uuid"])
          except Exception as e:
            raise HTTPException(400,detail = 'Bad Request:Getting empty dictionary request')

          response_list.append(response)
        return response_list
      else:
        raise HTTPException(400,detail = 'Bad Request')

    else:
      raise HTTPException(401, detail="Invalid Authorization Token")
  

# API 6: get algo details for a user
#get user id api
@app.get("/api/v1/algos/")
def get_user_id(request: Request):
  header_info  = request.headers.get("Authorization")
  print("header_info",header_info)
  token_status = verify_token(header_info)
  if token_status['status'] == 'success':
    email_id = token_status['emailid']
    response = caliperApiHelper.match_user_algo(email_id)
    return response
  else:
    raise HTTPException(401, detail="Invalid Authorization Token")
 
def changing_status(uuid):
  test_connection = None
  try:
      test_connection = Connector.create_connection()     
      engine = Connector.get_engine()
      cursor = test_connection.cursor()
      sql=f"UPDATE caliper.job_run set status= 'pending',error=null where uuid='{uuid}'"
      cursor.execute(sql)
      print("changed status to inprogress")
      test_connection.commit()
  except Exception as e:
    raise e
  finally:
    if test_connection:
      test_connection.close()

#TODO: Make common function
def change_status_to_cancel(uuid):
  test_connection = None
  try:
      print("stop measure started")
      test_connection = Connector.create_connection()     
      engine = Connector.get_engine()
      cursor = test_connection.cursor()
      df_uuid = pd.read_sql(f"SELECT status FROM caliper.job_run WHERE uuid='{uuid}'",test_connection)
      print(df_uuid)
      df_uuid=df_uuid.to_dict('r')
      print(df_uuid,"dict")
      print(df_uuid,"************************")
      if 'in progress' not in df_uuid[0]['status']:
        sql=f"UPDATE caliper.job_run set status= 'canceled',error=null where uuid='{uuid}'"
      cursor.execute(sql)
      print("changed status to Canceled")
      test_connection.commit()
  except Exception as e:
    print(str(e),"except")
    raise e
  finally:
    if test_connection:
      test_connection.close()

def multi_process_post_method(caliper_json):
  print("called multi process method")
  response_dict=dict()
  record = caliper_json['request']
  user_name = record['user_name'].replace(" ", "_")
  path = r"/application/code/caliper/user_measure_request/"+user_name+".txt"
  file_exists = os.path.exists(path)
  print("File status -------", file_exists)
  if file_exists:
    del caliper_json['request']['user_name']
    r = requests.post(url='https://modelservice.tcdsw.amat.com/model', json=caliper_json, headers={'Content-Type': 'application/json'},verify=False)
    print(r,"res",r.text)

    if r.status_code == 200:
      r = r.json()
      print(r,"response message")
      print(r["response"])
      if r['response']['status']=='success':
        response_dict["uuid"]=r['response']['uuid']
        response_dict["imagename"]=record["image_name"]
        response_dict["imageid"]=record["image"]
      else:
        error_res = r['response']['message']
        print(error_res,"else")
        raise HTTPException(status_code=401, detail=error_res)
    else:
      raise HTTPException(500, detail="error")
    return response_dict
    print("Calling Cloudera Measure Model...")
 # else:
 #   print("Ignoring post", caliper_json['request']['uuid'])
 #   change_status_to_cancel(caliper_json['request']['uuid'])
  

def update_nasimage_status(msg,uuid):
  test_connection = None
  try:
    test_connection = Connector.create_connection() 
    engine = Connector.get_engine()
    cursor = test_connection.cursor()
    sql=f"UPDATE caliper.job_run set nas_image_status= {msg}  where uuid='{uuid}'"
    cursor.execute(sql)
    print(sql,"--------------------")
    print("changed nas image status")
    test_connection.commit()
  except Exception as e:
    raise e
  finally:
    if test_connection:
      test_connection.close()

@app.api_route("/api/v1/measure/", methods = ["PUT","POST"])
async def update_item(request: Request):
    header_info  = request.headers.get("Authorization")
    print(header_info)
    token_status = verify_token(header_info)
    print(token_status,"-----------------")
    if token_status['status'] == 'success':
      response = dict()
      item=await request.json()
      measure_api_required_keys = {'algo_id','job_id','demo_id','image','image_name','imageObject','inputs','user_id','uuid','measured'}
      result = list()
      source_path_dev = "/var/lib/cdsw/calip-nas-dev/"
      nas_upload_image = source_path_dev + "imgs/upload_image/"

      if request.method == "PUT":
        for record in item:
          img_name = record["image_name"]
          tmp_imgname, tmp_imgext = os.path.splitext(img_name)
          temp_img_name = re.sub(r'[^a-zA-Z0-9-. ]','_',tmp_imgname)
          if record['image']==None:
            temp_image_name = temp_img_name  + tmp_imgext
          else:
            temp_image_name = str(record['image']) + "_" + temp_img_name + tmp_imgext
            record['image_name'] = temp_image_name
          img_name = temp_image_name

          if len(set(record.keys())) == len(measure_api_required_keys):

            if record["uuid"]=="":
              value = str(uuid.uuid4())
              record["uuid"]=value
            if record['imageObject']!="":
              enc_image = record['imageObject']
              enc_image = enc_image[enc_image.find(',')+1:]
              image_path = os.path.join(nas_upload_image,temp_image_name)
              print("image_path put:",image_path)
              try:
                decodeit = open(image_path, 'wb+')
                decodeit.write(base64.b64decode((enc_image)))
                decodeit.close()
                print("file saved in NAS")
                #psh_data = ns.push_data([temp_image_name], nas_upload_image , loc_image_path)
                #print("file pushed to nasapi successfully",psh_data)
              except:
                print("nasapi error local path")
                record['imageObject'] = temp_image_name 
  
                #print(record)
            #TO-DO: 1. insert_job_run_table has to be updated. If a UUID already exists, subsequent put requests should update the existing record
            nas_image_list = os.listdir(nas_upload_image)
            print("img_name",img_name)
            if img_name in nas_image_list:
              nas_image_present = True
            else:
              nas_image_present = False
            #response=caliperApiHelper.insert_job_run_table(record,nas_image_present)
            response=caliperApiHelper.insert_job_run_table(record,nas_image_present, token_status['username'])
            print(response)
            if "uuid" not in list(response.keys()):
              raise HTTPException(500, detail=response["message"])
            result.append(response)


          elif len(set(record.keys()))  > len(measure_api_required_keys):
            missing_keys = set(record.keys()).difference(measure_api_required_keys) 
            return { "Key Error":f"invalid key {missing_keys}"}
          else:
            missing_keys = measure_api_required_keys.difference(set(record.keys()))
            return { "Key Error":f"Missing Keys {missing_keys}"}

        return result
      elif request.method == "POST":
        processes = []
        pool=Pool(processes=5) 
        thread_list = list()
        thread_result = list()
        x_limstoken = request.headers.get("X-LimsToken")
        
        for record in item:
          response_dict = {}
                  
          if record['imageObject']!="":
            return {"error":f"image is not stored in db in put call for this {record['uuid']} uuid"}
          record["x_limstoken"]=x_limstoken
          record['user_name']= token_status['username']
          response_dict['uuid'] =  record['uuid']
          response_dict['status'] = "in progress"
          print(record['uuid'],"uuidd------------------------------")
          thread_result.append(response_dict)         
          caliper_json = {"accessKey":"m3qokgd1w693gv0kep9y50agzvo8ji3n","request":record}
          thread_list.append(caliper_json)
        for i in thread_result:
          changing_status(i['uuid'])
        print("----- HIt Thraed -----")
        def method_thread():
          print("-- method thread ----")
          user_name = token_status['username'].replace(" ", "_")
          path = r"/application/code/caliper/user_measure_request/"+user_name+".txt"
          print("path loc", path)
          f =open(path, 'w')
          f.close()
          print("File created")

          try:
            for i in range(0,len(thread_list),2):
              with multiprocessing.Pool(processes=5) as pool: 
                pool.map(multi_process_post_method,thread_list[i:i+2])
          finally:
            path = r"/application/code/caliper/user_measure_request/"+user_name+".txt"
            os.remove(path)
        t = threading.Thread(target=method_thread)
        t.start()
       
        return thread_result
    
    else:
      raise HTTPException(401, detail="Invalid Authorization Token")

@app.post("/api/v1/summary_statistics/")
async def read_summary_statistics(request: Request):
    header_info  = request.headers.get("Authorization")
    token_status = verify_token(header_info)
    if token_status['status'] == 'success':
      response_list = list()
      try:
        req = await request.json()
      except Exception as e:
        raise HTTPException(400,detail = 'Bad Request')
      print(req,"req")
      if len(req)!=0:
        for i in req:
           
            response = caliperApiHelper.get_summary_statistics(i["uuid"])
            response_list.append(response)
        return response_list
      else:
        raise HTTPException(400,detail = 'Bad Request')

    else:
      raise HTTPException(401, detail="Invalid Authorization Token")
        
@app.post("/api/v1/auto_pixel_calc/")
async def read_auto_pixel(request: Request):
    start_pixel_time = datetime.now() 
    header_info  = request.headers.get("Authorization")
    response_list = list() 
    start = time.time()
    token_status = verify_token(header_info)
    print("toen verify",time.time() - start)
    if token_status['status'] == 'success':
      response_list = list()
      start = datetime.now()
      req = await request.json()
      print("input process time",datetime.now()-start)
      x_limstoken = request.headers.get('X-LimsToken')
      #lims_status = verify_xlims(x_limstoken)
      #if lims_status['status']=='error':
        #raise HTTPException(401, detail="Invalid xlims token")
      req['X-LimsToken'] = x_limstoken 
      #print(req,"request")
      
      if req['image_obj']!="":
        enc_image = req['image_obj']
        enc_image = enc_image[enc_image.find(',')+1:]
        img_name = req['image_name']
        tmp_imgname, tmp_imgext = os.path.splitext(img_name)
        temp_img_name = re.sub(r'[^a-zA-Z0-9-. ]','_',tmp_imgname)
        if req["image_id"]==None:
          temp_image_name = temp_img_name  + tmp_imgext
        else:
          temp_image_name = str(req['image_id']) + "_" + temp_img_name + tmp_imgext
          req['image_name'] = temp_image_name
        img_name = temp_image_name
        source_path_dev = "/var/lib/cdsw/calip-nas-dev/"
        nas_upload_image = source_path_dev + "imgs/upload_image/"
        #loc_image_path = r"/application/code/caliper/upload_image/"
        image_path = os.path.join(nas_upload_image,temp_image_name)
        print("image_path put:",image_path)
        try:
          decodeit = open(image_path, 'wb+')
          decodeit.write(base64.b64decode((enc_image)))
          decodeit.close()
          print("file saved in local")
          req['image_obj']=""
          #psh_data = ns.push_data([temp_image_name], nas_upload_image , loc_image_path)
          #print("file pushed to nasapi successfully",psh_data)
        except:
          print("nasapi error local path")
          return {"error":"nas api path"}
      
      start = time.time()
      response = caliperApiHelper.get_auto_pixel(req)
      print("total time taken for model",time.time()-start)
      print(response,"res--")
      print("overall api time",datetime.now()-start_pixel_time)
      if response['response']['errorcode']==200:
        response_list.append(response)
        return response_list
      elif response['response']['errorcode']==401:
        raise HTTPException(401,detail=response['response'])
      elif response['response']['errorcode']==401:
        raise HTTPException(420,detail=response['response'])
      else:
        d = dict()
        d['pixelsize'] = -1
        d['pixelsizeunits'] = 'nm'
        d['scalebarval'] = -1
        d['scalebarunits'] = 'um'
        d['startx'] = -1
        d['endx'] = -1
        d['starty'] = -1
        d['endy'] = -1
        d['errorcode'] = 500
        d['errorcodeexplanation'] = 'Auto Pixel Size Calculation'
        raise HTTPException(500,detail = d)

    else:
      raise HTTPException(401, detail="Invalid Authorization Token")

@app.post("/api/v1/measure_request_form/")
async def read_measure_form(request: Request):
    header_info  = request.headers.get("Authorization")
    token_status = verify_token(header_info)
    if token_status['status'] == 'success':

      response_list = list()
      req = await request.form()
     
      print(req,"request")
      response = caliperApiHelper.measure_request_form(req)
      print(response,"response")
      #print(response,"res--")
      #response_list.append(response)
      if response['status'] == "success":
        return response
      else:
        raise HTTPException(500, detail="Request not sent")
     
    else:
      raise HTTPException(401, detail="Invalid Authorization Token")

@app.post("/api/v1/feedback_form/")
async def read_feedback_form(request: Request):
    header_info  = request.headers.get("Authorization")
    token_status = verify_token(header_info)
    if token_status['status'] == 'success':

      response_list = list()
      req = await request.form()
      x_limstoken = request.headers.get("X-LimsToken")  
      #print(req,"request")
      fullname = token_status['firstname'] +" "+ token_status['lastname']
      print(fullname)
      response = caliperApiHelper.feedback_form(req,x_limstoken)
      print(response,"response")
      #print(response,"res--")
      #response_list.append(response)
      if response['status']== "success":
        return response
      else:
        raise HTTPException(500, detail="Feedback not sent properly.")
   

    else:
      raise HTTPException(401, detail="Invalid Authorization Token")

@app.post("/api/v1/request_access_form/")
async def request_access(request: Request):
    header_info  = request.headers.get("Authorization")
    token_status = verify_token(header_info)
    if token_status['status'] == 'success':
      response_list = list()
      req = await request.json()
     
      print(req,"request")
      response = caliperApiHelper.request_access_form(req)
      print(response,"response")
      #print(response,"res--")
      #response_list.append(response)
      if response['status'] == "success":
        return response
      else:
        raise HTTPException(500, detail="Error with mail service. Please try again after 5 minutes, or reach out directly to the Caliper team at Caliper@amat.com..")
     
    else:
      raise HTTPException(401, detail="Invalid Authorization Token")


@app.post("/api/v1/image_name_list/")
async def images_list(request: Request):
    header_info  = request.headers.get("Authorization")
    token_status = verify_token(header_info)
    response_list = []
    print(token_status)
    if token_status['status'] == 'success':
      try:
        req = await request.json()
      except Exception as e:
        raise HTTPException(400,detail = 'Bad Request')

      print(req,"req------")
      if len(req)!=0:
        print(req,"request")
        for i in req:
          response = caliperApiHelper.images_name_list(i['image_name'])
          response_list.extend(response)
        return response_list
      else:
        raise HTTPException(400,detail = 'Bad Request')
    else:
      raise HTTPException(401, detail="Invalid Authorization Token")


@app.post("/api/v1/algo_list/")
async def algorithm_list(request: Request):
    header_info  = request.headers.get("Authorization")
    token_status = verify_token(header_info)
    response_list = []
    print(token_status)
    if token_status['status'] == 'success':
      try:
        response = caliperApiHelper.algo_list(token_status['emailid'])
        return response
      except:
        raise HTTPException(500, detail="algo list unable to load")

     
    else:
      raise HTTPException(401, detail="Invalid Authorization Token")

@app.get("/api/v1/almanac/{demo_id}")
async def almanac_list(demo_id:str,request: Request):
    header_info  = request.headers.get("Authorization")
    token_status = almanac_verify_token(header_info)
    response_list = []
    print(token_status)
    if token_status['status'] == 'success':
     
        response = caliperApiHelper.almanac_api_list(demo_id,token_status['emailid'])
        print(response)
        if "data" in response.keys():
          return response
        else:
          raise HTTPException(500,detail=response['error'])
    else:
      raise HTTPException(401, detail="Invalid Authorization Token")

@app.post("/api/v1/algo_list_almanac/")
async def algo_listalmanac(request: Request):
    header_info  = request.headers.get("Authorization")
    token_status = almanac_verify_token(header_info)
    response_list = []
    print(token_status)
    if token_status['status'] == 'success':
      req = await request.json()
      demo_id = req['demo_id']
      try:
        print(demo_id,"demoid------")
        response = caliperApiHelper.almanac_algo_list(demo_id,token_status['emailid'])
        print(response)
        return response
      except:
        raise HTTPException(500, detail="algo list unable to load")
    else:
      raise HTTPException(401, detail="Invalid Authorization Token")

@app.post("/api/v1/edit_measurement/")
async def measure_edit(request: Request):
    header_info  = request.headers.get("Authorization")

    token_status = almanac_verify_token(header_info)
    response_list = []
    print(token_status)
    if token_status['status'] == 'success':
      req = await request.json()
     
      response = caliperApiHelper.edit_measurement(req)
      print(response)
      if "error" not in response.keys():
        return response
      else:
        raise HTTPException(500, detail="Algorithm Not Supported for Editable Measurements")

    else:
      raise HTTPException(401, detail="Invalid Authorization Token")

@app.post("/api/v1/stop_measure/")
async def stop_measure_process(request: Request):
   
    print("-------------- STOP Measurements ----------------------")
    header_info  = request.headers.get("Authorization")
    print(header_info)
    token_status = verify_token(header_info)
    if token_status['status'] == 'success':
      try: 
        user_name = token_status['username']
        print("----user name is", user_name)
        path = r"/application/code/caliper/user_measure_request/"+user_name.replace(" ", "_")+".txt"
        os.remove(path)
        print("Remove User File :  Success ", user_name.replace(" ", "_"), ".txt")
        req = await request.json()
        print(req,"-----")
        for item in req:
          print("item", item)
          change_status_to_cancel(item['uuid'])
        return {'status' : True, 'msg':'Measurement requested has stopped succesfully'}
      except:
        raise HTTPException(500,detail = "failed in stop measure")
    else:
      raise HTTPException(401, detail="Invalid Authorization Token")



@app.post("/api/v1/manual_measure/")
async def manual_measure_process(request: Request):
  
    print("-------------- Manual Measurements ----------------------")
    header_info  = request.headers.get("Authorization")
    print(header_info)
    token_status = verify_token(header_info)
    if token_status['status'] == 'success':
      req = await request.json()   
      user_email = token_status['emailid']
      value = str(uuid.uuid4())
      req["uuid"]=value
      print(req)
      response = caliperApiHelper.post_manual_measure(req,user_email)
      if "status" in response.keys():
    
        print(response,"res")
        return response
      else:
        raise HTTPException(401, detail="Manual Measurement Failed")
    else:
      raise HTTPException(401, detail="Invalid Authorization Token")



@app.get("/api/v1/get_manual_measure/")
async def manual_measure_get(demo_id:str,request:Request):

    print("-------------- Manual Measurements ----------------------")
    header_info  = request.headers.get("Authorization")
    print(header_info)
    token_status = verify_token(header_info)
    if token_status['status'] == 'success':

      user_email = token_status['emailid']

      #req = await request.json()
      #print(req)
      response = caliperApiHelper.get_manual_measure(demo_id,user_email)
      return response
    else:
      raise HTTPException(401, detail="Invalid Authorization Token")

@app.post("/api/v1/put_manual_measurement/")
async def manual_measure_post(request: Request):
    header_info  = request.headers.get("Authorization")
    print(header_info)
    token_status = verify_token(header_info)
    print(token_status,"-----------------")
    if token_status['status'] == 'success':
        req = await request.json()
        response = caliperApiHelper.put_manual_measure(req)
        if 'uuid' in response.keys():
            return response
        else:
            raise HTTPException(500,detail = response['error'])
    else:
        raise HTTPException(401, detail = "Invalid Authorization Token")






