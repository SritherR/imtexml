import numpy as np
import pandas as pd


def edit_measure(msmts, summ_stats, linemarkings, pixel_size):
    try:
      
        edited_msmts = msmts.copy()

        # set up hashmap so easy to find msmst you're looking for
        msmt_positions = {elem["Name"]: i for i, elem in enumerate(msmts)}

        ss_df = pd.DataFrame(summ_stats)

        horiz_msmts = ["Bow CD [nm]", "Pinch CD [nm]", "Top CD [nm]", "Bottom CD [nm]"]

        #print("----- iterating through linemarkings")
        for lm_attribute in linemarkings:
            msmt_attribute = lm_attribute["Measurement"]

            # some linemarkings come from summary and don't have their own msmt attribute - skip these (uneditable)
            if not msmt_attribute in msmt_positions:
                continue

            #print("------- Adjusting measurements for", msmt_attribute)

            msmt_index = msmt_positions[msmt_attribute]

            original_msmts = msmts[msmt_index]["Value"].copy()

            for idx, lm in enumerate(lm_attribute["Linemarkings"]):
                pts = lm["Points"]

                # edited flag not currently present in linemarkings, but if its there, you can uncomment the following
                #if "Edited" in lm:

                ## IF MASK HEIGHT OR DEPTH, consider only vertical distance
                ## IF BOW CD or PINCH CD, consider only horizontal distance
                ## all other linemarkings are not editable here - skip

                # also need to filter out units ( [nm], [nm^2] )
                if msmt_attribute in horiz_msmts:
                    # calc horizontal distance
                    new_msmt = pts[2]-pts[0]
                    original_msmts[idx] = round(new_msmt * pixel_size, 5)
                elif (msmt_attribute == "Depth [nm]") or (msmt_attribute == "Mask Height [nm]"):
                    new_msmt = pts[3] - pts[1]
                    original_msmts[idx] = round(new_msmt * pixel_size, 5)

            edited_msmts[msmt_index] = {"Name": msmt_attribute, "Value": original_msmts}

            #print("--------- summarizing for", msmt_attribute)

            # update summ stats for this variable
            summ_rows = ss_df[ss_df.Summarized_Measurement == msmt_attribute]
            for index, row in summ_rows.iterrows():
                name = row['Name']
                if 'Average' in name:
                    new_avg = np.mean(original_msmts)

                    ss_df.loc[index, 'Value'] = round(new_avg, 5)

        #print("--- converting summary to list of dictionaries")
        edited_summ_stats = ss_df.to_dict('records')

        return edited_msmts, edited_summ_stats, (200,'success')
    except:
        return  -1, -1, (500, "Error Editing Measurement Values.")
