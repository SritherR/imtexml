import pickle

from edit_measurements.edit_dl_xsem import edit_measure as xsem
from edit_measurements.edit_full_xsem_classical import edit_measure as fxsem_classical

def edit_measure(algo_name, msmts, summ_stats, linemarkings, pixel_size):
    if (algo_name == "Full XSEM") or (algo_name == "High Mag XSEM Top") or \
            (algo_name == "High Mag XSEM Middle") or (algo_name == "High Mag XSEM Bottom"):

        # All Deep Learning XSEM Cases share measurement attribute names, the High Mag cases do not have all
        # measurements, but these can be skipped over through code

        print("---Editing for Deep Learning XSEM Case")
        edited_msmts, edited_summ_stats, edited_lm = xsem(msmts, summ_stats, linemarkings, pixel_size)
        return edited_msmts, edited_summ_stats, (200, "Success")

    elif algo_name == "Full XSEM Classical":
        print("---Editing for Full XSEM")
        edited_msmts, edited_summ_stats, edited_lm = fxsem_classical(msmts, summ_stats, linemarkings, pixel_size)
        return edited_msmts, edited_summ_stats, (200, "Success")
    else:
        return -1, -1, (500, "Algorithm Not Supported for Editable Measurements")
     

# if __name__ == "__main__":
#    data_root = "../edit_data_for_testing/"
#    with open(data_root+"19_linemarkings.pickle", "rb") as f:
#        sample_linemarkings = pickle.load(f)
#    with open(data_root+"19_msmts.pickle", "rb") as f:
#        sample_msmts = pickle.load(f)
#    with open(data_root+"19_summstats.pickle", "rb") as f:
#        sample_summ_stats = pickle.load(f)
#
#    pixel_size = 0.5291005291005291
#    for i,elem in enumerate(sample_msmts):
#        print(i, elem['Name'])
#
#
#    # change the depth CD first 2 measurements so linemarkings will be adjusted
#    sample_msmts[9]['Value'][0] = 75
#    sample_msmts[9]['Value'][1] = 75
#
#     # depth is 15th in summ stats list
#    sample_summ_stats[15]['Value'] = 75
#
#    print("BEFORE EDITING----------------")
#    print("Measurements")
#    print(sample_msmts)
#    print("\n")
#    print("Summ Stats")
#    print(sample_summ_stats)
#    print("\n")
#
#    E_M, E_S, err = edit_measure("Full XSEM", sample_msmts, sample_summ_stats, sample_linemarkings, pixel_size)
#
#    print("AFTER EDITING----------------")
#    print("Measurements")
#    print(E_M)
#    print("\n")
#    print("Summ Stats")
#    print(E_S)
#    print("\n")
#    print("Error code + message")
#    print(err)
