nohup uvicorn api.caliper_apis.jobid_api:app --reload --host 0.0.0.0 --port 3098 &
nohup uvicorn api.caliper_apis.measure_image_api:app --reload --host 0.0.0.0 --port 3099 &
nohup uvicorn api.caliper_apis.image_measurement_details_api:app --reload --host 0.0.0.0 --port 3092 &
nohup uvicorn api.caliper_apis.image_summary_statistics_api:app --reload --host 0.0.0.0 --port 3093 &
nohup uvicorn api.caliper_apis.measured_image_status_api:app --reload --host 0.0.0.0 --port 3094 &
nohup uvicorn api.caliper_apis.algo_config_details_api:app --reload --host 0.0.0.0 --port 3095 &
nohup uvicorn api.caliper_apis.auto_pixel_size_api:app --reload --host 0.0.0.0 --port 3096 &
nohup uvicorn api.caliper_apis.image_measure_multiuuid_api:app --reload --host 0.0.0.0 --port 3097 &
