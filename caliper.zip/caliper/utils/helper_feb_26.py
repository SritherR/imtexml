# coding: utf-8

"""
  Helper Module: Obtains information from caliper db

  Classes
  --------
  ImageProcessor: Calls helper functions needed to retrieve information from caliper db

"""

__author__ = ["Divya Shankar", "Samuel Joshua", "Srither Ranjan"]
__version__ = 1.0

 # Standard Library
import warnings
import datetime
import json
import uuid
from uuid import uuid4
# Third Party Library
import pandas as pd
import requests
# Application Specific Library
from database import Connector 

import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase

from email.mime.application import MIMEApplication
class caliperApiHelper():
  
  """
    Calls helper functions needed to retrieve information from caliper db
  """
  
  @classmethod
  def match_user_algo(cls, email_id):

    """
      For a given email_id, this function will return algo_id's user has access to and corresponding algorithm names

      Parameters
      -----------
      email_id: Accepts email_id for which we need the algo_id accessible by the email_id

      Returns
      --------
      user_algo_dict: Dictionary of email_id & algorithms 
                              {
                               'email_id':'values',
                               'algos': [{algo_id, algo_name, config_params}, {algo_id, algo_name, config_params}]
                              }

    """
    test_connection = None
    try:
      test_connection = Connector.create_connection()        
      df_user = pd.read_sql("SELECT * FROM caliper.user_algo WHERE email_id = '" + email_id + "'",test_connection)
      if df_user.shape[0] == 0:
          return {"Error","No record found for given email_id in user_algo table"}

      else:
          print("Found record for given email_id")

          # Group by user_id and get the list of algo_id which the user_id has access to
          df_match_user_algo = df_user.groupby('email_id')['algo_id'].apply(list).reset_index(name='algo_id_accessible')

          # Convert the groupby dataframe to dictionary: {'user_id':'x...','algos_accessible':[algo_id]}
          match_user_algo_record = df_match_user_algo.to_dict('r')[0]
          print(match_user_algo_record)

          # Extract values (algo_id) for key 'algos_accessible'
          algo_id_lst = match_user_algo_record['algo_id_accessible']
          print("algo_id_list",algo_id_lst)
          if len(algo_id_lst)==1:
            algo_id_lst = algo_id_lst+algo_id_lst 
          # Call get_algo_name to get name of algorithms in algo_lst
          algo_info_record = cls.get_algo_info(algo_id_lst)

          """
            RETURN THE FOLLOWING

            {
             "user_id": "x010768",
             "algos": [{algo_id, algo_name, config_params}, {algo_id, algo_name, config_params}]
            }

          """

          user_algo_info_dict = dict({'email_id':email_id,'algos':algo_info_record})

          return user_algo_info_dict

    except Exception as e:
      raise e

    finally:
      if test_connection:
        test_connection.close()
        
  @classmethod
  def get_algo_info(cls, algo_lst):
    """
      For a given list of algo_id's, it will return corresponding algo_names

      Parameters
      -----------
      algo_lst: List of algo_id

      Returns
      --------
      algo_names_record: List of dictionaries for algorithm info such as [{algo_id, algo_name, config_params}, 
                                                                      {algo_id, algo_name, config_params}]

    """

    len_algo_lst = len(algo_lst)
    test_connection = None

    if len_algo_lst == 0:
      return{"Error":"Invalid Input!"}

    else:

      try:
        test_connection = Connector.create_connection()

        # To pass a list to SQL Query it has to be in (1,2,3,4,5) format, not [1,2,3,4,5]
        temp_algo_lst = tuple(algo_lst)
        print(temp_algo_lst,'temp_algo_lst')
        df_algo = pd.read_sql(f"SELECT algo_id, algo_name, config_params, required_inputs FROM caliper.algo WHERE algo_id IN {temp_algo_lst}",test_connection)

        if df_algo.shape[0] == 0:
            return{"Error","No record found for given algo_id in algo table"}

        else:
            print("Found record for given algo_id")

            # Storing  algo_id, algo_name, and config_params in a list of dictionaries

            df_algo['config_params'] = df_algo['config_params'].astype(str)
            df_algo['config_params'] = df_algo['config_params'].str.replace("'", '"')
            df_algo['config_params'] = df_algo['config_params'].apply(lambda x: json.loads(x))
            algo_names_record = df_algo.to_dict(orient='records')
        return algo_names_record

      except Exception as e:
        raise e

      finally:
        if test_connection:
          test_connection.close()

  """
  @classmethod
  def insert_job_run_table(cls,record):
      print("called job run table")
      test_connection = None
      try:
          test_connection = Connector.create_connection()
          engine = Connector.get_engine()
          cursor = test_connection.cursor()
         
          algo_id = record.algo_id
          job_id = str(record.job_id)
          demo_id = record.demo_id
          image_id = record.image
          image_name = record.image_name
          bounding_box = record.inputs["bounding_box"]
          pixel_size = record.inputs["pixel_size"]
          uuid = str(record.uuid)
          sql = f"INSERT INTO caliper.job_run (uuid,job_id,demo_id,image_filename,image_id,algo_id,binary_op,rotation_angle,bounding_box,pixel_size,output_binary_values,config,start_ts, end_ts,error,sample_id, measurements_file,status,measurements) VALUES ('{uuid}','{job_id}','{demo_id}',null,{image_id},{algo_id},null,null,'{bounding_box}',{pixel_size},null,null,null,null,null,null,null,null,null)"
          cursor.execute(sql)
          test_connection.commit()
          print("sql-----",sql)
          print("inserted")
          return ({"uuid":uuid,"imageName":image_name,"imageId":image_id})
      except Exception as e:
        raise e
      finally:


        if test_connection:
          test_connection.close()




  """



  @classmethod
  def insert_job_run_table(cls,record,nas_image):
      """
      Insert the details into job_run table
      
      Parameters:
      -------------
      Get the put and post method request and insert the record in to job run table.
      
      Returns:
      -------------
      Return the uuid, image name and image id as response
      """
      print("called job run table")
      test_connection = None
      try:
          test_connection = Connector.create_connection()
          engine = Connector.get_engine()
          cursor = test_connection.cursor()

          algo_id = record["algo_id"]
          job_id =  str(record["job_id"])
          job_id = job_id.strip()
          demo_id = record["demo_id"].strip()
          image_id = record["image"]
          image_name = record["image_name"].strip()
          image_name = image_name.strip()
         
          image_obj = record["imageObject"]
          bounding_box =json.dumps(record["inputs"]["bounding_box"],default=str)
          pixel_size = json.dumps(record["inputs"]["pixel_size"],default=str)
          rotation_angle = record["inputs"]["rotate"]
          uuid = record["uuid"].strip()
          config_param = record["inputs"]["config_param"].keys()
          #print(config_param,"----")
          db_uuid = pd.read_sql(f"SELECT uuid,job_id,demo_id,image_filename FROM caliper.job_run",test_connection)
          db_uuid_list=list(db_uuid['uuid'])
          db_job_id_list = list(db_uuid["job_id"])
          db_demo_id_list = list(db_uuid["demo_id"])
          db_image_name_list = list(db_uuid["image_filename"])
          print(image_id,"image_id")
          print(uuid,"uuid")
          if uuid == "":
            print("uuid is empty")
            de_uuid = uuid.uuid4()
            print(de_uuid)
            uuid = str(de_uuid)
          if image_id == None: 
            image_id = "null"
          if rotation_angle == None:
            rotation_angle = "null"
          if len(config_param)==0:
            #config_param = josn.dumps(record["inputs"]["config_param"],default=str)
            if algo_id!="":
              algo_record = pd.read_sql(f"select config_params from caliper.algo where algo_id = {algo_id}",test_connection)
              if algo_record.shape[0]== 0:
                config_param = {}
              else:
                config = algo_record.to_dict('r')[0]
                config_param = config["config_params"]
            else:
              config_param = {}     
              #f"UPDATE caliper.job_run set image_filename = '{result_list[4]}',output_binary_values= '{result_list[11]}',start_ts = '{result_list[13]}'
            config_param = json.dumps(config_param,default=str)
          else:
            config_param = json.dumps(record["inputs"]["config_param"],default=str)
          
          if uuid in db_uuid_list:
            uuid_status =  pd.read_sql(f"SELECT status from caliper.job_run where uuid='{uuid}'",test_connection)
            status = uuid_status.to_dict('r')[0]
            status = status["status"]    
            sql=f"UPDATE caliper.job_run set uuid = '{uuid}',job_id = '{job_id}',demo_id = '{demo_id}',image_filename = '{image_name}',image_id = {image_id},algo_id = '{algo_id}',rotation_angle = {rotation_angle},bounding_box = '{bounding_box}',pixel_size = '{pixel_size}',config = '{config_param}',status = '{status}',nas_image_status = {nas_image} where uuid='{uuid}'"
          
          elif (job_id in db_job_id_list) & (demo_id in db_demo_id_list) & (image_name in db_image_name_list):
            uuid_record = pd.read_sql(f"SELECT uuid from caliper.job_run where job_id='{job_id}' and demo_id = '{demo_id}' and image_filename = '{image_name}'",test_connection)
            if uuid_record.shape[0]!=0:
              uuid = uuid_record.to_dict('r')[0]
              uuid = uuid["uuid"]
              print("matched_uuid",uuid)  
              uuid_status =  pd.read_sql(f"SELECT status from caliper.job_run where uuid='{uuid}'",test_connection)
              status = uuid_status.to_dict('r')[0]
              status = status["status"]
             
              sql = f"UPDATE caliper.job_run set uuid = '{uuid}',job_id = '{job_id}',demo_id = '{demo_id}',image_filename = '{image_name}',image_id = {image_id},algo_id = '{algo_id}',rotation_angle = {rotation_angle},bounding_box = '{bounding_box}',pixel_size = '{pixel_size}',config = '{config_param}',status = '{status}',nas_image_status = {nas_image} where uuid='{uuid}'"
            else:
              sql = f"INSERT INTO caliper.job_run (uuid,job_id,demo_id,image_filename,image_id,algo_id,binary_op,rotation_angle,bounding_box,pixel_size,output_binary_values,config,start_ts, end_ts,error,sample_id, measurements_file,status,measurements,nas_image_status) VALUES ('{uuid}','{job_id}','{demo_id}','{image_name}',{image_id},'{algo_id}',null,{rotation_angle},'{bounding_box}','{pixel_size}',null,'{config_param}',null,null,null,null,null,'pending',null,{nas_image})"

          elif image_obj!="":
            status = "pending"
            if image_name in db_image_name_list:
              image_obj_uuid = pd.read_sql(f"SELECT uuid from caliper.job_run where image_filename = '{image_name}'",test_connection)
              uuid = image_obj_uuid.to_dict('r')[0]
              uuid = uuid['uuid']
              uuid_status =  pd.read_sql(f"SELECT status from caliper.job_run where uuid='{uuid}'",test_connection)
              status = uuid_status.to_dict('r')[0]
              status = status["status"]
              sql = f"UPDATE caliper.job_run set uuid = '{uuid}',job_id = '{job_id}',demo_id = '{demo_id}',image_filename = '{image_name}',image_id = {image_id},algo_id = '{algo_id}',rotation_angle = {rotation_angle},bounding_box = '{bounding_box}',pixel_size = '{pixel_size}',config = '{config_param}',status = '{status}',nas_image_status={nas_image} where image_filename='{image_name}'"
            else:
              sql = f"INSERT INTO caliper.job_run (uuid,job_id,demo_id,image_filename,image_id,algo_id,binary_op,rotation_angle,bounding_box,pixel_size,output_binary_values,config,start_ts, end_ts,error,sample_id, measurements_file,status,measurements,nas_image_status) VALUES ('{uuid}','{job_id}','{demo_id}','{image_name}',{image_id},'{algo_id}',null,{rotation_angle},'{bounding_box}','{pixel_size}',null,'{config_param}',null,null,null,null,null,'pending',null,{nas_image})"

          else:
            print("generated_uuid",uuid)
            sql = f"INSERT INTO caliper.job_run (uuid,job_id,demo_id,image_filename,image_id,algo_id,binary_op,rotation_angle,bounding_box,pixel_size,output_binary_values,config,start_ts, end_ts,error,sample_id, measurements_file,status,measurements,nas_image_status) VALUES ('{uuid}','{job_id}','{demo_id}','{image_name}',{image_id},'{algo_id}',null,{rotation_angle},'{bounding_box}','{pixel_size}',null,'{config_param}',null,null,null,null,null,'pending',null,{nas_image})"
          print("sql-----",sql)
          cursor.execute(sql)
          test_connection.commit()
          print("inserted")
          return({"uuid":uuid,"imageName":image_name,"imageId":image_id,"nas_image_status":nas_image})
          
          
      except Exception as e:
        return {"error":str(e),"message":"uuid not stored in db properly"}
      finally:
        if test_connection:
          test_connection.close()



 
  @classmethod
  def post_measure_image(cls,record):
      print("called job run table")
      test_connection = None
      try:
          test_connection = Connector.create_connection()
          engine = Connector.get_engine()
          cursor = test_connection.cursor()

          algo_id = record["algo_id"]
          job_id =  str(record["job_id"])
          demo_id = record["demo_id"]
          image_id = record["image"]
          image_name = record["image_name"]
          bounding_box =json.dumps(record["inputs"]["bounding_box"],default=str)
          pixel_size = json.dumps(record["inputs"]["pixel_size"],default=str)
          rotation_angle = record["inputs"]["rotate"]
          uuid = str(record["uuid"])
          config_param = record["inputs"]["config_param"].keys()
          #print(config_param,"----")
          db_uuid = pd.read_sql(f"SELECT uuid,job_id,demo_id,image_filename FROM caliper.job_run",test_connection)
          db_uuid_list=list(db_uuid['uuid'])
          db_job_id_list = list(db_uuid["job_id"])
          db_demo_id_list = list(db_uuid["demo_id"])
          db_image_name_list = list(db_uuid["image_filename"])
          print(image_id,"image_id")
          print(uuid,"uuid")
          if uuid == "":
            print("uuid is empty")
            de_uuid = uuid.uuid4()
            print(de_uuid)
            uuid = str(de_uuid)
          if image_id == None: 
            image_id = "null"
          if rotation_angle == None:
            rotation_angle = "null"
          if len(config_param)==0:
            #config_param = josn.dumps(record["inputs"]["config_param"],default=str)
            if algo_id!="":
              algo_record = pd.read_sql(f"select config_params from caliper.algo where algo_id = {algo_id}",test_connection)
              if algo_record.shape[0]== 0:
                config_param = {}
              else:
                config = algo_record.to_dict('r')[0]
                config_param = config["config_params"]
            else:
              config_param = {}     
              #f"UPDATE caliper.job_run set image_filename = '{result_list[4]}',output_binary_values= '{result_list[11]}',start_ts = '{result_list[13]}'
            config_param = json.dumps(config_param,default=str)
          else:
            config_param = json.dumps(record["inputs"]["config_param"],default=str)

          if uuid in db_uuid_list:
            
            sql=f"UPDATE caliper.job_run set uuid = '{uuid}',job_id = '{job_id}',demo_id = '{demo_id}',image_filename = '{image_name}',image_id = {image_id},algo_id = '{algo_id}',rotation_angle = {rotation_angle},bounding_box = '{bounding_box}',pixel_size = '{pixel_size}',config = '{config_param}',status= 'error' where uuid='{uuid}'"
          elif (job_id in db_job_id_list) & (demo_id in db_demo_id_list) & (image_name in db_image_name_list):
            uuid_record = pd.read_sql(f"SELECT uuid from caliper.job_run where job_id='{job_id}' and demo_id = '{demo_id}' and image_filename = '{image_name}'",test_connection)
            if uuid_record.shape[0]!=0:
              uuid = uuid_record.to_dict('r')[0]
              uuid = uuid["uuid"]
              print("matched_uuid",uuid)  
            sql = f"UPDATE caliper.job_run set uuid = '{uuid}',job_id = '{job_id}',demo_id = '{demo_id}',image_filename = '{image_name}',image_id = {image_id},algo_id = '{algo_id}',rotation_angle = {rotation_angle},bounding_box = '{bounding_box}',pixel_size = '{pixel_size}',config = '{config_param}',status = 'error' where job_id='{job_id}'"
          else:
            print("generated_uuid",uuid)
            sql = f"INSERT INTO caliper.job_run (uuid,job_id,demo_id,image_filename,image_id,algo_id,binary_op,rotation_angle,bounding_box,pixel_size,output_binary_values,config,start_ts, end_ts,error,sample_id, measurements_file,status,measurements) VALUES ('{uuid}','{job_id}','{demo_id}','{image_name}',{image_id},'{algo_id}',null,{rotation_angle},'{bounding_box}','{pixel_size}',null,'{config_param}',null,null,null,null,null,'error',null)"
          print("sql-----",sql)
          cursor.execute(sql)
          test_connection.commit()
          print("inserted")
          return({"uuid":uuid,"imageName":image_name,"imageId":image_id})
          
          
      except Exception as e:
        raise e
      finally:
        if test_connection:
          test_connection.close()


  @classmethod
  def get_job_id_status(cls,image_job_id):
    """
    For a given job_id ,this function will get the record from job run table where job_id is matching
    Parameters:
    -----------
    Image_job_id : list of image_id
    
    Returns:
    ---------
    Return the uuid.image id,image_filename,status and error as response
    """
    try:
      test_connection = Connector.create_connection() 
      if image_job_id!="":
        df_record = pd.read_sql(f"SELECT uuid,image_id,image_filename,status,error,pixel_size,bounding_box,nas_image_status FROM caliper.job_run WHERE job_id = '{image_job_id}'",test_connection)
      else:
        print("image_job_id_empty")
        df_record = pd.read_sql(f"SELECT uuid,image_id,image_filename,status FROM caliper.job_run WHERE job_id = ''",test_connection)
     
      if df_record.shape[0]==0:
          return [{"Error":"given job_id is not present in job_run table"}]
      else:
        print("Found image Job_id")
        #df_record = df_record.fillna('')
        job_id_dict = df_record.to_dict('r')
        print(job_id_dict)
        """
        response_dict = dict()
        print("Job_id_dict",job_id_dict)
        uuid= job_id_dict['uuid']
        image_id = job_id_dict["image_id"]
        response_dict["uuid"] = uuid
        response_dict["image_id"]=image_id
        return response_dict
        """
        return job_id_dict
      
    except Exception as e:
        raise e

    finally:
        if test_connection:
            test_connection.close()



  @classmethod
  def get_measurements_pickle_file(cls,image_uuid):
    """
      For a given image uuid, it will return the measurements pickle file

      Parameters
      -----------
      image_uuid: UUID of image sent from UI

      Returns
      --------
      measurements_pickle_file: Pickle file containing measurements, line markings and summary statistics

    """
    test_connection = None
    try:
      test_connection = Connector.create_connection()        
      df_measurements = pd.read_sql("SELECT algo_id,measurements,rotation_angle,bounding_box, pixel_size,config,status,nas_image_status  FROM caliper.job_run WHERE uuid = '" + image_uuid + "'",test_connection)
      if df_measurements.shape[0] == 0:
          return {"Error" : "Uuid is not present in job_run table"}

      else:
          print("Found measurements pickle for given image uuid")
      	  df_measurements['config'] = df_measurements['config'].astype(str)
	  df_measurements['config'] = df_measurements['config'].str.replace("'", '"')
	  df_measurements['config'] = df_measurements['config'].apply(lambda x: json.loads(x)) 
          measurements_file_dict = df_measurements.to_dict('r')[0]
          response_dict = dict()
          #print("measurements_file_dict",measurements_file_dict)
          if measurements_file_dict["measurements"] != None:
            response_dict["measurementSummary"] = [measurements_file_dict['measurements']["Summary Statistics"]]
            response_dict["measurementDetails"] = [measurements_file_dict['measurements']["Measurements"]]
            response_dict["lineMarkings"] =  [measurements_file_dict['measurements']["Line Markings"]]
          else:
            response_dict["measurementSummary"] = []
            response_dict["measurementDetails"] = []
            response_dict["lineMarkings"] = []   
          response_dict["bounding_box"] = measurements_file_dict['bounding_box']
          response_dict["pixel_size"] = measurements_file_dict['pixel_size']
          response_dict["algo_id"] = measurements_file_dict["algo_id"]
          response_dict["rotate"] = measurements_file_dict["rotation_angle"]
          response_dict["config_param"] = measurements_file_dict["config"]
          response_dict["status"] = measurements_file_dict["status"]
          response_dict['nas_image_status'] = measurements_file_dict["nas_image_status"]
          #get config params from algo table
          """
          print(measurements_file_dict["algo_id"],"algoid---")
          if measurements_file_dict["algo_id"]!="":
            algo_record = pd.read_sql(f"select config_params from caliper.algo where algo_id = {measurements_file_dict['algo_id']}",test_connection)
            if algo_record.shape[0]== 0:
              response_dict["config_params"]={}
            else:
              config = algo_record.to_dict('r')[0]
              response_dict["config_params"]=config["config_params"]
              #measurementSummary = measurements_file_dict['measurements']["Summary Statistics"]
              #print("measurements_pickle_file",measurements_pickle_file)
              #return measurements_pickle_file #returns NAS path to pickle file
          else:
            response_dict["config_params"]={}
          """
          return response_dict
 
    except Exception as e:
      raise e

    finally:
      if test_connection:
        test_connection.close()



  @classmethod
  def get_image_measure_multi_uuid(cls,image_uuid):
    """
      For a given image uuid, it will return the measurements pickle file

      Parameters
      -----------
      image_uuid: UUID of image sent from UI

      Returns
      --------
      measurements_pickle_file: Pickle file containing measurements, line markings and summary statistics

    """
    test_connection = None
    try:
      test_connection = Connector.create_connection()        
      df_measurements = pd.read_sql("SELECT measurements,image_filename  FROM caliper.job_run WHERE uuid = '" + image_uuid + "'",test_connection)
      if df_measurements.shape[0] == 0:
          return {"Error" : "Uuid is not present in job_run table"}

      else:
          print("Found measurements pickle for given image uuid")
          
          measurements_file_dict = df_measurements.to_dict('r')[0]
          response_dict = dict()
          #print("measurements_file_dict",measurements_file_dict)
          if measurements_file_dict["measurements"] != None:
            print("measurement")
            response_dict["measurementSummary"] = [measurements_file_dict['measurements']["Summary Statistics"]]
            response_dict["measurementDetails"] = [measurements_file_dict['measurements']["Measurements"]]
            response_dict['image_name'] = measurements_file_dict['image_filename']
            print(response_dict.keys())
            #response_dict["lineMarkings"] =  [measurements_file_dict['measurements']["Line Markings"]]
          else:
            response_dict["measurementSummary"] = []
            response_dict["measurementDetails"] = []
            #response_dict["lineMarkings"] = []   
          """
          response_dict["bounding_box"] = measurements_file_dict['bounding_box']
          response_dict["pixel_size"] = measurements_file_dict['pixel_size']
          response_dict["algo_id"] = measurements_file_dict["algo_id"]
          response_dict["rotate"] = measurements_file_dict["rotation_angle"]
          #get config params from algo table
          print(measurements_file_dict["algo_id"],"algoid---")
          if measurements_file_dict["algo_id"]!="":
            algo_record = pd.read_sql(f"select config_params from caliper.algo where algo_id = {measurements_file_dict['algo_id']}",test_connection)
            if algo_record.shape[0]== 0:
              response_dict["config_params"]={}
            else:
              config = algo_record.to_dict('r')[0]
              response_dict["config_params"]=config["config_params"]
              #measurementSummary = measurements_file_dict['measurements']["Summary Statistics"]
              #print("measurements_pickle_file",measurements_pickle_file)
              #return measurements_pickle_file #returns NAS path to pickle file
          else:
            response_dict["config_params"]={}
          """
          print(response_dict["measurementSummary"],"-----summary")
          return response_dict
 
    except Exception as e:
      raise e

    finally:
      if test_connection:
        test_connection.close()

        
        
  @classmethod
  def get_image_status(cls,image_uuid):
      """
      For a given image_uuid, Get the record from job_run table where image_uuid is matching
      
      Parameters:
      -----------
      image_uuid : List of uuid
      
      Returns:
      -----------
      response_dict: uuid,status,error 
      
      """
      test_connection = None
      try:
        print("uuid called")
        test_connection = Connector.create_connection()        
        df_measurements = pd.read_sql("SELECT uuid,status,error,nas_image_status FROM caliper.job_run WHERE uuid = '" + image_uuid + "'",test_connection)
        if df_measurements.shape[0] == 0:
            return {"Error":"uuid is not present in job_run table"}
        else:
          print("Found measurements pickle for given image uuid")
          measurements_file_dict = df_measurements.to_dict('r')[0]
          response_dict = dict()
          print("measurements_file_dict",measurements_file_dict)
          response_dict["uuid"] = measurements_file_dict['uuid']
          response_dict["status"] = measurements_file_dict['status']
          response_dict['error'] = measurements_file_dict['error']
          response_dict['nas_image_status'] = measurements_file_dict['nas_image_status']
          return response_dict
      except Exception as e:
        raise e

      finally:
        if test_connection:
          test_connection.close()

  @classmethod
  def get_summary_statistics(cls,image_uuid):
    """
      For a given image_uuid, Get the record from job_run table where image_uuid is matching
      
      Parameters:
      -----------
      image_uuid : List of uuid
      
      Returns:
      -----------
      response_dict: uuid,algo name,measurementStatistcs 
      
      """

    try:
      test_connection = Connector.create_connection() 
      df_record = pd.read_sql("SELECT uuid,algo_id,image_filename,measurements FROM caliper.job_run WHERE uuid = '" + image_uuid + "'",test_connection)
      if df_record.shape[0]==0:
          return {"Error":"uuid is not present in job_run table"}
      else:
          print("Found image uuid")
          measurements_file_dict = df_record.to_dict('r')[0]
          response_dict = dict()
          #print("measurements_file_dict",measurements_file_dict)
          uuid= measurements_file_dict['uuid']
          #algo_id = int(measurements_file_dict['algo_id'])
          if measurements_file_dict["measurements"]!=None:
            summary_statistics = measurements_file_dict['measurements']["Summary Statistics"]
          else:
            summary_statistics = {}
          #print("algo_id")
          print(measurements_file_dict["algo_id"],"algo_id")
          if measurements_file_dict["algo_id"]!="":
            algo_id = int(measurements_file_dict['algo_id'])

            algo_id_record = pd.read_sql(f"SELECT algo_name from caliper.algo where algo_id = {algo_id}",test_connection)
            print(algo_id_record,"record")
            if algo_id_record.shape[0]!=0:
              algo_name = algo_id_record.to_dict('r')[0]
              algo_name = algo_name["algo_name"]
              print(algo_name,"algoname")
            else:
              algo_name = ""
          else:
            algo_name = ""
          print(uuid,"uuid")
          print(summary_statistics,"summary")
          response_dict["uuid"] = uuid
          response_dict["algo_name"] = algo_name
          response_dict['image_name'] = measurements_file_dict['image_filename']
          response_dict["measurementStatistcs"] = summary_statistics
          #print("algo_name",algo_name)
          
          return response_dict
    except Exception as e:
        raise e

    finally:
        if test_connection:
            test_connection.close()


  @classmethod
  def get_auto_pixel(cls,req):
      """
      For given request return the response of autopixelcalclulations result
      
      Parameters:
      ----------
      Get the post method as a request
      
      Returns:
      -----------
      Return the response.            
      
      """
      print("auto_pixel_called")
      request=req
      #print(request,"req--")
      caliper_json = {"accessKey":"m7rtstw0i73hwyixxp7p329o81cz6ldd","request":request}
      #print("caliper_json",caliper_json)
      try:
        response = requests.post(url='https://modelservice.tcdsw.amat.com/model', json=caliper_json, headers={'Content-Type': 'application/json'},verify=False)
        print(response.text,"text")
        if response.status_code == 200:
          return response.json()
        else:
          return {"error":str(response.text)}
      except Exception as e:
        return {"error_msg":str(e)}


  @classmethod
  def measure_request_form(cls,req):
      """
      For given request, this method senting the mail.
      
      Parameters:
      -----------
      Get the post method as request
      Returns:
      ----------
      Return the status of response
      """
      print("measure request form_called")
      keys=list(req.keys())
      request=req
      #print(request,"req--")
      print(request,"helper req")
      #print("caliper_json",caliper_json)
      try:
        msg = MIMEMultipart('alternative')
        from_addr = req['email']
        to_addr = ['Caliper@amat.com']#['Adrienne_Bergh@amat.com','Abhinav_Kumar@amat.com','Jeff_Collins@amat.com','Gokul_Ganesan@amat.com','Anjankumar_Patra@amat.com','Hexuan_Wang@amat.com','sunil_kabbaladavenkateshappa@amat.com'] ['Caliper@amat.com']
        print("to_addr",to_addr,type(to_addr))
        #to_addr = list(to_addr)
        #print("to_addr",to_addr,type(to_addr))
        msg['From'] = from_addr
        msg['To'] = ', '.join(to_addr)
        msg['X-Priority'] = '2'
        msg['Subject'] = "New Measurement Algorithm Request"
        html = f""" 
                    <html>
                     <head></head>
                       <body>
                       <p>Name : {request['name']}</p>
                       <p>Demo Id : {request['demo_id']}</p>
                       <p>Lims Job Ids : {request['lims_job_ids']}</p>
                       <p>Customer Spec : {request['customer_spec']} </p>
                       <p>Desired Measurements : {request['desired_measurements']} </p>
                       </body>
                     </html>

                """
        print("msg",msg)
        part1 = MIMEText(html, 'html')
        msg.attach(part1)
        image_keys = [i for i in keys if 'annotated_image' in i]
        zip_keys = [i for i in keys if 'zip_file' in i]
        all_keys = image_keys+zip_keys
        print("all_keys-----",all_keys)
        for i in all_keys:
          print("file",request[i],"annotated image --------------------")
          file_data = request[i].file.read()
          #print(file_data,"reading data")
          file_name = request[i].filename
          print(file_name,"name ------------------")
          part2 = MIMEApplication(
                  file_data,
                  Name=file_name
              )
          part2['Content-Disposition'] = 'attachment; filename="%s"' %file_name
          msg.attach(part2)
        """
        print("file",request['zip_file'])
        file_data = request['zip_file'].file.read()
        print(file_data,"reading data")
        file_name = request['zip_file'].filename
        print(file_name,"name ------------------")
        part3 = MIMEApplication(
                file_data,
                Name=file_name
            )
        part3['Content-Disposition'] = 'attachment; filename="%s"' %file_name
        msg.attach(part3)
        """
        #filename = request['annotated_image'].filname
        #p = MIMEBase('application', 'zip')
        #p.add_header('Content-Disposition', 'attachment', 
               #filename=f"{request[annotated_image]}")
        
        #msg.attach(MIMEApplication(file_data),Name = "annotated_image.png")
        s = smtplib.SMTP('mailserver.amat.com')
        s.sendmail(from_addr, (to_addr), msg.as_string())
        s.quit()
        print("Sucessfully sent mail for first warning")
        return {"status":"success","message":"Request sent successfully."}
      except Exception as e:
        return {"status":"error","error_msg":str(e)}

  @classmethod
  def feedback_form(cls, req,fullname,email):
    """
      For given request, this method senting the mail.
      
      Parameters:
      -----------
      Get the post method as request
      Returns:
      ----------
      Return the status of response
    """
    request = req
    print(request,"feedback and name")
    try:
      msg = MIMEMultipart('alternative')
      fromaddr = email
      toaddr =['Caliper@amat.com'] #['Adrienne_Bergh@amat.com','Abhinav_Kumar@amat.com','Jeff_Collins@amat.com','Gokul_Ganesan@amat.com','Anjankumar_Patra@amat.com','Hexuan_Wang@amat.com','sunil_kabbaladavenkateshappa@amat.com'] ['Caliper@amat.com']
      msg['From'] = fromaddr
      msg['To'] = ', '.join(toaddr)
      msg['Subject'] = "Caliper Feedback"
      html =f"""
            <html>
              <head></head>
              <body>
                <p>name : {fullname}</p>
                <p>Feedback : {request['feedback']}</p></body>
            </html>
            """
      part1 = MIMEText(html, 'html')
      msg.attach(part1)
      s = smtplib.SMTP('mailserver.amat.com')
      s.sendmail(fromaddr, (toaddr), msg.as_string())
      s.quit()
      return {"status":"success","message":"Feedback sent successfully."}
    except Exception as e:
      return {"status":"error","message":str(e)}


  @classmethod
  def request_access_form(cls, req):
    """
      For given request, this method senting the mail.
      
      Parameters:
      -----------
      Get the post method as request
      Returns:
      ----------
      Return the status of response
      
      """
    request = req
    try:
      msg = MIMEMultipart('alternative')
      fromaddr = request['email']
      toaddr = ['Caliper@amat.com'] #['Adrienne_Bergh@amat.com','Abhinav_Kumar@amat.com','Jeff_Collins@amat.com','Gokul_Ganesan@amat.com','Anjankumar_Patra@amat.com','Hexuan_Wang@amat.com','sunil_kabbaladavenkateshappa@amat.com']  ['Caliper@amat.com']
      msg['From'] = fromaddr
      msg['To'] = ', '.join(toaddr)
      msg['X-Priority'] = '2'
      msg['Subject'] = "Request to Existing Measurement Algorithm"
      html =f"""
            <html>
              <head></head>
              <body>
                <p>Name : {request['name']}</p>
                <p>Measurement_algorithm : {request['measurement_algorithm']}</p>
                 <p>Demo Id : {request['demo_id']}</p></body>
            </html>
            """
      part1 = MIMEText(html, 'html')
      msg.attach(part1)
      s = smtplib.SMTP('mailserver.amat.com')
      s.sendmail(fromaddr, (toaddr), msg.as_string())
      s.quit()
      return {"status":"success","message":"Request sent successfully."}
    except Exception as e:
      return {"status":"error","message":str(e)}


  @classmethod
  def images_name_list(cls,image_name):
    """
    For a given image name ,this function will get the record from job run table where image name is matching
    Parameters:
    -----------
    Image_job_id : list of image name
    
    Returns:
    ---------
    Return the uuid.image id,image_filename,status and error as response
    """
    try:
      test_connection = Connector.create_connection() 
      if image_name!="":
        df_record = pd.read_sql(f"SELECT uuid,image_filename,status,error,pixel_size,bounding_box,nas_image_status FROM caliper.job_run WHERE image_filename = '{image_name}'",test_connection)
      else:
        print("image_name_empty")
        #df_record = pd.read_sql(f"SELECT uuid,image_id,image_filename,status FROM caliper.job_run WHERE job_id = ''",test_connection)
        return {"status":"success","message":"given image name is empty"}
      if df_record.shape[0]==0:
          return [{"Error":"given image_name is not present in job_run table"}]
      else:
        print("Found image Job_id")
        #df_record = df_record.fillna('')
        image_name_dict = df_record.to_dict('r')
        print(image_name_dict)
        """
        response_dict = dict()
        print("Job_id_dict",job_id_dict)
        uuid= job_id_dict['uuid']
        image_id = job_id_dict["image_id"]
        response_dict["uuid"] = uuid
        response_dict["image_id"]=image_id
        return response_dict
        """
        return image_name_dict
      
    except Exception as e:
        raise e

    finally:
        if test_connection:
            test_connection.close()

  @classmethod
  def algo_list(cls, email_id):
    test_connection = None
    response_dict = dict()
    try:
      test_connection = Connector.create_connection()        
      df_user = pd.read_sql("SELECT algo_id,algo_name FROM caliper.user_algo WHERE email_id = '" + email_id + "'",test_connection)
      if df_user.shape[0] == 0:
          return {"Error","No record found for given email_id in user_algo table"}
      else:
          algo_id_df = list(df_user['algo_id'])
          print(algo_id_df,"algo_id_list")
      df_algo = pd.read_sql("SELECT algo_id,algo_name from caliper.algo",test_connection)
      if df_algo.shape[0] == 0:
          return {"Error","No record found in algo table"}
      else:
        result_df = df_algo[~df_algo['algo_id'].isin(algo_id_df)]
        print(result_df,"result df")
        if len(result_df)>0:
          result_df = result_df.to_dict('r')
          print(result_df,"dict result")
        
          #response_dict['algo_id'] = result_df['algo_id']
          #response_dict['algo_name'] = result_df['algo_name']
          return result_df
        else:
          return response_dict
    except Exception as e:
      raise e

    finally:
      if test_connection:
        test_connection.close()

#if __name__ == "__main__":
#  print(caliperApiHelper.match_user_algo('Siva_Thanneru@contractor.amat.com'))
