# coding: utf-8

from ._log import AMATLogger

log_path = r'/application/isystem_python/log/not_responding_logs'
#LOG = AMATLogger.get_logger(logpath=log_path, filename='timeout_systems_logs')
#LOG_WATCH = AMATLogger.get_logger(logpath=log_path, filename='watch_logs')
LOG = AMATLogger.get_rotating_logger(logpath=log_path, filename='timeout_systems_logs')
#LOG_WATCH = AMATLogger.get_rotating_logger(logpath=log_path, filename='watch_logs')

__doc__ = """Defines configuration and formatting to produce a homogeneous 
log for the application."""
__author__ = ['Tarun Verma']
__version__ = 2.0
