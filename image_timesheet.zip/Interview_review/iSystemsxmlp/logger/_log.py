# coding: utf-8

"""Logging Module

Defines configuration and formatting to produce a homogeneous log for the
application.

Classes
----------
AMATFormatter: Defines formatting to produce a homogeneous
log for the application.
AMATLogger: Defines configuration and formatting to
produce a homogeneous log for the application.
"""

# Standard Library
from os import path, sep
from datetime import datetime
import logging
import logging.handlers


class AMATFormatter(logging.Formatter):
    """Defines formatting to produce a homogeneous log for the application."""

    def format(self, record):
        self._fmt = '%(asctime)s [%(module)s:%(funcName)s] %(levelname)s: ' \
                    '%(message)s'

        if record.levelno >= logging.WARNING:
            self._fmt = '%(asctime)s [%(filename)s:%(lineno)d] ' \
                        '%(levelname)s: %(message)s'

        result = logging.Formatter(self._fmt).format(record)
        result = result.replace(':<module>', '')

        return result


class AMATLogger:
    """Defines configuration and formatting to produce a homogeneous log for
    the application. """

    @staticmethod
    def get_logger(logpath=None, filename='process', replace=True):
        """Defines logger.

        Parameters
        ----------
        logpath: str
            Log path, defaulted to None

        filename: str
            File name, defaulted to "process"

        replace: bool
            Overwrite identifier, defaulted to True

        Returns
        -------
        logger: object
            Object of class Logger
        """
        if logpath:
            if not path.exists(logpath):
                raise OSError('Invalid log path')
            if filename == '':
                raise ValueError("Invalid file name")

        logger = logging.getLogger(__name__)
        logger.setLevel(logging.DEBUG)

        formatter = AMATFormatter()

        if logpath:
            if replace:
                logname = logpath + sep + '{}.log'.format(filename)
            else:
                logname = logpath + sep + '{}_{}.log'. \
                    format(filename, datetime.now().strftime("%Y-%m-%d_%H-%M-%S"))

            file_handler = logging.FileHandler(logname, mode='w')
            file_handler.setFormatter(formatter)
            logger.addHandler(file_handler)

        stream_handler = logging.StreamHandler()
        stream_handler.setFormatter(formatter)
        logger.addHandler(stream_handler)
        
        return logger

    @staticmethod
    def get_rotating_logger(**intervals):
        """Defines rotating logger.

        Parameters
        ----------
        **intervals: dict
            Available keys:
            1. logpath (Required)
            2. filename (Optional, Default: 'process')
            3. when (Optional, Default: 'D')
            4. interval (Optional, Default: 7)
            5. backupCount (Optional, Default: 7)

        Returns
        -------
        logger: object
            Object of class Logger
        """
        if 'logpath' in intervals.keys():
            logpath = intervals['logpath']
            if not path.exists(logpath):
                raise OSError('Invalid log path')
        else:
            raise ValueError("log path is missing")

        if 'filename' in intervals.keys():
            filename = intervals['filename']
        else:
            filename = 'process'

        if 'when' in intervals.keys():
            when = intervals['when']
        else:
            when = 'D'

        if 'interval' in intervals.keys():
            interval = intervals['interval']
        else:
            interval = 7

        if 'backupCount' in intervals.keys():
            backupCount = intervals['backupCount']
        else:
            backupCount = 7

        logger = logging.getLogger(__name__)
        logger.setLevel(logging.DEBUG)

        formatter = AMATFormatter()

        logname = logpath + sep + '{}.log'.format(filename)

        file_handler = logging.handlers.TimedRotatingFileHandler(logname, when, interval, backupCount)
        file_handler.setFormatter(formatter)
        logger.addHandler(file_handler)

        stream_handler = logging.StreamHandler()
        stream_handler.setFormatter(formatter)
        logger.addHandler(stream_handler)

        return logger
