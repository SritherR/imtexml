import os
import sys
import datetime
import yaml
import multiprocessing
import xml_finder 
import glob
import requests
import csv
import pandas as pd
from datetime import datetime as dt,timedelta as td
from multiprocessing import Process, Pool
from settings import conf_file

def id_cdt_picker(files_list):

    try:
        log_list.append("info:-----Id picker function started-----") 
        file_dict={}
        for file in files_list:
            date_time=file.split('-')[-1].replace('.xml','')
            isystem_name=file.split('/')[-1].split(date_time)[0]
            isystem_id=str(isystem_name[:-1])
            cdt_val=str(dt.strptime(date_time,"%Y%m%d%H%M%S").strftime("%Y-%m-%d %H:%M:%S"))
            data_dict={'isystemid':str(isystem_id), 'cdt':str(cdt_val)}
            try:
                if int(str(file_dict[isystem_id]).replace("-","").replace(" ","").replace(":","")) < int(str(cdt_val).replace("-","").replace(" ","").replace(":","")):
                    file_dict[isystem_id]=cdt_val
            except:
                   file_dict[isystem_id]=cdt_val     

        dict_1={}
        dict_2={}
        header = ["isystemid", "cdt_val"]
        if(os.path.exists(r"isystem.csv")):
            with open('isystem.csv') as fin:
                read=csv.reader(fin)
                headers = next(read) 
                for row in read:
                    dict_1[row[0]]=row[1]
            dict_2=file_dict
            d = (set(dict_1)-set(dict_2))
            new_dict = {}
            for elements in d:
                new_dict[elements] = dict_1[elements]
            dict_2.update(new_dict)
            with open('isystem.csv', 'w', encoding='utf-8-sig') as f:
                writer = csv.writer(f,lineterminator='\n')
                writer.writerow(header)
                for k,v in dict_2.items():
                    writer.writerow([str(k),str(v)])
            log_list.append("info:-----Isystem & cdt values appended in isystem csv file -----")     
        else:
            with open('isystem.csv', 'w', encoding='utf-8-sig') as f:
                writer = csv.writer(f,lineterminator='\n')
                writer.writerow(header)
                for k,v in file_dict.items():
                    writer.writerow([str(k),str(v)])
                log_list.append("info:-----isystem csv file created for first run-----") 
    except Exception as e:
        log_list.append("exception:-----id_cdt_picker function Error is {0} : ".format( repr(e)))

def get_python_lock():

    """This function will block the pool processes for the current run"""

    global lock_exists_python
    if LOCK_FILE_Python:
        if os.path.exists(LOCK_FILE_Python):
            lock_exists_python = True
            raise LockFailed
        else:
            fh = open(LOCK_FILE_Python, 'w')
            fh.close()

def release_python_lock():

    """This function will release the block pool processes"""

    if os.path.exists(LOCK_FILE_Python):
        os.unlink(LOCK_FILE_Python)

def finder_calling(files_list):

    """Function will help start process the xml files which are present in the CMS directory"""

    xf = xml_finder.xml_observer(conf_file)
    parser_df=xf.file_processor(files_list)
    return parser_df

def solr_load(df,post_url):

    """This function load all the process data into Solr"""
    
    solr_json = df.to_json(orient='records')
    payload = solr_json
    try:
        headers = {'Content-Type': 'application/json', 'Accept': 'application/json'}
        response_api= requests.request("POST",post_url,data=payload, headers=headers)
        log_list.append("info:-----API Response is {0}. ".format(str(response_api.text)))
    except Exception as e:
        log_list.append("exception:Solr Error is {0}. ".format( repr(e)))


if __name__ == "__main__":

    log_list=[]
    lock_exists_python = False
    project_root=os.path.dirname(os.path.abspath(__file__))
    LOCK_FILE_Python =project_root+"/locker_python"

    try:
        get_python_lock()
        log_list.append("info:-----python job processes locked for the current run-----" )
        start=datetime.datetime.now()
        with open(conf_file, 'r') as conf_yaml:
                conf_details = yaml.load(conf_yaml)
                base_directory = conf_details.get("watched").get("watched_path")
                pool_count= conf_details.get("Multiprocess").get("pool_number")
                post_url = conf_details.get("API").get("url")
                log_path = conf_details.get("path").get("log_path")
        if os.name == 'nt':
            sep = "\\"
        else:
            sep = '/'   
        print(sep)
        log_list.append(("info:-----Number of process is going to run  {0} -----".format(pool_count)))
        log_list.append("info:-----Multiprocess job has started  -----")
        common_dir = str(base_directory) + sep+'*'+sep+'DB3'+sep+'*.xml'
        time=datetime.datetime.now()
        files_list=[]
        for files in glob.glob(common_dir):
            files_list.append(files)
        log_list.append("info:-----Number of xml files are {0} -----".format(len(files_list)))
        id_cdt_picker(files_list)
        small_list = []
        final_data_list = []
        counter = 0
        for item in files_list:
            if counter < 49:
                small_list.append(item)
                counter = counter + 1
            else:
                small_list.append(item)
                counter = 0
                final_data_list.append(small_list)
                small_list = []
        final_data_list.append(small_list)
        log_list.append("info:-----Each Batch should have 50 files ,Total Number of Batches {0} -----".format(len(final_data_list)))

        for ele_list in final_data_list:
            try:
                log_list.append("info:-----Number of xml files are inside the Batch {0} -----".format(len(ele_list)))
                process_pool = Pool(pool_count)
                data_list = process_pool.map(finder_calling, ele_list)
                process_df = pd.DataFrame()
                process_df = pd.concat([rdf for rdf in data_list])
                process_pool.close()
                process_pool.join()
                log_list.append("info:-----Data is ready to load into Solr,Records of the Batch {0}-----".format(len(process_df)))
                solr_load(process_df,post_url)

            except Exception as e:
                process_pool.terminate()
                process_pool.join()
                log_list.append("exception:-----Error in pool_process {0} : ".format(repr(e)))

        release_python_lock()
        log_list.append("info:-----Current python job is completed!! process lock got relased-----" )
        end = datetime.datetime.now()
        log_list.append("info:-----Run Successfully Completed!!,time taken is {0}.".format(end - start))

    except Exception as e:
        log_list.append("exception:-----Multiprocess job Error is {0} : ".format( repr(e)))

    finally:
            s=open(log_path+"/"+"log_multi_process.log",'a')
            for element in log_list:
                print(element)
                s.write(str(datetime.datetime.now())+"::"+str(element)+"\n")
            s.write("\n\n\n\n")
            s.close()