This Pipline will help to process xml files.

we have 3 main python scripts
a.xml_finder.py
b.xml_parser.py
c.multiprocess.py

a.xml_finder job is 
1.It will find the xmls from all isystems directory 
2.Then it call the xml_parser.py to process the xml files 
3.xml parser will return a dataframe
4.Then this job write that dataframe to postgress table.

b.xml_parser job is
1.It will process one by one xml files.
2.First it extracts data from xml and save into a dataframe . 
3.All kind of  data genration/filteration/Alteration is happens this script. 
4.Finaly this script retuns a datframe which uses to load into solar in multiprocess.py script.

c.Multiprocess job is
1.It uses multiple of processes of the system to complete the job in faster way for bulk amount files .
2.That processes we can control through the config file inputs .
3.This job control the each runs like it wont allows the next job to run if the previous job is not completed  
3.Also it stores all the xml files output dataframes in single dataframe and at the end it loads that dataframe into the solar.


If job sucessfully completed than files will automatically move to the archived_processed_xml_files folder otherwise files
move to errorxml folder.


conf.yaml will help to configure the database,Solar API,filters which are using inside the script and file management process.

logs:
We recives log information in 3 logs files which i one is for log_xml_finder,second one is log_xml_parser and the last one is forlog_multi_process.
All the logs can find in log folder.
We are using logutils.py to maintain logs and log file name is combination of xml file name+timestamp. 

Schedular:
This python job is running in every minute and this is scheduled in crontab.