import os
import time
import shutil
from xparser import xmlparser
import yaml
import datetime
import warnings
from settings import conf_file
start = time.time()
warnings.filterwarnings("ignore")

class xml_observer():

    def __init__(self, conf_file):
        self.conf_file = conf_file
        with open(self.conf_file, 'r') as conf_yaml:
            conf_details = yaml.load(conf_yaml)
            self.xml_archived_path = conf_details.get("path").get("archive_processed_xml_path")
            self.error_xml_path = conf_details.get("path").get("error_xml_path")
            self.log_path = conf_details.get("path").get("log_path")

        self.log_list=[]

    def file_processor(self,xml_files):
        '''
        file_processor funstion find all the xml in the directory and use
        parser code to process the xmls.
        '''
        start_time = time.time()
        try:
            self.log_list.append(("info:-----Process has started for ----- {0}.".format(xml_files)))
            parser = xmlparser(self.conf_file, xml_files)
            parser_df = parser.parse_to_dict()
            json_complete_time = time.time() - start_time
            self.log_list.append(("info:----- %s seconds ----- for json_complete_time" % (round(json_complete_time, 2))))
            shutil.move(xml_files, self.xml_archived_path)
            self.log_list.append(("----- xml file moved to archived folder-----"))
            completion_time = time.time() - start_time
            self.log_list.append(("info:----- %s seconds ----- for completion_time" % (round(completion_time, 2))))
            self.log_list.append(("info:-----Process has completetd for-----{0}.".format(xml_files)))        

        except Exception as e:
            self.log_list.append("exception : file_processor Error is {0} : ".format(repr(e)))
            shutil.move(xml_files, self.error_xml_path)

            self.log_list.append(("****************************************************************"))

        finally:
            end = time.time() - start
            self.log_list.append(("info:----- %s seconds ----- for end_time" % (round(end, 2))))
            s=open(self.log_path + "/" + "log_xml_finder.log",'a')
            for element in self.log_list:
                print(element)
                s.write(str(datetime.datetime.now())+"::"+str(element)+"\n")
            s.write("\n\n\n\n")
            s.close()
            return parser_df


if __name__ == "__main__":
    #con_file = "conf/conf.yaml"
    file_pro = xml_observer(conf_file)
    file_pro.file_processor()