import xmltodict, json
import pandas as pd
import numpy as np
from pandas.io.json import json_normalize
import yaml
import datetime
import warnings
import copy
import requests
import math

TIME_OBJ = datetime.datetime.now()
TSTAMP = TIME_OBJ.strftime("%Y-%m-%d %H:%M:%S")
LISTOFKEYS = []
analog_counter = 0
warnings.filterwarnings("ignore", category=FutureWarning)


class xmlparser():
    """
    Parse the  XML file and generate the data in the json format
    """

    def __init__(self, conf_file, xml_files):
        self.conf_file = conf_file
        self.xml_path_file = xml_files
        self.log_list = []
        self.log_list.append("info:paser process has started for " + str(xml_files))

        with open(conf_file, 'r') as conf_yaml:
            conf_details = yaml.load(conf_yaml)
            self.key_col = conf_details.get("key_col")
            self.refhierlabel_filter = conf_details.get("refhierlabel_filter")
            self.partial_filter = conf_details.get("partial_filter")
            self.restrict_records = conf_details.get("restrict_records")
            self.status_filter=conf_details.get("status_filter")
            #self.post_url = conf_details.get("API").get("url")
            self.ref_hierval_del = conf_details.get("ref_hierval_del")
            self.log_path = conf_details.get("path").get("log_path")

    def parse_to_dict(self):
        """
        Parse the XMl file
        """
        try:

            with open(self.xml_path_file) as xml_file:
                data = xml_file.read()
                self.doc = xmltodict.parse(data)
                jfile = json.dumps(self.doc)
                raw_data = json.loads(jfile)
                isys_complete_final = self.parser(raw_data)
                return isys_complete_final

        except Exception as e:
            self.log_list.append("exception:error is" + str(e))

    def flatten_json(self, ord_dict):
        '''
        flatten_json faltten the xml data where we have list or dictionary or nested dictionary.
        '''
        try:
            out_dict = {}

            def flatten(tag, name=''):
                try:

                    if type(tag) is dict:
                        LISTOFKEYS.append(tag.keys())
                        for chld_elem in tag:
                            flatten(tag[chld_elem], name + chld_elem + '/')


                    elif type(tag) is list:
                        for chld_elem in tag:
                            if type(chld_elem) != str:
                                flatten(chld_elem, name + str(chld_elem[next(iter(chld_elem))]) + '/')

                    else:
                        out_dict[name[:-1]] = tag

                except Exception as e:
                    self.log_list.append("Error {0} : ".format(repr(e)))

            flatten(ord_dict)
            return out_dict

        except Exception as e:
            self.log_list.append("exception:flatten_json Error is {0} : ".format(repr(e)))

    def split_col(self, col):
        '''
        split_col function: split the last string value which will be present after  "/" forward slash.
        '''
        try:

            cols = col.split("/")
            cols_temp = cols[:-1]
            col_last = cols[-1]
            cols_first = "/".join(cols_temp)
            return [cols_first, col_last]

        except Exception as e:
            self.log_list.append("exception:flatten_json Error is {0} : ".format(repr(e)))

    def parser(self, df1):
        '''
        Parser function:Uses for manupulation on dataframe level and post data into API.
        '''
        try:

            raw_data = df1 
            col = list(self.doc['cmsdata'].keys())
            tot_col = []

            for keys in col:
                tot_col.append('cmsdata/' + keys)
            if self.key_col is not None:
                key_col = ['cmsdata/' + str(i) for i in self.key_col]
            else:
                key_col = ['cmsdata/SystemID', 'cmsdata/TimeStamp', 'cmsdata/ProcessToolID']

            flat = self.flatten_json(raw_data) 

            """logic to handle single chamber as it is not populating chamber name in refhierlabel"""

            chamber_key = 'cmsdata/Tool/Chamber/Name'
            if chamber_key in flat.keys():
                self.log_list.append("info:Single Chamber present in file")
                replace_word = 'Chamber/' + flat['cmsdata/Tool/Chamber/Name'] + '/'
                modified_flat = {x.replace('Chamber/', replace_word): y for x, y in flat.items()}
                df_js = json_normalize(modified_flat)
            else:
                self.log_list.append("info:This file contains more then 1 Chamber so no additional logic reqd")
                df_js = json_normalize(flat)
            final_cols = [col for col in df_js.columns.values.tolist() for subcol in key_col if subcol in col]
            if self.key_col is None:
                df = df_js[:]
            else:
                df = df_js[final_cols]


            cdt = raw_data['cmsdata']['TimeStampSecond']
            cdt_new = cdt.replace('/', '-')
            df['CDT'] = cdt_new
            transposed_df = pd.melt(df, id_vars=['cmsdata/SystemID', 'CDT'], var_name=['RefHierLabel'],
                                    value_name='RefValue')
            transposed_df[['RefHierValue', 'RefLabel']] = transposed_df.apply(
                lambda row: pd.Series(self.split_col(row['RefHierLabel'])), axis=1)
            new_str = [str(x) for x in transposed_df['cmsdata/SystemID']][0]

            if transposed_df[transposed_df.RefHierLabel == 'cmsdata/Subfab/Abatement/Number'].shape[0] != 0:
                Subfabno = \
                transposed_df[transposed_df.RefHierLabel == 'cmsdata/Subfab/Abatement/Number']['RefValue'].reset_index(
                    drop=True)[0]

            ProcessToolId = raw_data['cmsdata']['ProcessToolID']
            transposed_df['RefHierValue'] = transposed_df['RefHierValue'].str.replace('cmsdata', new_str)
            transposed_df['RefHierValue'] = transposed_df['RefHierValue'].str.replace('Tool', ProcessToolId)
            transposed_df['RefHierLabel'] = transposed_df['RefHierLabel'].str.replace('cmsdata', "SystemID")
            transposed_df.rename(columns={'cmsdata/SystemID': 'iSystemID'}, inplace=True)
            transposed_df = transposed_df[['iSystemID', 'CDT', 'RefHierLabel', 'RefHierValue', 'RefLabel', 'RefValue']]

            for i in self.ref_hierval_del:
                transposed_df['RefHierValue'] = transposed_df['RefHierValue'].str.replace(i + '/', '')

            for i in self.ref_hierval_del:
                transposed_df['RefHierLabel'] = transposed_df['RefHierLabel'].str.replace(r'(?<=' + i + '/).*?(?=/)',
                                                                                          '')

            transposed_df['RefHierLabel'] = transposed_df['RefHierLabel'].str.replace('//', '/')
            transposed_df['RefHierLabel'] = transposed_df['RefHierLabel'].apply(lambda x: x[0:x.rindex('/')])
            transposed_df.loc[-1] = [new_str, cdt_new, 'SystemID', new_str, 'SystemID', new_str]  # adding a row
            transposed_df.index = transposed_df.index + 1  # shifting index
            transposed_df = transposed_df.sort_index()  # sorting by index
            transposed_df.columns = map(str.lower, transposed_df.columns)
            
            # #remove true from systemcomponents components data
            # def remove_true(x):
            #     if ('SystemComponents' in x):
            #         if len(x.split('/'))>4:
            #             if (x.split('/')[4]=='True'):
            #                 x=x.replace('/True','')

            #     return x

            # transposed_df['refhierlabel']=transposed_df['refhierlabel'].apply(lambda x:remove_true(x))
            # transposed_df['refhiervalue']=transposed_df['refhiervalue'].apply(lambda x:remove_true(x))
            self.log_list.append("info:-----shape of transposed_df{0}------".format(transposed_df.shape))

            trans_df_filt1 = transposed_df[transposed_df['refhierlabel'].isin(self.refhierlabel_filter)]
            trans_df_filt_status_1 = transposed_df[transposed_df['refhiervalue'].str.contains('|'.join(self.status_filter))]
            transposed_df_status_join = pd.concat([trans_df_filt1, trans_df_filt_status_1])
            mask = transposed_df.iloc[:, 2].str.contains(r'\b(?:{})\b'.format('|'.join(self.partial_filter)))
            trans_df_filt2 = transposed_df[mask]
            transposed_df_join = pd.concat([transposed_df_status_join, trans_df_filt2])

            """Restricting non existing components entries """
            rem_exist_list = transposed_df_join[(transposed_df_join['reflabel'] == "Exists") & (
                        transposed_df_join['refvalue'] == "False")].refhiervalue.unique().tolist()

            if len(rem_exist_list)>0:
                rem_df = transposed_df_join[~transposed_df_join['refhiervalue'].str.contains('|'.join(rem_exist_list))]
            else:
                rem_df = transposed_df_join[transposed_df_join['refhiervalue'].str.contains('|'.join(rem_exist_list))]
            

            ##//New logic
            rem_df['refhiervalue'] = rem_df['refhiervalue'].str.split('/Analogs').str[0]
            rem_df_chamber=rem_df[rem_df['refhierlabel'].str.contains('SystemID/Tool/Chamber/')]
            rem_df_syscomp=rem_df[rem_df['refhierlabel'].str.contains('SystemID/Tool/SystemComponents/')]
            pumpno_df_chamber = rem_df_chamber[rem_df_chamber.reflabel == 'Number']
            pump_list=pumpno_df_chamber.refhierlabel.str.split('/').str[-1].unique().tolist()
            pumpno_df_chamber['refhiervalue1'] = pumpno_df_chamber['refhiervalue'] + pumpno_df_chamber['refvalue']
            pumpno_df_sys = rem_df_syscomp[rem_df_syscomp.reflabel == 'Number']
            pump_list=pumpno_df_sys.refhierlabel.str.split('/').str[-1].unique().tolist()
            pumpno_df_sys['row']=pumpno_df_sys.reset_index(inplace=True)
            pumpno_df_sys['row']=pumpno_df_sys.index
            pumpno_df_sys['refhiervalue1'] = pumpno_df_sys['row'].apply(lambda x: str(pumpno_df_sys['refhiervalue'].iloc[x]) + str(pumpno_df_sys['refvalue'].iloc[x]) if (str(pumpno_df_sys['refhiervalue'].iloc[x].split('/')[-1])!=str(pumpno_df_sys['refvalue'].iloc[x])) else pumpno_df_sys['refhiervalue'].iloc[x].replace('/'+str(pumpno_df_sys['refvalue'].iloc[x]),str(pumpno_df_sys['refvalue'].iloc[x])))
            del pumpno_df_sys['row']
            del pumpno_df_sys['index']
            pumpno_df=pd.concat([pumpno_df_chamber,pumpno_df_sys])

            pump_list=pumpno_df['refhiervalue1'].str[:-1].str.split('/').str[-1].unique().tolist()
            for i in pump_list:
                pumpno_df['refhiervalue1'] = pumpno_df['refhiervalue1'].str.replace(i, '')
            df_merge = pd.merge(rem_df, pumpno_df[['refhiervalue', 'refhiervalue1']], on='refhiervalue',
                                how='left')
            df_merge.drop_duplicates(inplace=True)
            df_merge.loc[df_merge['refhiervalue1'].notnull(), 'refhiervalue'] = df_merge['refhiervalue1']
            df_merge.drop('refhiervalue1', axis=1, inplace=True)
            
            ddf=pd.DataFrame()
            try:
                comp_val_hier=df_merge['refhierlabel'].str.split('/').str[4].unique().tolist()
                num=[]
                for element in comp_val_hier:
                    try:
                        int(element) 
                        num.append(element)
                    except:
                        continue

                counter=0
                for elem in num:
                    df=df_merge[df_merge['refhierlabel'].str.contains('/'+elem)]
                    if counter==0:
                        ddf=df
                        counter=1
                    else:
                        ddf=ddf.append(df)
                self.log_list.append("-----Multiple Sybsystem components dataframe is ready-----")

            except Exception as e:
                self.log_list.append("-----No Multiple Sybsystem components-----",str(e))

            if len(ddf)>0:    
                list_m=ddf['refhierlabel'].unique().tolist()
            else:
                list_m=[]
            mdf=df_merge[~df_merge['refhierlabel'].isin(list_m)]

            """ Analog_converter function help to extract analog data from all componenets """

            def analog_converter(df_merge,compo=False):
                try:
                    ##Handling Analog Data
                    if df_merge['refhierlabel'].str.contains('/Analogs/Item/').any() == True:
                        if compo:
                            var_analog = df_merge[df_merge['refhierlabel'].str.contains('/Analogs/Item/')].refhierlabel.str.split('/').str[3].unique()+'/Analogs'
                        else:
                            var_analog=list(set(ddf['refhierlabel'].str.split('/').str[3]+'/'+ddf['refhierlabel'].str.split('/').str[4]+'/Analogs'))

                        column_name = ['isystemid', 'cdt', 'refhierlabel', 'refhiervalue', 'reflabel', 'refvalue',
                                       'reflabel1', 'refvalue1', 'reflabel2', 'refvalue2', 'new_ref_label',
                                       'new_ref_value']
                        concate_df = pd.DataFrame(columns=column_name)

                        for status in var_analog:
                            if df_merge['refhierlabel'].str.contains(status).any() == True:
                                final_df_2 = df_merge[
                                    ~df_merge['refhierlabel'].str.contains(status)]  ##Without analog

                                analog_df = df_merge[
                                    df_merge['refhierlabel'].str.contains(status)]  ##Only Analog

                                analog_df['reflabel1'] = (
                                    analog_df.sort_values(by=['refhierlabel', 'cdt', 'isystemid', 'reflabel'],
                                                          ascending=True).groupby(
                                        ['refhierlabel', 'refhiervalue'])['reflabel'].shift(-1))
                                analog_df['refvalue1'] = (
                                    analog_df.sort_values(by=['refhierlabel', 'cdt', 'isystemid', 'reflabel'],
                                                          ascending=True).groupby(
                                        ['refhierlabel', 'refhiervalue'])['refvalue'].shift(-1))
                                analog_df['reflabel2'] = (
                                    analog_df.sort_values(by=['refhierlabel', 'cdt', 'isystemid', 'reflabel'],
                                                          ascending=True).groupby(
                                        ['refhierlabel', 'refhiervalue'])['reflabel'].shift(-2))
                                analog_df['refvalue2'] = (
                                    analog_df.sort_values(by=['refhierlabel', 'cdt', 'isystemid', 'reflabel'],
                                                          ascending=True).groupby(
                                        ['refhierlabel', 'refhiervalue'])['refvalue'].shift(-2))

                                analog_df1 = analog_df[analog_df['reflabel'].str.contains("@name")]
                                analog_df1['new_ref_label'] = analog_df1['reflabel'] + '=' + analog_df1['refvalue']
                                analog_df1['new_ref_value'] = analog_df1['reflabel1'] + '(' + analog_df1[
                                    'refvalue1'] + ')' + '|' + \
                                                              analog_df1['reflabel2'] + '(' + analog_df1[
                                                                  'refvalue2'].fillna('') + ')'
                                concate_df = concate_df.append(analog_df1)


                        final_analog_df = concate_df.drop(
                            columns=['reflabel', 'refvalue', 'reflabel1', 'refvalue1', 'reflabel2', 'refvalue2'])
                        final_analog_df.rename(columns={'new_ref_label': 'reflabel', 'new_ref_value': 'refvalue'},
                                               inplace=True)
                        final_analog_df_idx = final_analog_df[
                            ['isystemid', 'cdt', 'refhierlabel', 'refhiervalue', 'reflabel', 'refvalue']]

                        final_df_3 = final_df_2[~final_df_2.refhierlabel.str.contains('/Analogs/Item/')]

                        """ Concatenate final_analog_df_idx & final_df """
                        analog_list = [final_analog_df_idx, final_df_3]
                        result_df = pd.concat(analog_list)

                        self.log_list.append("info:-----Analog Data Processed Successfully-----")

                    else:
                        result_df = df_merge
                        final_df_3 = df_merge[~df_merge.refhierlabel.str.contains('/Analogs/Item/')]

                    return result_df,final_df_3
                except Exception as e:
                    self.log_list.append("Analog converter error is {0} : ".format(repr(e)))

            result_df_mdf,final_df_3_mdf = analog_converter(mdf,True)
            if len(ddf)>0:
                result_df_ddf,final_df_3_ddf = analog_converter(ddf)
            else:
                result_df_ddf=pd.DataFrame()
                final_df_3_ddf=pd.DataFrame()

            status_list_mdf=result_df_mdf[(result_df_mdf['reflabel']=='Alarm')  & (result_df_mdf['refhierlabel'].str.contains('Status'))| (result_df_mdf['reflabel']=='Warning')  & (result_df_mdf['refhierlabel'].str.contains('Status'))| (result_df_mdf['reflabel']=='CommunicationStatus'
            ) & (result_df_mdf['refhierlabel'].str.contains('Status'))].refhierlabel.str.split('/').str[-1].unique().tolist()

            if len(result_df_ddf)>0:

                    sta_df=result_df_ddf[(result_df_ddf['reflabel']=='Alarm') & (result_df_ddf['refhierlabel'].str.contains('Status')) 
                    | (result_df_ddf['reflabel']=='Warning')  & (result_df_ddf['refhierlabel'].str.contains('Status'))
                    | (result_df_ddf['reflabel']=='CommunicationStatus') & (result_df_ddf['refhierlabel'].str.contains('Status'))]
                    status_list_ddf=list(set(sta_df['refhierlabel'].str.split('/').str[3]+'/'+sta_df['refhierlabel'].str.split('/').str[4]))
            else:
                sta_df=pd.DataFrame()
                status_list_ddf=[]


            def status_df(Name,df,rf_df):
                
                rf_df_1=comp_status_extract_test(df,Name,'Alarm', 'Warning', 'CommunicationStatus')
                rf_df=rf_df.append(rf_df_1)
                return rf_df

            """ components label status extraction """

            def comp_status_extract_test(result_df, ref_level1, arg_1, arg_2, arg_3):
                try:
                    comp_df2 = result_df
                    ana_list=['SystemID/Tool/Chamber/','SystemID/Tool/SystemComponents/']
                    for i in ana_list:
                        variable_ref = i + ref_level1
                        comp_df3 = comp_df2[(comp_df2['reflabel'] == arg_1) & (comp_df2['refhierlabel'] == variable_ref) | (
                                    comp_df2['reflabel'] == arg_2) & (comp_df2['refhierlabel'] == variable_ref) | (
                                                    comp_df2['reflabel'] == arg_3) & (
                                                        comp_df2['refhierlabel'] == variable_ref)].drop_duplicates()
                        comp_df3['comm_stats_label'] = (
                            comp_df3.sort_values(by=['refhierlabel', 'cdt', 'isystemid', 'reflabel'], ascending=True).groupby(
                                ['refhierlabel', 'refhiervalue'])['reflabel'].shift(-1))
                        comp_df3['comm_stats_value'] = (
                            comp_df3.sort_values(by=['refhierlabel', 'cdt', 'isystemid', 'reflabel'], ascending=True).groupby(
                                ['refhierlabel', 'refhiervalue'])['refvalue'].shift(-1))
                        comp_df3['warning_label'] = (
                            comp_df3.sort_values(by=['refhierlabel', 'cdt', 'isystemid', 'reflabel'], ascending=True).groupby(
                                ['refhierlabel', 'refhiervalue'])['reflabel'].shift(-2))
                        comp_df3['warning_value'] = (
                            comp_df3.sort_values(by=['refhierlabel', 'cdt', 'isystemid', 'reflabel'], ascending=True).groupby(
                                ['refhierlabel', 'refhiervalue'])['refvalue'].shift(-2))

                        comp_df4 = comp_df3[comp_df3['reflabel'].str.contains(arg_1)]

                        comp_df4['comp_status'] = np.where((comp_df4['refvalue'] == 'False'), 'offline',
                                                           (np.where((comp_df4['comm_stats_value'] == 'True') & (
                                                               comp_df4['refvalue'].isnull()) & (
                                                                         comp_df4['warning_value'].isnull()), 'online',
                                                                     (np.where((comp_df4['comm_stats_value'] == 'True') & (
                                                                         comp_df4['refvalue'].notnull()) & (
                                                                                   comp_df4['warning_value'].isnull()), 'alarm',
                                                                               (np.where(
                                                                                   (comp_df4['comm_stats_value'] == 'True') & (
                                                                                       comp_df4['refvalue'].isnull()) & (
                                                                                       comp_df4['warning_value'].notnull()),
                                                                                   'warning', (np.where(
                                                                                       (comp_df4['comm_stats_value'] == 'True') & (
                                                                                           comp_df4['refvalue'].notnull()) & (
                                                                                           comp_df4['warning_value'].notnull()),
                                                                                       'alarm', 'offline')))))))))

                        # comp_df4.replace(to_replace=arg_3, value=ref_level1+"_status", inplace=True)
                        comp_df4.replace(to_replace=arg_1, value=ref_level1, inplace=True)
                        comp_df4.drop(
                            columns=['refvalue', 'comm_stats_label', 'comm_stats_value', 'warning_label', 'warning_value'],
                            inplace=True)
                        comp_df4.rename(columns={'comp_status': 'refvalue'}, inplace=True)
                        cols = ['isystemid', 'cdt', 'refhierlabel', 'refhiervalue', 'reflabel', 'refvalue']
                        comp_df5 = comp_df4[cols]
                        if i=='SystemID/Tool/Chamber/':
                            comp_df6=comp_df5
                        else:
                            comp_df6=comp_df6.append(comp_df5)
                    comp_result_df = pd.concat([comp_df2, comp_df6])
                    return comp_result_df

                except Exception as e:
                    self.log_list.append("Componenet label status extraction error is {0} : ".format(repr(e)))

            comp_status_df_mdf=pd.DataFrame()
            for i in status_list_mdf:
                comp_status_df_mdf=status_df(i,result_df_mdf,comp_status_df_mdf)

            comp_status_df_ddf=pd.DataFrame()
            if len(result_df_ddf)>0:
                for i in status_list_ddf:
                    comp_status_df_ddf=status_df(i,result_df_ddf,comp_status_df_ddf)
                self.log_list.append('-----Status Calculcation for sub systemcomponets-----')
            else:
                self.log_list.append('-----No Status Calculcation for sub systemcomponets-----')

            #Status generates using multiple sub systemcomponets
            if len(comp_status_df_ddf)>0:
                listcomp=comp_status_df_ddf['refhierlabel'].str.split('/').str[3].unique().tolist()
                counter=0
                for z in listcomp:
                    hm_df=comp_status_df_ddf[((comp_status_df_ddf['refvalue'] == 'alarm') | (comp_status_df_ddf['refvalue'] == 'warning') 
                        | (comp_status_df_ddf['refvalue'] == 'online') | (comp_status_df_ddf['refvalue'] == 'offline')) & 
                                             (comp_status_df_ddf['refhierlabel'].str.contains(z))]

                    hm_list=hm_df.refvalue.unique().tolist()##hm_df.refvalue.iloc[i]
                    for i in range(0,len(hm_df)):
                        fm_df=pd.DataFrame()
                        #hm_list=hm_df.refvalue.iloc[i]
                        for column in hm_df.columns:
                            if column=='refvalue':
                                if ('offline' in hm_list) :
                                    fm_df['refvalue'] = ['offline']
                                elif ('alarm' in hm_list):
                                    fm_df['refvalue'] = ['alarm']
                                elif ('warning' in hm_list):
                                    fm_df['refvalue'] = ['warning']
                                else:
                                    fm_df['refvalue'] = ['online']
                            else:
                                fm_df[column]=[hm_df[column].values[i]]

                        fm_df['reflabel'] = fm_df['reflabel'].str.strip('/').str[:-2]
                        fm_df['refhierlabel'] = fm_df['refhierlabel'].str.strip('/').str[:-2]
                        fm_df['refhiervalue'] = "Combined_"+fm_df['reflabel'].str.strip('/').str[:-2]
                        sys_colm=['isystemid', 'cdt', 'refhierlabel', 'refhiervalue', 'reflabel',
                               'refvalue']
                    if counter==0:
                        counter=1         
                        cm_df=fm_df[sys_colm]
                    else:
                        cm_df=cm_df.append(fm_df[sys_colm])
                    cm_df.drop_duplicates(inplace=True)
                comp_status_df_ddf=comp_status_df_ddf.append(cm_df)
                self.log_list.append("-----Combined multiple sub systemcomponents status-----")
            else:
                self.log_list.append("-----No multiple subsystem components present to combined the status-----")

            comp_status_df=comp_status_df_mdf.append(comp_status_df_ddf)
            comp_status_df = comp_status_df.drop_duplicates().reset_index(drop=True)
            comp_result_df_2 = pd.concat([comp_status_df,final_df_3_mdf]).drop_duplicates().reset_index(drop=True)
            
            chamber_list = list(set(comp_result_df_2["refhiervalue"].to_list()))

            final_chamber = []
            for i in chamber_list:
                if (len(str(i).split('/')) == 3):
                    final_chamber.append(i)

            test_df = comp_status_df.head(0)
            test_1 = comp_status_df
            if len(test_1)>0:

                for element in final_chamber:
                    comp_status_df = test_1[test_1['refhiervalue'].str.contains(element)]

                    if len(comp_status_df[comp_status_df['refvalue'] == 'offline']) > 0:
                        comp_status_df = comp_status_df[comp_status_df['refvalue'] == 'offline'].head(1)

                    elif len(comp_status_df[comp_status_df['refvalue'] == 'alarm']) > 0:
                        comp_status_df = comp_status_df[comp_status_df['refvalue'] == 'alarm'].head(1)
                    elif len(comp_status_df[comp_status_df['refvalue'] == 'warning']) > 0:
                        comp_status_df = comp_status_df[comp_status_df['refvalue'] == 'warning'].head(1)
                    else:
                        comp_status_df = comp_status_df[comp_status_df['refvalue'] == 'online'].head(1)

                    comp_status_df['reflabel'] = 'comb_status_' + str(element[-1])
                    comp_status_df['refhierlabel'] = 'SystemID/Tool/Chamber/Components'
                    test_df = pd.concat([test_df, comp_status_df])
                    del comp_status_df
            
                comp_result_df = pd.concat([comp_result_df_2, test_df])
            else:
                comp_result_df= pd.DataFrame()
                comp_result_df = comp_result_df_2
            global TSTAMP
            comp_result_df['batch_time'] = TSTAMP

            self.log_list.append("info:-----Components Label Status Processed Successfully-----")

            """ Chambers label status extraction """

            df1_filt_chamber = comp_result_df[(comp_result_df['reflabel'] == 'ChamberAlarm') | (
                    comp_result_df['reflabel'] == 'ChamberWarning') | (
                                                  comp_result_df['reflabel'].str.contains("comb_status"))]
            df1_filt_chamber['chambers'] = df1_filt_chamber.refhiervalue.str.split('/').str[2]
            df2_filt_chamber = df1_filt_chamber.sort_values(by=['chambers', 'reflabel'], ascending=True)
            df2_filt_chamber['chamber_warning_label'] = (
                df2_filt_chamber.sort_values(by=['refhierlabel', 'cdt', 'isystemid', 'reflabel'],
                                             ascending=True).groupby(['chambers'])['reflabel'].shift(-1))
            df2_filt_chamber['chamber_warning_value'] = (
                df2_filt_chamber.sort_values(by=['refhierlabel', 'cdt', 'isystemid', 'reflabel'],
                                             ascending=True).groupby(['chambers'])['refvalue'].shift(-1))
            df2_filt_chamber['status_label'] = (
                df2_filt_chamber.sort_values(by=['refhierlabel', 'cdt', 'isystemid', 'reflabel'],
                                             ascending=True).groupby(['chambers'])['reflabel'].shift(-2))
            df2_filt_chamber['status_value'] = (
                df2_filt_chamber.sort_values(by=['refhierlabel', 'cdt', 'isystemid', 'reflabel'],
                                             ascending=True).groupby(['chambers'])['refvalue'].shift(-2))
            df3_filt_chamber = df2_filt_chamber[df2_filt_chamber['reflabel'].str.contains("ChamberAlarm")]

            df3_filt_chamber['chamber_status'] = np.where(
                ((df3_filt_chamber['refvalue'].isnull()) & (df3_filt_chamber['chamber_warning_value'].isnull())),
                df3_filt_chamber['status_value'],
                (np.where((df3_filt_chamber['refvalue'].notnull()), 'alarm', 'warning')))
            
            ##If ToolCommType==”No Tool” then all chamber_status would be online.
            ##if (comp_result_df['reflabel'] == 'ToolCommType').any() & (comp_result_df['refvalue'] == 'No Tool').any():
            if len(comp_result_df[(comp_result_df['reflabel'] == 'ToolCommType') & (comp_result_df['refvalue'] == 'No Tool')])==1:
                df3_filt_chamber['chamber_status']='online'
                self.log_list.append("info:-----ToolCommType value is No Tool-----")
            else:
                 self.log_list.append("info:-----ToolCommType value is not No Tool-----")

            cols = ['isystemid', 'cdt', 'refhierlabel', 'refhiervalue', 'reflabel', 'chamber_status', 'batch_time']
            df4_filt_chamber = df3_filt_chamber[cols]
            df4_filt_chamber.rename(columns={'chamber_status': 'refvalue'}, inplace=True)
            df4_filt_chamber.replace(to_replace="ChamberAlarm", value="chamber_status", inplace=True)
            result_df_filt_chamb = pd.concat([comp_result_df, df4_filt_chamber])

            comp_sys_comp=result_df_filt_chamb['refhierlabel'].str.split('/').str[4].unique().tolist()
            sys_num=[]
            for element in comp_sys_comp:
                try:
                    int(element) 
                    sys_num.append(element)
                except:
                    continue
            cdf=pd.DataFrame()
            if len(sys_num)>0:
                counter=0
                for element in sys_num:
                    df_1=result_df_filt_chamb[result_df_filt_chamb['refhierlabel'].str.contains('/'+element)]
                    if counter==0:
                        cdf=df_1
                        counter=1
                    else:
                        cdf=cdf.append(df_1)

                fdc=result_df_filt_chamb[~result_df_filt_chamb['refhierlabel'].isin(cdf['refhierlabel'].unique())]
                sys_list=cdf.refhiervalue.str.split('/').str[3].unique()
 
                for number in sys_num:
                    try:
                        int(number) 
                        cdf['refhierlabel']=cdf['refhierlabel'].str.replace('/'+number,'')
                    except:
                        continue 
                result_df_filt_chamber=pd.concat([fdc,cdf])

            else:
                result_df_filt_chamber=result_df_filt_chamb
            self.log_list.append("info:-----Chambers Label Status Processed Successfully-----")

            """Isystems label status extraction"""
            unique_list = result_df_filt_chamber[
                result_df_filt_chamber['reflabel'] == 'chamber_status'].refvalue.unique().tolist()

            df_new_filt = result_df_filt_chamber

            sys_comp_list=df_new_filt[(df_new_filt['reflabel'].str.contains('Status')) & (
            df_new_filt['refhierlabel'].str.contains('SystemID/Tool/SystemComponents'))].refhierlabel.str.split('/').str[3].unique().tolist()
                       
            df3_filt_sys_co=pd.DataFrame()
            if len(sys_comp_list)>0:
                for i in sys_comp_list:

                    df_2= df_new_filt[(df_new_filt['reflabel'] == i)  & (df_new_filt['refhierlabel'].str.contains('SystemID/Tool/SystemComponents'))]
                    df3_filt_sys_co=df3_filt_sys_co.append(df_2)
                sys_unique_list=df3_filt_sys_co.refvalue.unique().tolist()
            else:
                sys_unique_list=[]

            df3_filt_isys = df_new_filt[(df_new_filt['reflabel'] == 'Alarm') & (df_new_filt['refhierlabel'] == 'SystemID') | (
                        df_new_filt['reflabel'] == 'Warning') & (df_new_filt['refhierlabel'] == 'SystemID')]

            df3_filt_isys['SystemWarning_label'] = (
                df3_filt_isys.sort_values(by=['refhierlabel', 'cdt', 'isystemid', 'reflabel'], ascending=True).groupby(
                    ['refhierlabel', 'refhiervalue'])['reflabel'].shift(-1))
            df3_filt_isys['SystemWarning_value'] = (
                df3_filt_isys.sort_values(by=['refhierlabel', 'cdt', 'isystemid', 'reflabel'], ascending=True).groupby(
                    ['refhierlabel', 'refhiervalue'])['refvalue'].shift(-1))
            df4_filt_isys = df3_filt_isys[df3_filt_isys['reflabel'].str.contains("Alarm")]


            if ('offline' in unique_list) | ('offline' in sys_unique_list):
                df4_filt_isys['isystem_status'] = 'offline'
            elif ('alarm' in unique_list) | ('alarm' in sys_unique_list) | (df4_filt_isys.refvalue.notnull().any()):
                df4_filt_isys['isystem_status'] = 'alarm'
            elif ('warning' in unique_list) | ('warning' in sys_unique_list) | (df4_filt_isys.SystemWarning_value.notnull().any()):
                df4_filt_isys['isystem_status'] = 'warning'
            else:
                df4_filt_isys['isystem_status'] = 'online'

            final_cols = ['isystemid', 'cdt', 'refhierlabel', 'refhiervalue', 'reflabel', 'isystem_status',
                          'batch_time']
            df_final_isystem = df4_filt_isys[final_cols]
            df_final_isystem.rename(columns={'isystem_status': 'refvalue'}, inplace=True)
            df_final_isystem.replace(to_replace="Alarm", value="isystem_status", inplace=True)
            isystem_final_df = pd.concat([result_df_filt_chamber, df_final_isystem])
            self.log_list.append("info:-----Isystem Label Status Processed Successfully------")

            """replace SystemID value by ProcessToolID value"""
            new_value = isystem_final_df.loc[isystem_final_df['reflabel'] == 'ProcessToolID', ['refvalue']]['refvalue'].iloc[0]
            old_value = isystem_final_df.loc[isystem_final_df['reflabel'] == 'SystemID', ['refvalue']]['refvalue'].iloc[0]
            isystem_final_df['refvalue'] = isystem_final_df['refvalue'].apply(lambda x: new_value if (x == old_value) else x)
            self.log_list.append("info:-----Systemid Extraction Completed------")

            """add components in numbers in refvalue columns"""
            final_isys = isystem_final_df[isystem_final_df['reflabel'] == "Number"]
            final_isys['comp_vals'] = final_isys.refhierlabel.str.split("/").str[-1] + '-' + final_isys['refvalue']
            final_isys['refvalue'] = final_isys['comp_vals']
            final_isys.drop(['comp_vals'], axis=1, inplace=True)
            final_isys['refvalue']=final_isys['refvalue'].str.replace('Status', '', regex=True)            
            isystem_final_df = isystem_final_df[isystem_final_df['reflabel'] != "Number"]
            isystem_final_df_1 = pd.concat([isystem_final_df, final_isys], ignore_index=True)
            self.log_list.append("info:-----Componets values added in numbers-----")

            """If label data is missing then replace chamber name in label value"""

            label_df = isystem_final_df_1[isystem_final_df_1['reflabel'] == "Label"]
            for i in range(0, len(label_df)):
                if (label_df['refvalue'].iloc[i] == None):
                    label_df['refvalue'].iloc[i] = label_df['refhiervalue'].iloc[i][-1]

                else:
                    label_df['refvalue'].iloc[i] = label_df['refvalue'].iloc[i]

            isystem_final_df_1 = isystem_final_df_1[isystem_final_df_1['reflabel'] != "Label"]
            isys_final_label = pd.concat([isystem_final_df_1, label_df], ignore_index=True)
            self.log_list.append("info:-----Label Value Extraction Completed-----")


            """If subfablevel is missing or value is 0 then the default subfablevel value should be 1 """

            sub_df = isys_final_label[isys_final_label['reflabel'] == "SubfabLevel"]
            #sub_df['refvalue'].fillna(value=1, inplace=True)
            #sub_df['refvalue'] = sub_df['refvalue'].astype(int).apply(lambda x: 1 if (math.isnan(x) or x == 0) else x)
            sub_df['refvalue']=sub_df['refvalue'].replace(np.nan,1).replace(0,1)
            isys_final_label = isys_final_label[isys_final_label['reflabel'] != "SubfabLevel"]
            isys_final = pd.concat([isys_final_label, sub_df], ignore_index=True)
            self.log_list.append("info:-----SubfabLevel Extraction Completed-----")

            """Modifying refhiervalue using last element of refhierlabel(components) and adding the same components value with last element of refhiervalue  """

            isys_final_compute_analog = isys_final[isys_final['refhierlabel'].str.contains('/Analogs/Item/')]
            isys_final_compute = isys_final[~isys_final['refhierlabel'].str.contains('/Analogs/Item/')]
            isys_final_comp = isys_final_compute[isys_final_compute['refhierlabel'].str.contains('Status')]
            isys_final_comp_status = isys_final_compute[~isys_final_compute['refhierlabel'].str.contains('Status')]
            isys_final_rem =pd.concat([isys_final_compute_analog,isys_final_comp_status],ignore_index=True)

            def num_rem(x):
                y=copy.deepcopy(x)
                len_str=len(str((x).split("/")[-1]))
                y=str(y)[:-1*len_str]+"/"
                return y

            isys_final_comp['refhiervalue_1'] = isys_final_comp.refhierlabel.str.split("/").str[-1] + "" + \
                                                isys_final_comp.refhiervalue.str.split("/").str[-1]

            isys_final_comp['refhiervalue']=isys_final_comp['refhiervalue'].apply(lambda x: num_rem(x))


            if len(isys_final_comp.index)==0:
                isys_final_comp['refhiervalue_2'] = isys_final_comp.refhiervalue.str[:-1] + isys_final_comp.refhiervalue_1

            else:
                if len(isys_final_comp.refhiervalue.str.split("/").str[-1].tolist()[0]) > 1:
                    refv_list=["/".join(i) for i in isys_final_comp.refhiervalue.str.split("/").str[:-1]]
                    for i in zip(refv_list,isys_final_comp.refhiervalue_1):
                        isys_final_comp["refhiervalue_2"]=i[0]+'/'+i[1]
                else:  
                    isys_final_comp['refhiervalue_2'] = isys_final_comp.refhiervalue.str[:-1] + isys_final_comp.refhiervalue_1

            isys_final_comp['refhiervalue'] = isys_final_comp['refhiervalue_2'] 
            isys_final_comp.drop(['refhiervalue_1', 'refhiervalue_2'], axis=1, inplace=True)
            isys_final_1 = pd.concat([isys_final_rem, isys_final_comp], ignore_index=True)
            self.log_list.append("info:-----Componenets level refhiervalue modified-----")

            """Modifying refhiervalue using last element of refhierlabel(components) and adding the same components value with last element of refhiervalue  for analog data"""

            #isys_final_1_analog = isys_final_1[
            #    isys_final_1.iloc[:, 2].str.contains(r'\b(?:{})\b'.format('|'.join(self.partial_filter)))]
            #isys_final_1_rem = isys_final_1[
            #    ~isys_final_1.iloc[:, 2].str.contains(r'\b(?:{})\b'.format('|'.join(self.partial_filter)))]

            isys_final_1_analog = isys_final_1[
                isys_final_1.iloc[:, 2].str.contains('|'.join(self.partial_filter))]
            isys_final_1_rem = isys_final_1[
                ~isys_final_1.iloc[:, 2].str.contains('|'.join(self.partial_filter))]

            isys_final_1_analog['refhiervalue_1'] = isys_final_1_analog.refhierlabel.str.split("/").str[3] + "" + \
                                                    isys_final_1_analog.refhiervalue.str.split("/").str[-1]

            isys_final_1_analog['refhiervalue']=isys_final_1_analog['refhiervalue'].apply(lambda x: num_rem(x))

            if len(isys_final_1_analog.index)==0:
                isys_final_1_analog['refhiervalue_2'] = isys_final_1_analog.refhiervalue.str[:-1] + isys_final_1_analog.refhiervalue_1

            else:   
  
                if len(isys_final_1_analog.refhiervalue.str.split("/").str[-1].tolist()[0]) > 1:

                    refh_list=["/".join(i) for i in isys_final_1_analog.refhiervalue.str.split("/").str[:-1]]
                    for i in zip(refh_list,isys_final_1_analog.refhiervalue_1):
                        isys_final_1_analog["refhiervalue_2"]=i[0]+'/'+i[1]
                else:
                     isys_final_1_analog['refhiervalue_2'] = isys_final_1_analog.refhiervalue.str[:-1] + isys_final_1_analog.refhiervalue_1

            isys_final_1_analog['refhiervalue'] = isys_final_1_analog['refhiervalue_2']
            isys_final_1_analog.drop(['refhiervalue_1', 'refhiervalue_2'], axis=1, inplace=True)
           
            """Remove non numeric entries from analog data"""

            def rem_non_numeric(str_val):
                try:
                    s_val=float(str_val.split("|@value")[1].split('(')[1].replace(")",""))
                    s_num=isinstance(s_val,float)
                except:
                    s_num=False
                return s_num

            isys_final_1_analog['filter_value']=isys_final_1_analog["refvalue"].apply(lambda x:rem_non_numeric(x))
            isys_final_1_analog=isys_final_1_analog[isys_final_1_analog['filter_value']==True]
            isys_final_1_analog.drop(['filter_value'], axis=1, inplace=True)
            isys_final_ad = pd.concat([isys_final_1_rem, isys_final_1_analog], ignore_index=True)
            self.log_list.append("info:-----Analogs level refhiervalue modified-----")

            """ Added section,department and ProcessToolID columns in the datframe """
            
            section = isys_final_ad[
                (isys_final_ad['refhierlabel'] == "SystemID/Header") & (isys_final_ad['reflabel'] == "Section")]
            department = isys_final_ad[
                (isys_final_ad['refhierlabel'] == "SystemID/Header") & (isys_final_ad['reflabel'] == "Department")]
            process = isys_final_ad[
                (isys_final_ad['refhierlabel'] == "SystemID") & (isys_final_ad['reflabel'] == "ProcessToolID")]
            processtoolid = process['refvalue'].iloc[0]
            sec = section['refvalue'].iloc[0]
            bu = department['refvalue'].iloc[0]
            isys_final_ad['section'] = str(sec)
            isys_final_ad['department'] = str(bu)
            isys_final_ad['ProcessToolID'] = str(processtoolid)
            cols = ['isystemid', 'cdt', 'refhierlabel', 'refhiervalue', 'reflabel', 'refvalue', 'section', 'department',
                    'ProcessToolID', 'batch_time']
            isys_final_ad = isys_final_ad[cols]

            """Add extra records for alarm,warning,systemalarm,systemwarning,chamberalarm and chamber warning by spliting all these values"""

            ala_list = ['Alarm', 'Warning', 'SystemAlarm', 'SystemWarning', 'ChamberAlarm', 'ChamberWarning']
            df_ala = isys_final_ad[isys_final_ad['reflabel'].isin(ala_list)]
            df_ala['length'] = df_ala['refvalue'].apply(lambda x: len(str(x).split('|')))
            uni_ala_warn_list = df_ala['length'].unique().tolist()
            final_ala = isys_final_ad.head(0)
            for element in uni_ala_warn_list:
                for i in range(0, element):
                    temp_ala = df_ala[df_ala['length'] == element]
                    temp_ala["refvalue"] = temp_ala["refvalue"].apply(lambda x: str(x).split('|')[i])
                    final_ala = final_ala.append(temp_ala)

            final_ala.drop(['length'], axis=1, inplace=True)
            final_ala = final_ala[cols]
            isys_out_ala = isys_final_ad[~isys_final_ad['reflabel'].isin(ala_list)]
            isys_with_ala = pd.concat([isys_out_ala, final_ala], ignore_index=True)
            

            """Deleteing discrete and no units entries from analog data"""

            to_drop = ["0=False 1=True", "no units", "NoUnits"]
            isys_with_ala = isys_with_ala[~isys_with_ala['refvalue'].str.contains('|'.join(to_drop), na=False)]
            self.log_list.append("info:-----Discrete/No units entries deleted from analog data-----")

            """Adding location,model and manufacturer columns """

            isys_mo = isys_with_ala[isys_with_ala['reflabel'] == "Model"]
            isys_mo.drop(['isystemid', 'cdt', 'refhierlabel', 'section', 'department', 'ProcessToolID', 'batch_time'], axis=1,
                         inplace=True)
            isys_model = pd.merge(isys_with_ala, isys_mo[['refhiervalue', 'refvalue']], on='refhiervalue', how='left')
            isys_model['model'] = isys_model['refvalue_y']
            isys_model.drop(['refvalue_y'], axis=1, inplace=True)
            isys_model.rename(columns={'refvalue_x': 'refvalue'}, inplace=True)
            isys_manf = isys_model[isys_model['reflabel'] == "Manufacturer"]
            isys_manf.drop(
                ['isystemid', 'cdt', 'refhierlabel', 'section', 'department', 'ProcessToolID', 'model', 'batch_time'], axis=1,
                inplace=True)
            isys_manfacture = pd.merge(isys_model, isys_manf[['refhiervalue', 'refvalue']], on='refhiervalue', how='left')
            isys_manfacture['manufacturer'] = isys_manfacture['refvalue_y']
            isys_manfacture.drop(['refvalue_y'], axis=1, inplace=True)
            isys_manfacture.rename(columns={'refvalue_x': 'refvalue'}, inplace=True)
            isys_loc = isys_manfacture[isys_manfacture['reflabel'] == "Location"]
            isys_loc.drop(
                ['isystemid', 'cdt', 'refhierlabel', 'section', 'department', 'ProcessToolID', 'model', 'manufacturer',
                 'batch_time'], axis=1, inplace=True)
            isys_location = pd.merge(isys_manfacture, isys_loc[['refhiervalue', 'refvalue']], on='refhiervalue', how='left')
            isys_location['location'] = isys_location['refvalue_y']
            isys_location.rename(columns={'refvalue_x': 'refvalue'}, inplace=True)
            isys_location.drop(['refvalue_y'], axis=1, inplace=True)
            isys_location['model'].fillna('NA', inplace=True)
            isys_location['manufacturer'].fillna('NA', inplace=True)
            isys_location['location'].fillna('NA', inplace=True)
            cols = ['isystemid', 'cdt', 'refhierlabel', 'refhiervalue', 'reflabel', 'refvalue', 'section', 'department',
                    'ProcessToolID', 'model', 'manufacturer', 'location', 'batch_time']
            isys_complete = isys_location[cols]
            isys_complete.refvalue.replace("None","", inplace=True)
            isys_complete['refhiervalue']=isys_complete['refhiervalue'].str.replace('Status', '', regex=True)
            isys_complete_final=isys_complete[~isys_complete['reflabel'].isin(self.restrict_records)]
            isys_complete_final.reset_index(inplace=True)
            isys_complete_final['row_n']=isys_complete_final.index
            isys_complete_final['reflabel']=isys_complete_final['row_n'].apply(lambda x: isys_complete_final['reflabel'].iloc[x].replace('/'+str(isys_complete_final['reflabel'].iloc[x]).split('/')[-1],'') if (len(str(isys_complete_final['reflabel'].iloc[x]).split('/'))>1) & ('SystemID/Tool/SystemComponents/' in isys_complete_final['refhierlabel'].iloc[x]) else isys_complete_final['reflabel'].iloc[x])
            del isys_complete_final['row_n']
            #isys_complete_final.to_excel("isys_complete_final.xlsx",index=False)
            #isys_complete_final.to_json("isys_complete_final.json",orient='records')
            self.log_list.append("info:-----Parser job completed---")
            self.log_list.append("info:-----isys_complete_final dataframe shape is {0}-----".format(isys_complete_final.shape))

            return isys_complete_final

        except Exception as e:
            self.log_list.append("Parser Error is {0} : ".format(repr(e)))
        finally:
            s = open(self.log_path + "/" + "log_xml_parser.log", 'a')
            for element in self.log_list:
                print(element)
                s.write(str(datetime.datetime.now()) + "::" + str(element) + "\n")
            s.write("\n\n\n\n")
            s.close()