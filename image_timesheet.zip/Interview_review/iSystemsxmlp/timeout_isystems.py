import  pandas as pd
import yaml
from datetime import datetime,timedelta
import warnings
import requests
from logger import LOG
warnings.filterwarnings("ignore")

TIME_OBJ = datetime.now()
TSTAMP = TIME_OBJ.strftime("%Y-%m-%d %H:%M:%S")
#last_processed = datetime.now() - timedelta(minutes=10) ##remove this deployement time

LOG.info("Timeout Isystem job has started at "+TSTAMP)
try:
    with open("conf/conf.yaml", 'r') as conf_yaml:
                conf_details = yaml.load(conf_yaml)
    post_url = conf_details.get("API").get("url")
    timeout_min=int(conf_details.get('Timeout').get('minutes'))
except Exception as e:
    LOG.error("Cannot open config file. The error is \n : {0}".
        format(e))	


read_df=pd.read_csv("isystem.csv")
LOG.info("isystem csv data reading is successfully completed!")

#global TSTAMP
read_df.rename(columns={'cdt_val': 'cdt'}, inplace=True)
read_df['refhierlabel']='SystemID'
read_df['refhiervalue']= read_df['isystemid']
read_df['reflabel']='SystemOfflineAlarm' 
#read_df['refvalue']='offline|System update timeout'
#if((datetime.now() - last_processed).seconds > 30):    ##remove if statement deployement time
read_df['refvalue'] = read_df['cdt'].apply(lambda x : "offline|System update timeout" if (datetime.now() - datetime.strptime(x,"%Y-%m-%d %H:%M:%S")).days*24*3600+(datetime.now() - datetime.strptime(x,"%Y-%m-%d %H:%M:%S")).seconds > timeout_min*60 else False)
#read_df['time_diff']=read_df['cdt'].apply(lambda x :(datetime.now() - datetime.strptime(x,"%Y-%m-%d %H:%M:%S")).days*24*3600+(datetime.now() - datetime.strptime(x,"%Y-%m-%d %H:%M:%S")).seconds)
read_df=read_df[read_df['refvalue'] != False]
read_df['batch_time']= str(TSTAMP) 
print(read_df)
read_df.to_csv("read_df.csv",index=False)
#read_df.to_json("read_df.json",orient='records')
LOG.info("not responding isystems list is ready to dump in solr!")
            

#last_processed = datetime.now()  ##remove this statement in deployement time
###Write read_df data to json file and push json to API
# read_df_json=read_df.to_json(orient='records')
# payload = read_df_json
# LOG.info("not responding isystems json file got created!")
# try:
#     headers = {'Content-Type': "text/xml/json", 'Accept': 'application/json'}
#     response_api= requests.request("POST",post_url,data=payload, headers=headers)
#     LOG.info("----------JSON data loaded into API Successfully!!---------------")
# except Exception as e:
#     LOG.error("Connect to solr is failed. The error is \n : {0}".
#                            format(e))
LOG.info("Timeout Isystem job completetd successfully! at "+TSTAMP)