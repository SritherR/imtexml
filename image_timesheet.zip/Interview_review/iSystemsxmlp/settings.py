import os
#import sys
#env_type = 'Windows'

#conf_file = str(os.getcwd())+"\\conf\\conf.yaml"

project_root=os.path.dirname(os.path.abspath(__file__))
conf_file_path=os.path.join(project_root,"conf")
conf_file = os.path.join(conf_file_path,"conf.yaml")