# -*- coding: utf-8 -*-
"""
Created on Wed Dec 18 14:17:14 2019

@author: SKarmakarX0106132
"""

import pytest
import os
import xml_finder 
from db import PgSQLUtil
import yaml

from sqlalchemy import create_engine
import pandas as pd

def MatchFileCount(sourcepathfilecount,archivepath,errorxmlpath):
    
    archivelist = os.listdir(archivepath) 
    errorxmllist = os.listdir(errorxmlpath) 
    
    assert sourcepathfilecount==len(archivelist)+len(errorxmllist),'Test Failed,Total Count of files does not match in the source path and with the combination of error and processed path'
    
    #assert len(sourcelist)==len(archivelist)+len(errorxmllist),'Test Passed, Files are matched properly'
    
    
def CheckDBConnection(con_file):
    with open(conf_file, 'r') as conf_yaml:
        config_detail = yaml.safe_load(conf_yaml)
        host = config_detail.get("postgresql").get("host")
        user = config_detail.get("postgresql").get("user")
        passwd = config_detail.get("postgresql").get("passwd")
        db = config_detail.get("postgresql").get("db")
        engine = create_engine('postgresql+psycopg2://{0}:{1}@{2}/{3}'.format(user,passwd,host,db))
        conn=engine.connect()

        df = pd.read_sql("select * from {0} LIMIT 5".format(config_detail.get("XML_tables").get("parser_table")),con=conn)
        
        assert df.shape[0] > 0,'Test Failed, Connection to database failed'

def getSourcepathCount(conf_file):
    with open(conf_file, 'r') as conf_yaml:
            conf_details = yaml.load(conf_yaml)
            sourcepath=conf_details.get("watched").get("watched_path")+'\\r4prex409isys\DB'
    
    return len(os.listdir(sourcepath))        
    


if __name__ == "__main__":
    conf_file = "conf/conf.yaml"
    sourcepathfilecount=getSourcepathCount(conf_file)
    
    file_pro = xml_finder.xml_observer(conf_file)
    sourcepath=file_pro.watched_path+'\\r4prex409isys\DB'
    archivepath=file_pro.xml_archived_path
    errorxmlpath=file_pro.error_xml_path
    
    df=file_pro.file_processor()
    
    MatchFileCount(sourcepathfilecount,archivepath,errorxmlpath)
    
    CheckDBConnection(conf_file)
    
    
