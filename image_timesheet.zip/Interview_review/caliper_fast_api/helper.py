# coding: utf-8

"""
  Helper Module: Obtains information from caliper db

  Classes
  --------
  ImageProcessor: Calls helper functions needed to retrieve information from caliper db

"""

__author__ = ["Divya Shankar", "Samuel Joshua", "Srither Ranjan"]
__version__ = 1.0

 # Standard Library
import warnings
import datetime
import json
import uuid
from uuid import uuid4
# Third Party Library
import pandas as pd
import requests
import numpy as np
# Application Specific Library
import re
import base64
import pytz
from database import Connector 
import pickle
import smtplib
from edit_measurements import edit_measure
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
import os
from email.mime.application import MIMEApplication
#from edit_measurements import edit_measure
source_path_dev = "/var/lib/cdsw/calip-nas-dev/"
nas_measurement_path = r"/var/lib/cdsw/calip-nas-dev/measurements/"
lims_db_qa = "http://sc-db-315/smslimscache/api/images/"
class caliperApiHelper():
  
  """
    Calls helper functions needed to retrieve information from caliper db
  """
  
  @classmethod
  def match_user_algo(cls, email_id):

    """
      For a given email_id, this function will return algo_id's user has access to and corresponding algorithm names

      Parameters
      -----------
      email_id: Accepts email_id for which we need the algo_id accessible by the email_id

      Returns
      --------
      user_algo_dict: Dictionary of email_id & algorithms 
                              {
                               'email_id':'values',
                               'algos': [{algo_id, algo_name, config_params}, {algo_id, algo_name, config_params}]
                              }

    """
    test_connection = None
    try:
      test_connection = Connector.create_connection()        
      df_user = pd.read_sql("SELECT * FROM caliper.user_algo WHERE email_id = '" + email_id + "'",test_connection)
      if df_user.shape[0] == 0:
          return {"Error","No record found for given email_id in user_algo table"}

      else:
          print("Found record for given email_id")

          # Group by user_id and get the list of algo_id which the user_id has access to
          df_match_user_algo = df_user.groupby('email_id')['algo_id'].apply(list).reset_index(name='algo_id_accessible')

          # Convert the groupby dataframe to dictionary: {'user_id':'x...','algos_accessible':[algo_id]}
          match_user_algo_record = df_match_user_algo.to_dict('r')[0]
          print(match_user_algo_record)

          # Extract values (algo_id) for key 'algos_accessible'
          algo_id_lst = match_user_algo_record['algo_id_accessible']
          print("algo_id_list",algo_id_lst)
          if len(algo_id_lst)==1:
            algo_id_lst = algo_id_lst+algo_id_lst 
          # Call get_algo_name to get name of algorithms in algo_lst
          algo_info_record = cls.get_algo_info(algo_id_lst)

          """
            RETURN THE FOLLOWING

            {
             "user_id": "x010768",
             "algos": [{algo_id, algo_name, config_params}, {algo_id, algo_name, config_params}]
            }

          """

          user_algo_info_dict = dict({'email_id':email_id,'algos':algo_info_record})

          return user_algo_info_dict

    except Exception as e:
      raise e

    finally:
      if test_connection:
        test_connection.close()
        
  @classmethod
  def get_algo_info(cls, algo_lst):
    """
      For a given list of algo_id's, it will return corresponding algo_names

      Parameters
      -----------
      algo_lst: List of algo_id

      Returns
      --------
      algo_names_record: List of dictionaries for algorithm info such as [{algo_id, algo_name, config_params}, 
                                                                      {algo_id, algo_name, config_params}]

    """

    len_algo_lst = len(algo_lst)
    test_connection = None

    if len_algo_lst == 0:
      return{"Error":"Invalid Input!"}

    else:

      try:
        test_connection = Connector.create_connection()

        # To pass a list to SQL Query it has to be in (1,2,3,4,5) format, not [1,2,3,4,5]
        temp_algo_lst = tuple(algo_lst)
        print(temp_algo_lst,'temp_algo_lst')
        df_algo = pd.read_sql(f"SELECT algo_id, algo_name, config_params, required_inputs FROM caliper.algo WHERE algo_id IN {temp_algo_lst}",test_connection)

        if df_algo.shape[0] == 0:
            return{"Error","No record found for given algo_id in algo table"}

        else:
            print("Found record for given algo_id")

            # Storing  algo_id, algo_name, and config_params in a list of dictionaries

            #df_algo['config_params'] = df_algo['config_params'].astype(str)
            #df_algo['config_params'] = df_algo['config_params'].str.replace("'", '"')
            #df_algo['config_params'] = df_algo['config_params'].apply(lambda x: json.loads(x))
            algo_names_record = df_algo.to_dict(orient='records')

        return algo_names_record

      except Exception as e:
        raise e

      finally:
        if test_connection:
          test_connection.close()

  """
  @classmethod
  def insert_job_run_table(cls,record):
      print("called job run table")
      test_connection = None
      try:
          test_connection = Connector.create_connection()
          engine = Connector.get_engine()
          cursor = test_connection.cursor()
         
          algo_id = record.algo_id
          job_id = str(record.job_id)
          demo_id = record.demo_id
          image_id = record.image
          image_name = record.image_name
          bounding_box = record.inputs["bounding_box"]
          pixel_size = record.inputs["pixel_size"]
          uuid = str(record.uuid)
          sql = f"INSERT INTO caliper.job_run (uuid,job_id,demo_id,image_filename,image_id,algo_id,binary_op,rotation_angle,bounding_box,pixel_size,output_binary_values,config,start_ts, end_ts,error,sample_id, measurements_file,status,measurements) VALUES ('{uuid}','{job_id}','{demo_id}',null,{image_id},{algo_id},null,null,'{bounding_box}',{pixel_size},null,null,null,null,null,null,null,null,null)"
          cursor.execute(sql)
          test_connection.commit()
          print("sql-----",sql)
          print("inserted")
          return ({"uuid":uuid,"imageName":image_name,"imageId":image_id})
      except Exception as e:
        raise e
      finally:


        if test_connection:
          test_connection.close()




  """

  @classmethod
  def insert_job_run_table(cls,record,nas_image, user_name):
      """
      Insert the details into job_run table
      
      Parameters:
      -------------
      Get the put and post method request and insert the record in to job run table.
      
      Returns:
      -------------
      Return the uuid, image name and image id as response
      """
      print("\n\n\n\n called job run table", user_name)
      test_connection = None
      if 1==1:
          test_connection = Connector.create_connection()
          engine = Connector.get_engine()
          cursor = test_connection.cursor()

          algo_id = record["algo_id"]
          job_id =  str(record["job_id"])
          job_id = job_id.strip()
          demo_id = record["demo_id"].strip()
          image_id = record["image"]
          image_name = record["image_name"].strip()
          image_name = image_name.strip()
         
          image_obj = record["imageObject"]
          bounding_box =json.dumps(record["inputs"]["bounding_box"],default=str)
          pixel_size = json.dumps(record["inputs"]["pixel_size"],default=str)
          rotation_angle = record["inputs"]["rotate"]
          uuid = record["uuid"].strip()
          config_param = record["inputs"]["config_param"].keys()
          #print(config_param,"----")
          db_uuid = pd.read_sql(f"SELECT uuid,job_id,demo_id,image_filename FROM caliper.job_run",test_connection)
          db_uuid_list=list(db_uuid['uuid'])
          db_job_id_list = list(db_uuid["job_id"])
          db_demo_id_list = list(db_uuid["demo_id"])
          db_image_name_list = list(db_uuid["image_filename"])
          print(image_id,"image_id")
          print(uuid,"uuid")
          if uuid == "":
            print("uuid is empty")
            de_uuid = uuid.uuid4()
            print(de_uuid)
            uuid = str(de_uuid)
          if image_id == None: 
            image_id = "null"
          if rotation_angle == None:
            rotation_angle = "null"
          print("rotation angle")
          """
          if len(config_param)==0:
            #config_param = josn.dumps(record["inputs"]["config_param"],default=str)
            if algo_id!="":
              algo_record = pd.read_sql(f"select config_params from caliper.algo where algo_id = {algo_id}",test_connection)
              if algo_record.shape[0]== 0:
                config_param = {}
              else:
                config = algo_record.to_dict('r')[0]
                config_param = config["config_params"]
            else:
              config_param = {}     
              #f"UPDATE caliper.job_run set image_filename = '{result_list[4]}',output_binary_values= '{result_list[11]}',start_ts = '{result_list[13]}'
            config_param = json.dumps(config_param,default=str)
          else:
            config_param = json.dumps(record["inputs"]["config_param"],default=str)
          print("uuid-------")
          """
          if uuid in db_uuid_list:
            print("****1***************")
            uuid_status =  pd.read_sql(f"SELECT status from caliper.job_run where uuid='{uuid}'",test_connection)
            status = uuid_status.to_dict('r')[0]
            status = status["status"]    
            if status != 'success':
              algo_id=''
            sql=f"UPDATE caliper.job_run set uuid = '{uuid}',job_id = '{job_id}',demo_id = '{demo_id}',image_filename = '{image_name}',image_id = {image_id},rotation_angle = {rotation_angle},bounding_box = '{bounding_box}',pixel_size = '{pixel_size}',status = '{status}',nas_image_status = {nas_image},edit_measurement='null',user_name='{user_name}' where uuid='{uuid}'"
          
          elif (job_id in db_job_id_list) & (demo_id in db_demo_id_list) & (image_name in db_image_name_list):
            uuid_record = pd.read_sql(f"SELECT uuid from caliper.job_run where job_id='{job_id}' and demo_id = '{demo_id}' and image_filename = '{image_name}'",test_connection)
            if uuid_record.shape[0]!=0:
              uuid = uuid_record.to_dict('r')[0]
              uuid = uuid["uuid"]
              print("matched_uuid",uuid)  
              uuid_status =  pd.read_sql(f"SELECT status,algo_id from caliper.job_run where uuid='{uuid}'",test_connection)
            
              status = uuid_status.to_dict('r')[0]
              algo_id = status['algo_id']
              status = status["status"]
              if status!='success':
                algo_id=''
              print("****   2   ***************")
              sql = f"UPDATE caliper.job_run set uuid = '{uuid}',job_id = '{job_id}',demo_id = '{demo_id}',image_filename = '{image_name}',image_id = {image_id},rotation_angle = {rotation_angle},bounding_box = '{bounding_box}',pixel_size = '{pixel_size}',status = '{status}',nas_image_status = {nas_image},edit_measurement='null',user_name='{user_name}' where uuid='{uuid}'"
            else:
              print("****   5 else  ***************")
              sql = f"INSERT INTO caliper.job_run (uuid,job_id,demo_id,image_filename,image_id,algo_id,binary_op,rotation_angle,bounding_box,pixel_size,output_binary_values,config,start_ts, end_ts,error,sample_id, measurements_file,status,measurements,nas_image_status,edit_measurement,user_name) VALUES ('{uuid}','{job_id}','{demo_id}','{image_name}',{image_id},'',null,{rotation_angle},'{bounding_box}','{pixel_size}',null,null,null,null,null,null,null,'pending',null,'{nas_image}','null','{user_name}')"

          elif image_obj!="" or image_obj=="":
            status = "pending"
            if image_name in db_image_name_list:
              image_obj_uuid = pd.read_sql(f"SELECT uuid from caliper.job_run where image_filename = '{image_name}'",test_connection)
              uuid = image_obj_uuid.to_dict('r')[0]
              uuid = uuid['uuid']
              print(uuid,"uuid")
              uuid_status =  pd.read_sql(f"SELECT status,status from caliper.job_run where uuid='{uuid}'",test_connection)
              status = uuid_status.to_dict('r')[0]
              status = status["status"]
              algo_id = status['algo_id']
              if status!='success':
                algo_id='' 
              print("****   3   ***************")
              sql = f"UPDATE caliper.job_run set uuid = '{uuid}',job_id = '{job_id}',demo_id = '{demo_id}',image_filename = '{image_name}',image_id = {image_id},rotation_angle = {rotation_angle},bounding_box = '{bounding_box}',pixel_size = '{pixel_size}',status = '{status}',nas_image_status={nas_image},edit_measurement='null',user_name='{user_name}' where image_filename='{image_name}'"
            else:
              print("****   4   ***************")
              sql = f"INSERT INTO caliper.job_run (uuid,job_id,demo_id,image_filename,image_id,algo_id,binary_op,rotation_angle,bounding_box,pixel_size,output_binary_values,config,start_ts, end_ts,error,sample_id, measurements_file,status,measurements,nas_image_status,edit_measurement,user_name) VALUES ('{uuid}','{job_id}','{demo_id}','{image_name}',{image_id},'',null,{rotation_angle},'{bounding_box}','{pixel_size}',null,null,null,null,null,null,null,'pending',null,'{nas_image}','null','{user_name}')"

          else:
            print("generated_uuid",uuid)
            sql = f"INSERT INTO caliper.job_run (uuid,job_id,demo_id,image_filename,image_id,algo_id,binary_op,rotation_angle,bounding_box,pixel_size,output_binary_values,config,start_ts, end_ts,error,sample_id, measurements_file,status,measurements,nas_image_status,edit_measurement,user_name) VALUES ('{uuid}','{job_id}','{demo_id}','{image_name}',{image_id},'',null,{rotation_angle},'{bounding_box}','{pixel_size}',null,null,null,null,null,null,null,'pending',null,'{nas_image}','null','{user_name}')"
          print("sql-----",sql)
          cursor.execute(sql)
          test_connection.commit()
          print("inserted")
          return({"uuid":uuid,"imageName":image_name,"imageId":image_id,"nas_image_status":nas_image})
          
          
      else:
        return {"error":str(e),"message":"uuid not stored in db properly"}
     
      if test_connection:
      	test_connection.close()



  class NumpyEncoder(json.JSONEncoder):
      """
      Note: Converting all the numpy data types to python object type (numpy arrat to python list)
      """
      def default(self, obj):
        if isinstance(obj, np.integer):
          return int(obj)
        elif isinstance(obj, np.floating):
          return float(obj)
        elif isinstance(obj, np.ndarray):
          return obj.tolist()
        elif isinstance(obj, np.bool_):
          return bool(obj)
        elif np.isnan(obj):
          return "null"
        return json.JSONEncoder.default(self, obj)

  @classmethod
  def get_job_id_status(cls,image_job_id):
    """
    For a given job_id ,this function will get the record from job run table where job_id is matching
    Parameters:
    -----------
    Image_job_id : list of image_id
    
    Returns:
    ---------
    Return the uuid.image id,image_filename,status and error as response
    """
    try:
      test_connection = Connector.create_connection() 
      if image_job_id!="":
        df_record = pd.read_sql(f"SELECT uuid,image_id,image_filename,status,error,pixel_size,bounding_box,nas_image_status FROM caliper.job_run WHERE job_id = '{image_job_id}'",test_connection)
      else:
        print("image_job_id_empty")
        df_record = pd.read_sql(f"SELECT uuid,image_id,image_filename,status FROM caliper.job_run WHERE job_id = ''",test_connection)
     
      if df_record.shape[0]==0:
          return [{"Error":"given job_id is not present in job_run table"}]
      else:
        print("Found image Job_id")
        #df_record = df_record.fillna('')
        job_id_dict = df_record.to_dict('r')
        print(job_id_dict)
        """
        response_dict = dict()
        print("Job_id_dict",job_id_dict)
        uuid= job_id_dict['uuid']
        image_id = job_id_dict["image_id"]
        response_dict["uuid"] = uuid
        response_dict["image_id"]=image_id
        return response_dict
        """
        return job_id_dict
      
    except Exception as e:
        raise e

    finally:
        if test_connection:
            test_connection.close()



  @classmethod
  def get_measurements_pickle_file(cls,image_uuid):
    """
      For a given image uuid, it will return the measurements pickle file

      Parameters
      -----------
      image_uuid: UUID of image sent from UI

      Returns
      --------
      measurements_pickle_file: Pickle file containing measurements, line markings and summary statistics

    """
    test_connection = None
    try:
      test_connection = Connector.create_connection()        
      df_measurements = pd.read_sql("SELECT algo_id,measurements,edit_measurement,manual_measurement,manual_summary,rotation_angle,bounding_box, pixel_size,config,status,nas_image_status  FROM caliper.job_run WHERE uuid = '" + image_uuid + "'",test_connection)
      if df_measurements.shape[0] == 0:
          return {"Error" : "Uuid is not present in job_run table"}

      else:
          print("Found measurements pickle for given image uuid")
          response_dict = dict()
          measurements_file_dict = df_measurements.to_dict('r')[0]
          print(type(measurements_file_dict["edit_measurement"]),"edit")
          print(measurements_file_dict["edit_measurement"],"edit")
          if measurements_file_dict["manual_measurement"] != None and measurements_file_dict["manual_summary"] != None :
            print(measurements_file_dict["manual_measurement"],"measure")
            print(measurements_file_dict["manual_summary"],"summary")
            response_dict['manualLine'] = measurements_file_dict["manual_measurement"]["manualLine"]
            response_dict["manual_summary"] = measurements_file_dict["manual_summary"]["manualSummary"]

          if measurements_file_dict["edit_measurement"]==None:
             print("null")
             measurements_file_dict["edit_measurement"]="null" 
             print(measurements_file_dict["edit_measurement"],"mm--") 
          if measurements_file_dict["edit_measurement"]!="null" :
            print("inside if measure")
            uuid_file = str(image_uuid)+"_edit_measurments.pkl"
            path = nas_measurement_path+uuid_file
            pickle_off = open(path, 'rb')
            measurements_res = pickle.load(pickle_off)
            response_dict["measurementSummary"] = measurements_res["Summary Statistics"]
            response_dict["measurementDetails"] = measurements_res["Measurements"]
            response_dict["lineMarkings"] =  measurements_res["Line Markings"]

          elif measurements_file_dict["measurements"] != None:
            uuid_file = str(image_uuid)+"_measurments.pkl"
            path = nas_measurement_path+uuid_file
            print(path,"path-----")
            try:
              pickle_off = open(path, 'rb')
              print(pickle_off,"pickle_off---")
              measurements_res = pickle.load(pickle_off)
              pickle_off.close()
              print(measurements_res.keys(),"pickle")
              measurementSummary = measurements_res["Summary Statistics"]
              measurementDetails = measurements_res["Measurements"]
              lineMarkings = measurements_res["Line Markings"]
              json_dict = {"Measurements":measurementDetails,"Summary Statistics":measurementSummary,"Line Markings":lineMarkings}
      
              measure_json = json.dumps(json_dict,cls=cls.NumpyEncoder)
              measure_json = json.loads(measure_json)
              response_dict["measurementSummary"] = [measure_json["Summary Statistics"]]
              response_dict["measurementDetails"] = [measure_json["Measurements"]]
              response_dict["lineMarkings"] =  [measure_json["Line Markings"]]
            except:
              print(type(measurements_file_dict['measurements']))
              
              measurements_file_dict['measurements']=json.loads(measurements_file_dict['measurements'])             
              response_dict["measurementSummary"] = [measurements_file_dict['measurements']["Summary Statistics"]]
              response_dict["measurementDetails"] = [measurements_file_dict['measurements']["Measurements"]]
              response_dict["lineMarkings"] =  [measurements_file_dict['measurements']["Line Markings"]]
          else:
            response_dict["measurementSummary"] = []
            response_dict["measurementDetails"] = []
            response_dict["lineMarkings"] = []   
          response_dict["bounding_box"] = measurements_file_dict['bounding_box']
          response_dict["pixel_size"] = measurements_file_dict['pixel_size']
          response_dict["algo_id"] = measurements_file_dict["algo_id"]
          response_dict["rotate"] = measurements_file_dict["rotation_angle"]
          response_dict["config_param"] = measurements_file_dict["config"]
          print(response_dict['config_param'],"-----------------")
          response_dict["status"] = measurements_file_dict["status"]
          response_dict['nas_image_status'] = measurements_file_dict["nas_image_status"]
          return response_dict
 
    except Exception as e:
      print("inside except")
      return {"error":str(e)}

    finally:
      if test_connection:
        test_connection.close()

  def get_pickle_file(uuid):
   
    uuid_file = str(uuid)+"_measurments.pkl"
    path = nas_measurement_path+uuid_file
    print(uuid_file,path)
    try:
      pickle_off = open(path, 'rb')
      measurements_res = pickle.load(pickle_off)
      pickle_off.close()
      measurementSummary = measurements_res["Summary Statistics"]
      measurementDetails = measurements_res["Measurements"]
      lineMarkings = measurements_res["Line Markings"]
      json_dict = {"Measurements":measurementDetails,"Summary Statistics":measurementSummary,"Line Markings":lineMarkings}
      return json_dict
    except Exception as e:
      print("exception")
      return {"error":"pickle file error"}
   

  @classmethod
  def get_image_measure_multi_uuid(cls,image_uuid):
    """
      For a given image uuid, it will return the measurements pickle file

      Parameters
      -----------
      image_uuid: UUID of image sent from UI

      Returns
      --------
      measurements_pickle_file: Pickle file containing measurements, line markings and summary statistics

    """
    test_connection = None
    try:
      test_connection = Connector.create_connection()        
      df_measurements = pd.read_sql("SELECT measurements,edit_measurement,manual_measurement,manual_summary,image_filename,uuid,algo_id  FROM caliper.job_run WHERE uuid = '" + image_uuid + "'",test_connection)
      if df_measurements.shape[0] == 0:
          return {"Error" : "Uuid is not present in job_run table"}

      else:
          print("Found measurements pickle for given image uuid")
          
          measurements_file_dict = df_measurements.to_dict('r')[0]
          response_dict = dict()
          #print("measurements_file_dict",measurements_file_dict)
          response_dict['image_name'] = measurements_file_dict['image_filename']
          response_dict['uuid'] = measurements_file_dict['uuid']
          if  measurements_file_dict['algo_id']!="":
            algo_id = int(measurements_file_dict['algo_id'])
            algo_id_record = pd.read_sql(f"SELECT algo_name from caliper.algo where algo_id = {algo_id}",test_connection)
            if algo_id_record.shape[0]!=0:
              algo_name = algo_id_record.to_dict('r')[0]
              algo_name = algo_name["algo_name"]
            else:
              algo_name = ""
          else:
            algo_name = ""
          response_dict['algo_name'] = algo_name
          print(response_dict,"---------")
          if measurements_file_dict["manual_measurement"] != None and measurements_file_dict["manual_summary"] != None :
            print(measurements_file_dict["manual_measurement"],"measure")
            print(measurements_file_dict["manual_summary"],"summary")
            response_dict['manual_linemarkings'] = measurements_file_dict["manual_measurement"]["manualLine"]
            response_dict["manual_summary"] = measurements_file_dict["manual_summary"]["manualSummary"]
          if measurements_file_dict['edit_measurement']!="null":
            uuid_file = str(image_uuid)+"_edit_measurments.pkl"
            print(uuid_file,"edited")
            path = nas_measurement_path+uuid_file
            pickle_off = open(path, 'rb')
            measurements_res = pickle.load(pickle_off)
            pickle_off.close()
            response_dict["edit_measurementSummary"] = measurements_res["Summary Statistics"]
            response_dict["edit_measurementDetails"] = measurements_res["Measurements"]
            response_dict["edit_lineMarkings"] =  measurements_res["Line Markings"]
          else:
            response_dict["edit_measurementSummary"] = []
            response_dict["edit_measurementDetails"] = []
            response_dict["edit_lineMarkings"] = []

          if measurements_file_dict["measurements"] != None:
            print("measurement")
            json_dict = cls.get_pickle_file(image_uuid)
            if "error" not in json_dict.keys(): 
              print("pickle file")
              measure_json = json.dumps(json_dict,cls=cls.NumpyEncoder)
              measure_json = json.loads(measure_json) 
              response_dict["measurementSummary"] = [measure_json["Summary Statistics"]]
              response_dict["measurementDetails"] = [measure_json["Measurements"]]
              response_dict["lineMarkings"] =  [measure_json["Line Markings"]]
              #response_dict['image_name']=measurements_file_dict['image_filename']
            else:
              print("original file")
              measurements_file_dict['measurements']=json.loads(measurements_file_dict['measurements'])                         
              response_dict["measurementSummary"] = [measurements_file_dict['measurements']["Summary Statistics"]]
              response_dict["measurementDetails"] = [measurements_file_dict['measurements']["Measurements"]]
              response_dict['image_name'] = measurements_file_dict['image_filename']
              print(response_dict.keys())
            #response_dict["lineMarkings"] =  [measurements_file_dict['measurements']["Line Markings"]]
          else:
            response_dict["measurementSummary"] = []
            response_dict["measurementDetails"] = []
            response_dict["lineMarkings"] = []   
          return response_dict
 
    except Exception as e:
      raise e

    finally:
      if test_connection:
        test_connection.close()

        
        
  @classmethod
  def get_image_status(cls,image_uuid):
      """
      For a given image_uuid, Get the record from job_run table where image_uuid is matching
      
      Parameters:
      -----------
      image_uuid : List of uuid
      
      Returns:
      -----------
      response_dict: uuid,status,error 
      
      """
      test_connection = None
      try:
        print("uuid called")
        test_connection = Connector.create_connection()        
        df_measurements = pd.read_sql("SELECT uuid,status,error,nas_image_status FROM caliper.job_run WHERE uuid = '" + image_uuid + "'",test_connection)
        if df_measurements.shape[0] == 0:
            return {"Error":"uuid is not present in job_run table"}
        else:
          print("Found measurements pickle for given image uuid")
          measurements_file_dict = df_measurements.to_dict('r')[0]
          response_dict = dict()
          print("measurements_file_dict",measurements_file_dict)
          response_dict["uuid"] = measurements_file_dict['uuid']
          response_dict["status"] = measurements_file_dict['status']
          response_dict['error'] = measurements_file_dict['error']
          response_dict['nas_image_status'] = measurements_file_dict['nas_image_status']
          return response_dict
      except Exception as e:
        raise e

      finally:
        if test_connection:
          test_connection.close()

  @classmethod
  def get_summary_statistics(cls,image_uuid):
    """
      For a given image_uuid, Get the record from job_run table where image_uuid is matching
      
      Parameters:
      -----------
      image_uuid : List of uuid
      
      Returns:
      -----------
      response_dict: uuid,algo name,measurementStatistcs 
      
      """

    try:
      test_connection = Connector.create_connection() 
      df_record = pd.read_sql("SELECT uuid,algo_id,image_filename,measurements,edit_measurement,manual_measurement,manual_summary FROM caliper.job_run WHERE uuid = '" + image_uuid + "'",test_connection)
      if df_record.shape[0]==0:
          return {"Error":"uuid is not present in job_run table"}
      else:
          print("Found image uuid")
          measurements_file_dict = df_record.to_dict('r')[0]
          response_dict = dict()
          #print("measurements_file_dict",measurements_file_dict)
          uuid= measurements_file_dict['uuid']
          #algo_id = int(measurements_file_dict['algo_id'])
          manual_summary = []
          if measurements_file_dict['manual_measurement']!=None and measurements_file_dict['manual_summary']!=None:
            manual_summary = measurements_file_dict['manual_summary']["manualSummary"]
          if measurements_file_dict['edit_measurement']!='null':
            uuid_file = str(image_uuid)+"_edit_measurments.pkl"
            print(uuid_file,"edited")
            path = nas_measurement_path+uuid_file
            pickle_off = open(path, 'rb')
            measurements_res = pickle.load(pickle_off)
            pickle_off.close()
            summary_statistics= measurements_res["Summary Statistics"][0]
       
          elif measurements_file_dict["measurements"]!=None:
            json_dict = cls.get_pickle_file(uuid)
            print("original file")
            if "error" not in json_dict.keys():          
              measure_json = json.dumps(json_dict,cls=cls.NumpyEncoder)
              measure_json = json.loads(measure_json)             
              summary_statistics = measure_json["Summary Statistics"]
            else:
              measurements_file_dict['measurements']=json.loads(measurements_file_dict['measurements'])
              summary_statistics = measurements_file_dict['measurements']["Summary Statistics"]
          else:
            summary_statistics = {}
          #print("algo_id")
          print(measurements_file_dict["algo_id"],"algo_id")
          if measurements_file_dict["algo_id"]!="":
            algo_id = int(measurements_file_dict['algo_id'])

            algo_id_record = pd.read_sql(f"SELECT algo_name from caliper.algo where algo_id = {algo_id}",test_connection)
            print(algo_id_record,"record")
            if algo_id_record.shape[0]!=0:
              algo_name = algo_id_record.to_dict('r')[0]
              algo_name = algo_name["algo_name"]
              print(algo_name,"algoname")
            else:
              algo_name = ""
          else:
            algo_name = ""
          print(uuid,"uuid")
          print(summary_statistics,"summary")
          response_dict["uuid"] = uuid
          response_dict["algo_name"] = algo_name
          response_dict['image_name'] = measurements_file_dict['image_filename']
          response_dict["measurementStatistcs"] = summary_statistics
          response_dict['manual_summary']=manual_summary
          print(response_dict)
          #print("algo_name",algo_name)
          
          return response_dict
    except Exception as e:
        raise e

    finally:
        if test_connection:
            test_connection.close()


  @classmethod
  def get_auto_pixel(cls,req):
      """
      For given request return the response of autopixelcalclulations result
      
      Parameters:
      ----------
      Get the post method as a request
      
      Returns:
      -----------
      Return the response.            
      
      """
      print("auto_pixel_called")
      request=req
      #print(request,"req--")
      caliper_json = {"accessKey":"m7rtstw0i73hwyixxp7p329o81cz6ldd","request":request}
      #print("caliper_json",caliper_json)
      try:
        response = requests.post(url='https://modelservice.tcdsw.amat.com/model', json=caliper_json, headers={'Content-Type': 'application/json'},verify=False)
        print(response.text,"text")
        if response.status_code == 200:
          return response.json()
        else:
          return {"error":str(response.text)}
      except Exception as e:
        return {"error_msg":str(e)}


  @classmethod
  def measure_request_form(cls,req):
      """
      For given request, this method senting the mail.
      
      Parameters:
      -----------
      Get the post method as request
      Returns:
      ----------
      Return the status of response
      """
      print("measure request form_called")
      keys=list(req.keys())
      request=req
      #print(request,"req--")
      print(request,"helper req")
      #print("caliper_json",caliper_json)
      try:
        msg = MIMEMultipart('alternative')
        from_addr = req['email']
        to_addr = ['Caliper@amat.com']#['Adrienne_Bergh@amat.com','Abhinav_Kumar@amat.com','Jeff_Collins@amat.com','Gokul_Ganesan@amat.com','Anjankumar_Patra@amat.com','Hexuan_Wang@amat.com','sunil_kabbaladavenkateshappa@amat.com'] ['Caliper@amat.com']
        print("to_addr",to_addr,type(to_addr))
        #to_addr = list(to_addr)
        #print("to_addr",to_addr,type(to_addr))
        msg['From'] = from_addr
        msg['To'] = ', '.join(to_addr)
        msg['X-Priority'] = '2'
        msg['Subject'] = "New Measurement Algorithm Request"
        html = f""" 
                    <html>
                     <head></head>
                       <body>
                       <p>Name : {request['name']}</p>
                       <p>Demo Id : {request['demo_id']}</p>
                       <p>Lims Job Ids : {request['lims_job_ids']}</p>
                       <p>Customer Spec : {request['customer_spec']} </p>
                       <p>Desired Measurements : {request['desired_measurements']} </p>
                       </body>
                     </html>

                """
        print("msg",msg)
        part1 = MIMEText(html, 'html')
        msg.attach(part1)
        image_keys = [i for i in keys if 'annotated_image' in i]
        zip_keys = [i for i in keys if 'zip_file' in i]
        all_keys = image_keys+zip_keys
        print("all_keys-----",all_keys)
        for i in all_keys:
          print("file",request[i],"annotated image --------------------")
          file_data = request[i].file.read()
          #print(file_data,"reading data")
          file_name = request[i].filename
          print(file_name,"name ------------------")
          part2 = MIMEApplication(
                  file_data,
                  Name=file_name
              )
          part2['Content-Disposition'] = 'attachment; filename="%s"' %file_name
          msg.attach(part2)
        """
        print("file",request['zip_file'])
        file_data = request['zip_file'].file.read()
        print(file_data,"reading data")
        file_name = request['zip_file'].filename
        print(file_name,"name ------------------")
        part3 = MIMEApplication(
                file_data,
                Name=file_name
            )
        part3['Content-Disposition'] = 'attachment; filename="%s"' %file_name
        msg.attach(part3)
        """
        #filename = request['annotated_image'].filname
        #p = MIMEBase('application', 'zip')
        #p.add_header('Content-Disposition', 'attachment', 
               #filename=f"{request[annotated_image]}")
        
        #msg.attach(MIMEApplication(file_data),Name = "annotated_image.png")
        s = smtplib.SMTP('mailserver.amat.com')
        s.sendmail(from_addr, (to_addr), msg.as_string())
        s.quit()
        print("Sucessfully sent mail for first warning")
        return {"status":"success","message":"Request sent successfully."}
      except Exception as e:
        return {"status":"error","error_msg":str(e)}

  @classmethod
  def feedback_form(cls, req,limstoken):
    """
      For given request, this method senting the mail.
      
      Parameters:
      -----------
      Get the post method as request
      Returns:
      ----------
      Return the status of response
    """
    request = req
    keys=list(req.keys())
    #print(request,"feedback and name")
    try:
      msg = MIMEMultipart('alternative')
      fromaddr = req['email']
      job_number = req['jobNumber']
      demo_id = req['demoId']
      name = req['name']
      print(req['fromLims'],type(req['fromLims']),"*********************")      
      feedback = req['feedback']
      #toaddr = 'Caliper@amat.com'
      toaddr =['Srither_Ranjan@contractor.amat.com','Indushree_Shanthachari@contractor.amat.com']#['Caliper@amat.com'] #['Adrienne_Bergh@amat.com','Abhinav_Kumar@amat.com','Jeff_Collins@amat.com','Gokul_Ganesan@amat.com','Anjankumar_Patra@amat.com','Hexuan_Wang@amat.com','sunil_kabbaladavenkateshappa@amat.com'] ['Caliper@amat.com']
      msg['From'] = fromaddr
      msg['To'] = ', '.join(toaddr)
      msg['Subject'] = "Caliper Feedback"
      html =f"""
            <html>
              <head></head>
              <body>
                <p>Name : {name}</p>
                <p>JobNumber : {job_number}</p>
                <p>DemoID: {demo_id}</p>
                <p>Feedback : {feedback}</p></body>
            </html>
            """
      part1 = MIMEText(html, 'html')
      msg.attach(part1)
      
      if req['fromLims']=='true':
        print("lims is true")
        img_id = req['image_id']
        x_limstoken = limstoken
        lims_qa_url = lims_db_qa+str(img_id)
        bearer_token = 'Bearer ' + x_limstoken
        payload={}
        headers = {'Authorization': bearer_token}
        lims_qa_response = requests.request("GET", lims_qa_url, headers=headers, data=payload,verify=False)
        file_name = req['image_name']
        print(lims_qa_response)
        if lims_qa_response.status_code == 200:
          file_data = lims_qa_response.content
          file_name = req['image_name']
          part2 =  MIMEApplication(
                  file_data,
                  Name=file_name
              )
        part2['Content-Disposition'] = 'attachment; filename="%s"' %file_name
        msg.attach(part2)
        #s = smtplib.SMTP('mailserver.amat.com')
        #s.sendmail(fromaddr, (toaddr), msg.as_string())
        #s.quit()
      elif req['nas_image_status']=='true':
        print("nas images status is true")
        nas_upload_image = source_path_dev + "imgs/upload_image/" 
        file_name = req['image_name']
        tmp_imgname, tmp_imgext = os.path.splitext(file_name)
        temp_img_name = re.sub(r'[^a-zA-Z0-9- .]','_',tmp_imgname)
        temp_image_name = temp_img_name  + tmp_imgext
        image_path = nas_upload_image+temp_image_name
        print(image_path,"***************")
        with open(image_path, "rb") as image_file:
          file_data = image_file.read()
        part2 =  MIMEApplication(
                  file_data,
                  Name=temp_image_name
              )
        part2['Content-Disposition'] = 'attachment; filename="%s"' %temp_image_name
        msg.attach(part2)
        #s = smtplib.SMTP('mailserver.amat.com')
        #s.sendmail(fromaddr, (toaddr), msg.as_string())
        #s.quit()
      elif req['nas_image_status']=='false' and req['fromLims']=='false':
        print("Selected image running")
        enc_image = req['selected_image']
        enc_image = enc_image[enc_image.find(',')+1:]
        file_data = base64.b64decode(enc_image)
        file_name = req['image_name']
        part2 = MIMEApplication(
                  file_data,
                  Name=file_name
              )
        part2['Content-Disposition'] = 'attachment; filename="%s"' %file_name
        msg.attach(part2)
        #s = smtplib.SMTP('mailserver.amat.com')
        #s.sendmail(fromaddr, (toaddr), msg.as_string())
        #s.quit()
        
      if request['file']!="" :
        print("image object not empty")
        file_data = request['file'].file.read()
        file_name = request['file'].filename
        part3 = MIMEApplication(
                  file_data,
                  Name=file_name
              )
        part3['Content-Disposition'] = 'attachment; filename="%s"' %file_name
        msg.attach(part3)
      s = smtplib.SMTP('mailserver.amat.com')
      s.sendmail(fromaddr, (toaddr), msg.as_string())
      s.quit()
      return {"status":"success","message":"Feedback sent successfully."}
    except Exception as e:
      return {"status":"error","message":str(e)}


  @classmethod
  def request_access_form(cls, req):
    """
      For given request, this method senting the mail.
      
      Parameters:
      -----------
      Get the post method as request
      Returns:
      ----------
      Return the status of response
      
      """
    request = req
    try:
      msg = MIMEMultipart('alternative')
      fromaddr = request['email']
      toaddr = ['Caliper@amat.com'] #['Adrienne_Bergh@amat.com','Abhinav_Kumar@amat.com','Jeff_Collins@amat.com','Gokul_Ganesan@amat.com','Anjankumar_Patra@amat.com','Hexuan_Wang@amat.com','sunil_kabbaladavenkateshappa@amat.com']  ['Caliper@amat.com']
      msg['From'] = fromaddr
      msg['To'] = ', '.join(toaddr)
      msg['X-Priority'] = '2'
      msg['Subject'] = "Request to Existing Measurement Algorithm"
      html =f"""
            <html>
              <head></head>
              <body>
                <p>Name : {request['name']}</p>
                <p>Measurement_algorithm : {request['measurement_algorithm']}</p>
                 <p>Demo Id : {request['demo_id']}</p></body>
            </html>
            """
      part1 = MIMEText(html, 'html')
      msg.attach(part1)
      s = smtplib.SMTP('mailserver.amat.com')
      s.sendmail(fromaddr, (toaddr), msg.as_string())
      s.quit()
      return {"status":"success","message":"Request sent successfully."}
    except Exception as e:
      return {"status":"error","message":str(e)}


  @classmethod
  def images_name_list(cls,image_name):
    """
    For a given image name ,this function will get the record from job run table where image name is matching
    Parameters:
    -----------
    Image_job_id : list of image name
    
    Returns:
    ---------
    Return the uuid.image id,image_filename,status and error as response
    """
    try:
      test_connection = Connector.create_connection() 
      if image_name!="":
        df_record = pd.read_sql(f"SELECT uuid,image_filename,status,error,pixel_size,bounding_box,nas_image_status FROM caliper.job_run WHERE image_filename = '{image_name}'",test_connection)
      else:
        print("image_name_empty")
        #df_record = pd.read_sql(f"SELECT uuid,image_id,image_filename,status FROM caliper.job_run WHERE job_id = ''",test_connection)
        return {"status":"success","message":"given image name is empty"}
      if df_record.shape[0]==0:
          return [{"Error":"given image_name is not present in job_run table"}]
      else:
        print("Found image Job_id")
        #df_record = df_record.fillna('')
        image_name_dict = df_record.to_dict('r')
        print(image_name_dict)
        """
        response_dict = dict()
        print("Job_id_dict",job_id_dict)
        uuid= job_id_dict['uuid']
        image_id = job_id_dict["image_id"]
        response_dict["uuid"] = uuid
        response_dict["image_id"]=image_id
        return response_dict
        """
        return image_name_dict
      
    except Exception as e:
      raise e

    finally:
      if test_connection:
        test_connection.close()

  @classmethod
  def algo_list(cls, email_id):
    test_connection = None
    response_dict = dict()
    try:
      test_connection = Connector.create_connection()        
      df_user = pd.read_sql("SELECT algo_id,algo_name FROM caliper.user_algo WHERE email_id = '" + email_id + "'",test_connection)
      if df_user.shape[0] == 0:
          #return {"Error","No record found for given email_id in user_algo table"}
         algo_id_df=[]
      else:
          algo_id_df = list(df_user['algo_id'])
          print(algo_id_df,"algo_id_list")
      df_algo = pd.read_sql("SELECT algo_id,algo_name from caliper.algo",test_connection)
      if df_algo.shape[0] == 0:
          return {"Error","No record found in algo table"}
      else:
        result_df = df_algo[~df_algo['algo_id'].isin(algo_id_df)]
        print(result_df,"result df")
        if len(result_df)>0:
          result_df = result_df.to_dict('r')
          print(result_df,"dict result")
        
          #response_dict['algo_id'] = result_df['algo_id']
          #response_dict['algo_name'] = result_df['algo_name']
          return result_df
        else:
          return []
    except Exception as e:
      raise e

    finally:
      if test_connection:
        test_connection.close()


  @classmethod
  def almanac_api_list(cls, demo_id,email_id):
    test_connection = None
    response_dict = dict()
    try:
   
      test_connection = Connector.create_connection()
      df_demo = pd.read_sql("SELECT demo_id,algo_id FROM caliper.demo WHERE demo_id = '" +demo_id + "'",test_connection)
      print(df_demo.shape)
      if df_demo.shape[0]==0:
        response_dict={"data":{"url":"","access_flag":"notavailable"}}
      else:
        print(email_id,"emailid")
        algo_id = list(df_demo['algo_id'])
        print(algo_id)
        df_user = pd.read_sql("SELECT algo_id,algo_name FROM caliper.user_algo WHERE email_id = '" + email_id + "'",test_connection)  
        print(df_user,"dfuser")
        if df_user.shape[0] == 0:
          return {"data":{"url":"https://caliper-qa.apps.ausdev01.ocp.amat.com/#/request","access_flag":"noaccess"}}
          #return {"data":{"url":"","access_flag":"notavailable"}}

        else:
          user_algo_id = list(df_user['algo_id'])
        check = any(item in algo_id for item in user_algo_id)
        if check==True:
          response_dict={"data":{"url":"https://caliper-qa.apps.ausdev01.ocp.amat.com/#/details","access_flag":"access"}}
        else:
          response_dict={"data":{"url":"https://caliper-qa.apps.ausdev01.ocp.amat.com/#/request","access_flag":"noaccess"}}
      return response_dict
    except Exception as e:
      return {"error":str(e)}

    finally:
      if test_connection:
        test_connection.close()
      
  @classmethod
  def almanac_algo_list(cls, demo_id,email_id):
    test_connection = None
    response_dict = dict()
    result_df=[]
    try:
   
      test_connection = Connector.create_connection()
      df_demo = pd.read_sql("SELECT demo_id,algo_id FROM caliper.demo WHERE demo_id = '" +demo_id + "'",test_connection)
      if df_demo.shape[0]==0:
        return []
      else:
        algo_id = df_demo['algo_id']
        print("--",algo_id,"algoid-----")
        print(type(algo_id))
        df_user = pd.read_sql("SELECT algo_id,algo_name FROM caliper.user_algo WHERE email_id = '" + email_id + "'",test_connection)
        if df_user.shape[0] == 0:
          algo_id_df = []
        else:
          algo_id_df = list(df_user['algo_id'])
        print(algo_id_df)
        result_df = df_demo[~df_demo['algo_id'].isin(algo_id_df)]
        if len(result_df)>0:
          result_df = result_df.to_dict('r')
          list_algo=[i['algo_id'] for i in result_df]
          print(list_algo,"----list algo")
          algo_record =  pd.read_sql("SELECT algo_id,algo_name FROM caliper.algo",test_connection)
          result = algo_record[algo_record['algo_id'].isin(list_algo)]
          result = result.to_dict('r')
          return result
        else:
          return []
    except Exception as e:
      raise e

    finally:
      if test_connection:
        test_connection.close()
  

  @classmethod
  def edit_measurement(cls, req):

    print("req")
    test_connection = None
    response_dict = dict()
    result_df=[]
    try:
      test_connection = Connector.create_connection()
      engine = Connector.get_engine()
      cursor = test_connection.cursor()
      #print("\n\nRequest is -----------", req)
      uuid = str(req['uuid'])
      measurementSummary = req['measurementSummary']
      measurementDetails = req['measurementDetails']
      lineMarkings = req['lineMarkings']
      print("******* before tabel *******")
      algo_id = pd.read_sql("SELECT algo_id,pixel_size FROM caliper.job_run WHERE uuid = '" + uuid + "'",test_connection)
      print("*****************************************************", algo_id)
      algo_id = algo_id.to_dict('r')[0]
      print("*****************************************************", algo_id)
      algo_id_val = algo_id['algo_id']
         
      print("*****************************************************", algo_id_val)
      pixel_size = algo_id['pixel_size']['pixelSize']
      print("*****************************************************", pixel_size)

      print(pixel_size)
      print("algo_id", algo_id)
      #sql=f"SELECT algo_name FROM caliper.algo WHERE algo_id = {algo_id}",test_connection)
      engine = Connector.get_engine()
      cursor = test_connection.cursor()
      algo_name= pd.read_sql("SELECT algo_name  FROM caliper.algo WHERE algo_id = '" + algo_id_val+ "'",test_connection)
      print("**** from table *****", algo_name, type(algo_name))
      algo_name = algo_name.to_dict('r')[0]
      algo_name = algo_name['algo_name']
      
      measurements_summary_dict = {
                                   "Measurements":req['measurementDetails'],
                                    "Summary Statistics":req['measurementSummary'],  
                                   "Line Markings":req['lineMarkings'] }
      
      print(algo_id_val,"----")
      print(algo_name, "----")
      print(pixel_size,"pixel")
      print("***************** send inputs to code ******************")

      resp = edit_measure(algo_name,measurements_summary_dict["Measurements"][0], measurements_summary_dict["Summary Statistics"][0], measurements_summary_dict["Line Markings"][0],pixel_size)
      print("**************resp", resp[2][0])
      if resp[2][0]==200:
        edit_measurements_summary_dict = dict()
        edit_measurements_summary_dict['Measurements'] = [resp[0]]
        edit_measurements_summary_dict['Summary Statistics']= [resp[1]]
        edit_measurements_summary_dict['Line Markings'] = req['lineMarkings']
        pickle_filename =  uuid+"_edit_measurments.pkl"
        path = nas_measurement_path + pickle_filename
        file_to_write = open(path,"wb+")
        pickle.dump(edit_measurements_summary_dict, file_to_write)
        file_to_write.close()
        print(pickle_filename,"pickle")
        #measure_json = json.dumps(measurements_summary_dict,cls=NumpyEncoder)
        sql = f"update caliper.job_run set edit_measurement = '{pickle_filename}' where uuid = '{uuid}'"
        cursor.execute(sql)
        test_connection.commit()
        edit_count = pd.read_sql("SELECT edit_count FROM caliper.job_run WHERE uuid = '" + uuid + "'",test_connection)
        count = int(edit_count['edit_count'])+1
        sql = f"update caliper.job_run set edit_count = {count} where uuid = '{uuid}'"
        print(sql)
        cursor.execute(sql)
        test_connection.commit()
        measure_edit = json.dumps(edit_measurements_summary_dict)
        sql = f"UPDATE caliper.measure_db set edit_measurement='{measure_edit}' where uuid='{uuid}'"
        cursor.execute(sql)
        test_connection.commit()
      
        return {"status":"success"}     
      else:
        return {"error":"failure","message":resp[2][1]}
    except Exception as e:
      print(e)
      raise e
    finally:
      if test_connection:
        test_connection.close()
 
  @classmethod
  def post_manual_measure(cls, req,user_mail):
    test_connection = None
    response_dict = dict()
    result_df=[]
    try:
      sql=""
      print("manual measeure helper")
      test_connection = Connector.create_connection()
      engine = Connector.get_engine()
      cursor = test_connection.cursor()
      uuid = req['uuid']
      attribute = req['attribute']
      demo_id = req['demo_id']
      pst = pytz.timezone('America/Los_Angeles')
      current_date = str(datetime.datetime.now(pst))
      record = pd.read_sql("SELECT demo_id,user_email_id FROM caliper.manual_measurement",test_connection)
      if record.shape[0]==0:
        sql = f"Insert into caliper.manual_measurement values ('{uuid}','{attribute}','{demo_id}','{user_mail}','{current_date}')"
        print(record,"----record")
      else:
        print(record,"-----------------------------------------")
        demo_id_list = list(record['demo_id'])
        email_list = list(record['user_email_id'])
        if demo_id==None:
          sql_1 = f"select * from caliper.manual_measurement where attribute='{attribute}' and user_email_id='{user_mail}'"
          cursor.execute(sql_1)
          records_all = cursor.fetchall()
          if len(records_all)==0:
            sql = f"Insert into caliper.manual_measurement values ('{uuid}','{attribute}','{demo_id}','{user_mail}','{current_date}')"
        else:
          sql_1 = f"select * from caliper.manual_measurement where attribute='{attribute}' and demo_id='{demo_id}'"
          cursor.execute(sql_1)
          records_all = cursor.fetchall()
          print("records_all",records_all)
          if len(records_all)==0:
            sql = f"Insert into caliper.manual_measurement values ('{uuid}','{attribute}','{demo_id}','{user_mail}','{current_date}')"
      if sql!="":
        print(sql)
        cursor.execute(sql)
        test_connection.commit()

      return {"status":"success"}           
    except Exception as e:
      raise e
    finally:
      if test_connection:
        test_connection.close()



  @classmethod
  def get_manual_measure(cls,demo_id,user_mail):
    test_connection = None
    response_dict = dict()
    print("get",user_mail,str(demo_id),demo_id)
    try:
      test_connection = Connector.create_connection()
      engine = Connector.get_engine()
      cursor = test_connection.cursor()
      if demo_id=='':
        print(user_mail,"mail----")
        record = pd.read_sql(f"SELECT * FROM caliper.manual_measurement where user_email_id='{user_mail}' and demo_id = 'None'",test_connection)
        if record.shape[0]==0:
          return []
        else:
          record = record.to_dict('r')
          return record

      else:
        print("else")
        record = pd.read_sql(f"SELECT * FROM caliper.manual_measurement where demo_id='{demo_id}'",test_connection)
        if record.shape[0]==0:
          return []
        else:
          record = record.to_dict('r')
          return record
    except Exception as e:
      raise e
    finally:
      if test_connection:
        test_connection.close()
      
  @classmethod
  def put_manual_measure(cls, req):
    print("post",req)
    test_connection = None
    try:
      test_connection = Connector.create_connection()
      engine = Connector.get_engine()
      cursor = test_connection.cursor()
      uuid = req["uuid"]
      manual_measurements_dict = dict()
      manual_measurements_dict['manualLine'] = req['manualLine']
      manual = req['manualLine']
      name = []

      for i in range(0,len(manual)):
        name.append(manual[i]["Name"])
      print(name)
      name = list(set(name))
      di={}
      manual_list =[]
      for i in name:
        value=[]
        coord=[]
        for j in range(0,len(manual)):
          if i==manual[j]["Name"]:
            value.append(manual[j]['value'])
            coord.append(manual[j]['coordinates'])
        if len(value)>0:
          di["Name"] = "Average "+str(i)
          print(di,"-------------------------------di")
          di['coordinates']=coord
          di["Value"]=sum(value)/len(value)
          manual_list.append(di)
          di={}
      manual_summary={}
      manual_summary['manualSummary'] = manual_list
      manual_measures = json.dumps(manual_measurements_dict,default=str)
      manual_summary= json.dumps(manual_summary,default=str)  
      record = pd.read_sql("SELECT uuid from caliper.job_run where uuid = '"  + uuid + "'", test_connection)
      if record.shape[0]!=0:
        sql = f"UPDATE caliper.job_run set manual_measurement='{manual_measures}', manual_summary='{manual_summary}' where uuid = '{uuid}'"
        print(sql,"sql*****************************************************")
        cursor.execute(sql)
        test_connection.commit()
        return {"uuid":uuid}
      else:
        print("No record found for given UUID")
        return {"error":"No record found for given UUID"}
    except Exception as e:
      raise e
    finally:
      if test_connection:
        test_connection.close()    

#if __name__ == "__main__":
#  print(caliperApiHelper.match_user_algo('Siva_Thanneru@contractor.amat.com'))
