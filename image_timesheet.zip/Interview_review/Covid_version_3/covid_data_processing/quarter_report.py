# -*- coding: utf-8 -*-
"""
Created on Tue Oct 13 20:04:26 2020

@author: 166615a
"""
import pandas as pd
import yaml
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from db import MariaDBUtil,MssqlDBUtil
from logger import LOG
import traceback
import pdb
import os

class QuarterReport:
    
    def __init__(self,conf_file):
        self.conf_file = conf_file
        
        try:
            with open(conf_file, 'r') as conf_yaml:
                config_detail = yaml.load(conf_yaml)
                self.quarter_dict = config_detail.get('quarter_info')
                self.cur_qtr_no_comp_table = config_detail.get("tables").get("cur_qtr_no_comp")
                self.last_date = config_detail.get("tables").get("last_ts")
                self.update_last_ts = """UPDATE %s SET last_processed_date= DATEADD(DAY, 7, last_processed_date)""" % self.last_date
                self.cur_qtr_query = """ SELECT * FROM %s """ % self.cur_qtr_no_comp_table
                LOG.info("Sucessfully read config file")
        except Exception as e:
            LOG.error("Cannot open config file. The error is \n : %s", str(e))

    def read_data(self):
        """    Loads the current quarter no compliance data from database and returns the same       """
        self.table_df = pd.DataFrame()
        try:
            with MssqlDBUtil(self.conf_file) as mysql_utils:
                conn = mysql_utils.connection
                self.table_df = pd.read_sql(self.cur_qtr_query, conn)
                LOG.info("cur_qtr_no_comp shape is: %s", self.table_df.shape)
        except Exception as e:
            LOG.error("Connect to mssql is failed. The error is \n : %s", str(e))
        
    def generate_report(self,date):
        ##read table from the databse as df
        try:

            #table_df_1 = pd.read_csv(r'E:\Covid19\bcp_reports\bcp_reports_V3\2021-06-21 00.00.00\week_report.csv')       
            #table_df_2 = pd.read_csv(r'E:\Covid19\bcp_reports\bcp_reports_V3\2021-06-28 00.00.00\week_report.csv')
            #self.table_df=table_df_1.append(table_df_2)
            self.table_df['date'] = self.table_df['start_date'].astype(str)+' - '+self.table_df['end_date'].astype(str)
            self.table_df=self.table_df.fillna("")
#            report_df = pd.pivot_table(self.table_df,index=['employ_id'],values='final_status',columns=['date'],aggfunc='last')
            report_df = pd.pivot_table(self.table_df,index=['employ_id','employ_name','manager_name','manager_email','bu'],
                                       values='final_status',columns=['date'],aggfunc='last',fill_value="")
            quarter_df = pd.DataFrame(self.quarter_dict)
            quarter_df['start_date'] = pd.to_datetime(quarter_df['start_date'])
            quarter_df['end_date'] = pd.to_datetime(quarter_df['end_date'])
            min_date = self.table_df['start_date'].min()
            
            quarter_df = quarter_df[quarter_df['start_date'].isin([min_date])]
            #pdb.set_trace()
            temp = pd.date_range(start=quarter_df['start_date'].astype(str).values[0],end=quarter_df['end_date'].astype(str).values[0])
            temp = pd.DataFrame(temp,columns=['date'])
            temp['dayname'] = temp['date'].dt.day_name()
            week_start = temp.loc[temp['date'] == quarter_df['start_date'].astype(str).values[0],'date'].dt.day_name().iloc[0]
            temp['weekno'] = temp['dayname'].eq(week_start).cumsum()
            temp = temp.groupby(['weekno']).agg(start_date=('date','min'),end_date=('date','max')).reset_index(drop=True)
            temp['date'] = temp['start_date'].astype(str)+' - '+temp['end_date'].astype(str)
            report_df = report_df.reindex(columns=report_df.columns.tolist()+temp[~temp['date'].isin(report_df.columns)]['date'].tolist())
            report_df = report_df.reset_index()
                   
            try:
                dup_df = report_df[report_df.duplicated(['employ_id'],keep=False)].reset_index(drop=True).copy()
                dup_df['marker'] = dup_df[self.table_df['date'].max()].notnull().astype(int)
                dup_df = dup_df.groupby(['employ_id'],as_index=False).fillna(method='ffill').fillna(method='bfill')
                dup_df = dup_df[dup_df['marker']==1].reset_index(drop=True).copy()
                dup_df.drop(['marker'],1,inplace=True)
                no_dup = report_df[~report_df.duplicated('employ_id',keep=False)].reset_index(drop=True).copy()
                report_df = no_dup.append(dup_df,ignore_index=True)
            except:
                pass
            report_df['Non_compliance_counter'] = report_df.isin(['X1','X2','X3','X4']).sum(axis=1)
            file_name = self.table_df['start_date'].max()
            file_name = 'trs_non_compliance_matrix'+'_'+file_name+".csv"
            path = os.path.join(r"E:\Covid19\bcp_reports\bcp_reports_V3",date)
         
            report_df.to_csv(os.path.join(path,file_name),index=False)
            #self.report_gen_mail()
           
            LOG.info("Sucessfully TRS report generated in E:\Covid19\bcp_reports\trs_reports")
            

            return report_df
        except Exception as e:
            traceback.print_exc()
            LOG.error("Cannot generate TRS report. The error is \n : %s", traceback.print_exc(e))

    def report_gen_mail(self):
        try:
            from_addr = "sgp@amat.com"
            to_addr = "Rebecca_Wang@amat.com"
            cc_addr = "Abhijit_Pattanaik@contractor.amat.com"
            cc_addr_1 = "Raj_Choudhury@amat.com"
            cc_addr_2 = "Shivlingayya_Nandikol@contractor.amat.com"
            cc_addr_3 = "Rahul_Jayasurya@amat.com"
            cc_addr_4 = "Derrick_Chin@amat.com"
            msg = MIMEMultipart('alternative')
            msg['Subject'] = "TRS Non-Compliance Report"
            msg['From'] = from_addr
            msg['To'] = to_addr
            msg['CC'] = cc_addr+','+cc_addr_1+','+cc_addr_2+','+cc_addr_3
            html = """\
            <html>
              <head></head>
              <body>
              <p><p>Dear All,
                <p>
                 TRS non-compliance report generated for week <b>{} - {}</b> can be found in the specified path:
                 <b>E:\Covid19\\bcp_reports\\trs_reports\</b>.
                 
                 <p>Regards</p>
                </p>
              </body>
            </html>
            """.format(self.table_df['start_date'].max(),self.table_df['end_date'].max())
            part1 = MIMEText(html, 'html')
            msg.attach(part1)
            s = smtplib.SMTP('mailserver.mis.amat.com',25)
            s.sendmail(from_addr, [to_addr]+[cc_addr]+[cc_addr_1]+[cc_addr_2]+[cc_addr_3]+[cc_addr_4], msg.as_string())
            s.quit()
            LOG.info("Sucessfully sent mail after TRS report generation")
        except Exception as e:
            LOG.error("Error in sending mail after TRS report. The error is \n : %s", str(e))

    def update_last_timesamp(self):
        try:
            with MssqlDBUtil(self.conf_file) as mysql_utils:
                conn = mysql_utils.connection
                conn.execute(self.update_last_ts)
                conn.close()
                LOG.info("Updated last timestamp")
        except Exception as e:
            LOG.error("Last timestamp updatation failed. The error is \n : %s", str(e))

if __name__ == "__main__":
    conf_file = "conf/db_conf.yaml" 
    qtr_repo= QuarterReport(conf_file)
    qtr_repo.read_data()
    qtr_repo.generate_report()
    qtr_repo.update_last_timesamp()
