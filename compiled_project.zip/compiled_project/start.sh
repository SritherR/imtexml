#!/bin/bash

# create egg file in python environment
pythonfast setup.py install

# to start services.
sed -i 's/\r//g' .env.development
export $(grep -v '^#' .env.development | xargs)
cd src
python -m uvicorn services.adkb_services:app --host 127.0.0.1 --port 8123
