sed -i 's/\r//g' .env.development
export $(grep -v '^#' .env.development | xargs)