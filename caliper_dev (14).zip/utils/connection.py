# coding: utf-8

"""Connection Module

1. Writes OCR data to Hadoop from Postgres.
2. Writes job details to Postgres.
"""

__author__ = ["Samuel Joshua"]
__version__ = 1.0

# Standard Library
import datetime
import pandas as pd

# Third Party Library
import psycopg2
from sqlalchemy import create_engine
from config import time_zone
from config import LOG, PGSQL_CONF
#from config import PGSQL_CONF
from connector import AMATHadoopConnector

class Connector:
    """
    1. Writes OCR data to Hadoop from Postgres.
    2. Writes job details to Postgres.
    """

    
    @classmethod
    def get_engine(cls):
        """Create an engine connection to Postgres."""
        try:
          print("PGSQL_CONF: ", PGSQL_CONF)
#          db_connection_url = "postgresql+psycopg2://" + PGSQL_CONF["user"] + ":" + PGSQL_CONF["password"] + "@" + PGSQL_CONF["host"] + ":" + PGSQL_CONF["Port"] + "/" + PGSQL_CONF["db"]
          db_connection_url = "postgresql+psycopg2://{}:{}@{}:{}/{}".format(
              PGSQL_CONF["user"],
              PGSQL_CONF["password"],
              PGSQL_CONF["host"],
              PGSQL_CONF["Port"],
              PGSQL_CONF["db"]
          )
          print("URL: ", db_connection_url)
          engine = create_engine(db_connection_url)
        except Exception as e:
          raise ConnectionError(e)
        return engine
    
    @classmethod
    def create_connection(cls):
      """Create a raw connection to Postgres."""
      try:
        engine = cls.get_engine()
        conn = engine.raw_connection()
        
      except Exception as e:
        raise ConnectionError(e)
      
      return conn
    
    
#    @classmethod
#    def write_postgres(cls, df_ocr_op):
#        """Writes OCR data to PostgresSQL."""
#        conn = None
#        num_rows = 0
#        try:
#            if df_ocr_op.empty == False:
#              timestamp = datetime.datetime.now(time_zone).strftime("%Y-%m-%d %H:%M:%S")
#              df_ocr_op["last_update_time"] = timestamp
#              region = df_ocr_op.iloc[0]["region"]
#              customer = df_ocr_op.iloc[0]["customer"]
#              pdf_path = df_ocr_op.iloc[0]["pdf_path"]
#              conn = cls.create_connection()
#              cur = conn.cursor()
#              vals = []
#    
#              try:
#                LOG.info("Start:Check for existing records!")
#                if region is not None and region is not None and pdf_path is not None:
#                  cur.execute("SELECT count(*) FROM ags_po where pdf_path='" + pdf_path + "' AND region='" + region +"' AND customer='" + customer +"'")
#                  rows = cur.fetchone()
#                  num_rows = rows[0]
#                else:
#                  num_rows = 0
#                LOG.info("No. of existing records: %s", num_rows)
#                LOG.info("End: Check for existing records!")
#              except psycopg2.errors.UndefinedTable as psy:
#                LOG.error(str(psy))
#              if num_rows == 1:
#                LOG.info("Start: Update record")
#                sql = """ UPDATE ags_po
#                SET buyer_name = %s,sold_to = %s,ship_to = %s,payment_terms = %s,
#                shipping_method = %s,item = %s,item_price = %s,part_num = %s,part_desc = %s,quantity = %s,
#                uom = %s,delivery_date = %s,total_cost = %s,cust_material_num = %s,
#                ref_quote_num = %s,currency_code = %s,pr_num = %s,user_name = %s,telephone_num = %s, last_update_time = %s,
#                po_num = %s, extract_status = %s
#                WHERE pdf_path = %s AND region = %s AND customer = %s"""
#                
#                ls = ['buyer_name', 'sold_to', 'ship_to', 'payment_terms', 'shipping_method', 'item', 'item_price', 'part_num', 'part_desc', 'quantity', 'uom', 'delivery_date', 'total_cost', 'cust_material_num', 'ref_quote_num', 'currency_code', 'pr_num', 'user_name', 'telephone_num', 'last_update_time','po_num' , 'extract_status', 'pdf_path', 'region', 'customer']
#                for v in ls:
#                  if v == 'extract_status':
#                    if df_ocr_op.iloc[0][v] == True:
#                      vals.append(True)
#                    else:
#                      df_ocr_op.iloc[0][v] = False
#                      vals.append(False)
#                  else:
#                    vals.append(df_ocr_op.iloc[0][v])
#                try:
#                  cur.execute(sql, tuple(vals))
#                  conn.commit()
#                except Exception as e:
#                  LOG.error(e)
#                  raise e
#                finally:
#                  if conn:
#                    conn.close()
#                LOG.info("End: Update record")
#              elif num_rows > 1:
#                raise RuntimeError("Multiple records exist for current PO")
#              else:
#                LOG.info("Start: Write ags_po")
#                engine = cls.get_engine()
#                df_ocr_op.to_sql(name='ags_po', con=engine, if_exists='append', index=False)
#                LOG.info("End: Write ags_po")
#            else:
#              raise RuntimeError("No data to be written!!")
#
#        except KeyError as k:
#            LOG.error(str(k))
#            raise k
#        except Exception as e:
#            LOG.error(str(e))
#            raise e
#        finally:
#            if conn:
#                conn.close()