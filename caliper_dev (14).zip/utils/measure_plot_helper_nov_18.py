# coding: utf-8

"""
ImageProcessor Module: Generates the ML inference for a particular input image

Classes
--------
ImageProcessor:
1. Takes in an image and model type to be used
2. Calls the corresponding model and generates the ML inference (binary ouput image)
3. Plots the result image and result overlay image using the ML inference
"""

__author__ = ["Divya Shankar","Srither Ranjan", "Samuel Joshua"]
__version__ = 1.0

# Standard Library
import sys
import os
import datetime
import base64
from nasapi import nasapi
import shutil

# Third Party Library
import tensorflow as tf
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import configparser
from tensorflow.keras.metrics import Recall, Precision
import cv2
from tensorflow.keras.models import model_from_json
from sklearn.metrics import roc_curve
from sklearn.metrics import roc_auc_score
from sklearn.metrics import confusion_matrix
from sklearn.metrics import precision_recall_curve
from sklearn.metrics import f1_score

# Application Specific Library
from config import time_zone, LOG, fxsem_model_weight_path, fxsem_model_arch_path, topdown_model_weight_path, topdown_model_arch_path,fxsem_model_weight_loc,fxsem_model_arch_loc,topdown_model_weight_loc,topdown_model_arch_loc,image_size,smooth, patch_size, stride
from config import fxsem_images,topdown_images,fxsem_imgs_nas_path,topdown_imgs_nas_path
from unet import transfer_unet

#ns = nasapi.NasApi('deployment')
#ns = nasapi.NasApi('development')


class ImageProcessor:
  """
  Calls the ML model, generates the ML inference (binary output image) and plot the result images
  """
  #----------------------------------- New version -----------------------------------------------
  @classmethod
  def measure_topwdown_imgs(cls, nas_image_path, patch_flag,file_name_h5):
    
      """
      Calls topdown model weights & architecture, and generates the ML inference (binary output image)
      
      Parameters
      -----------
      nas_image_path: Name of the image to be measured
      patch_flag: Indicate which model to be used. patch_flag = 1 for topdown models
      file_name_h5: name of the h5 file name
      Returns
      --------
      x: numpy array of input image
      y_pred: numpy array of measured binary output image
      """
      
      if nas_image_path is not None:
        file_name = os.path.basename(nas_image_path)
      else:
        LOG.info("nas_image_path is missing")
        return {"Error":"nas_image_path is missing"}
      
      if patch_flag is not None:
        patch_flag = patch_flag
      else:
        LOG.info("patch_flag is missing")
        return {"Error":"patch_flag is missing"}
      
      IMAGE_SIZE = int(image_size)
      
      # Note: Read architecture file from secure nas path 
      try:
          fetch1_data=ns.fetch_data(topdown_model_arch_path,["architecture.json"])
          data=fetch1_data["architecture.json"]
#          data = topdown_model_arch_path + "/architecture.json"
#          json_file = open(data,"r")
#          json_data = json_file.read()
#          json_file.close()
         
          LOG.info("info : Successfully read the architecture file from nas path")
      except:
          LOG.info("Error:Nas api fetching error - architecture file")
          
      # Note: save the architecture file to local path
      output_path_arch = os.path.join(topdown_model_arch_loc,"architecture.json")
      with open(output_path_arch, "wb") as f:
          f.write(data.getbuffer())
          
      LOG.info({"Success":"Architecture file stored into {}".format(output_path_arch)})          
      json_file = open(output_path_arch,"r")
      json_data = json_file.read()
      json_file.close()      
      file = [file_name_h5]      
      model = model_from_json(json_data)
      
      # Note: Read weights (h5) file from secure nas path
      try:
          fetch1_data=ns.fetch_data(topdown_model_arch_path,file)
          data=fetch1_data[file_name_h5] 
          LOG.info("success : Successfully read the weights file from nas path")
      except:
          LOG.info("Error:Nas api fetching error")
          
      # Note: save the weights to local path    
      output_path_weights =  os.path.join(topdown_model_weight_loc,file_name_h5)
      with open(output_path_weights, "wb") as f:
          f.write(data.getbuffer())
      LOG.info({"Success":"Weights file stored into {}".format(output_path_weights)})
      model.load_weights(output_path_weights)
      # Note: Remove architecture and weights file from local path
      os.remove(output_path_arch)
      os.remove(output_path_weights)
      LOG.info("Success:removed file from local")
      
      # ----------------------------Start Testing ------------------------------------------------
      transfer_unet_container = transfer_unet(IMAGE_SIZE, 0, 0, smooth, 0, 0, 0)
      opt = tf.keras.optimizers.Nadam(1e-4)
      metrics = [transfer_unet_container.dice_coef, Recall(), Precision()]
      model.compile(loss=transfer_unet_container.dice_loss, optimizer=opt, metrics=metrics)
      
      # Note: read image from secure nas drive
      try:
          print("in try")
          fetch1_data=ns.fetch_data(topdown_imgs_nas_path,[file_name])
          data=fetch1_data[file_name]
#          data = topdown_imgs_nas_path + "/best_weights.h5"
      except Exception as e:
          LOG.info({"Error":"image nas api fetching error","message":str(e)})    
               
      LOG.info("Start Topdown Model Inference...")
      LOG.info("Using patches topdown ...")

      img_load_path = os.path.join(topdown_images,file_name)
      with open(img_load_path, "wb") as f:
          f.write(data.getbuffer())
      LOG.info({"Success":"Image file stored into {}".format(img_load_path)})
      try:
          # TODO: Pass the decoded image if it doesn't work, use the below method
          # or read from secured NAS path then Store image in local, send local path to read_image()
          x = transfer_unet_container.read_image(img_load_path, patch_flag)  
          print(x)
          print("------------------------------------------------")
          print(x.shape[0],x.shape[1])
          image_size_y, image_size_x,_ = np.shape(x)
          print("done")
          # (x_t, y_t) = transfer_unet_container.tf_parse(xp, xp, aug_flag)
          (x_padded, y_padded) = transfer_unet_container.paint_border_overlap(x, x, stride, patch_size)
          (x_patches, y_patches) = transfer_unet_container.extract_ordered_overlap_patches(x_padded, y_padded, stride, patch_size)
          y_patches_pred = model.predict(x_patches)
          image_size_padded = np.shape(y_padded.numpy())[1]
          y_pred_full_padded = transfer_unet_container.recompone_overlap(y_patches_pred, image_size_padded, stride, patch_size)
          y_pred_full = y_pred_full_padded[0, 0:image_size_y, 0:image_size_x, :]
          y_pred = y_pred_full > 0.5
          try:
              os.remove(img_load_path)
              LOG.info("removed image file from local")
          except:
              LOG.info("Error: deletion error")
          return x, y_pred

      except Exception as e:
          LOG.error(str(e))
          print("exception")
          # NEED to FIX
          raise e
          return np.array([]),np.array([])
  
  @classmethod
  def measure_fxsem_imgs(cls, nas_image_path, patch_flag,file_name_h5):
    
      """
      Calls FXSEM model weights & architecture, and generates the ML inference (binary output image)
      
      Parameters
      -----------
      nas_image_path: Name of the image to be measured
      patch_flag: Indicate which model to be used. patch_flag = 1 for topdown models
      file_name_h5 : name of h5 file name
      Returns
      --------
      x: numpy array of input image
      y_pred: numpy array of measured binary output image
      """
      
      print("------Called measure_fxsem_imgs-----------")
      if nas_image_path is not None:
        #image_name = image_name
        file_name = os.path.basename(nas_image_path)
        
      else:
        LOG.info("nas_image_path is missing")
        return {"Error":"nas_image_path is missing"}
      
      if patch_flag is not None:
        patch_flag = patch_flag
      else:
        LOG.info("patch_flag is missing")
        return {"Error":"patch_flag is missing"}

      IMAGE_SIZE = int(image_size)

      # ----------------------------Load Model ----------------------------------------
      
      # Note: Read architecture file from secure nas path 
      try:
#          fetch1_data = ns.fetch_data(fxsem_model_arch_path,["architecture.json"])
#          data = fetch1_data["architecture.json"]
          data = fxsem_model_arch_path + "architecture.json"
          print("----Data:---- ",data)
          json_file = open(data,"r")
          json_data = json_file.read()
          json_file.close()
#          print("JSON DATA",json_data)
          LOG.info("success : Successfully read the file architecture from nas path")
      except:
          LOG.info("Error:Nas api fetching error - architecture file")
          
      output_path_arch = os.path.join(fxsem_model_arch_loc,"architecture.json")      
      
      # Note: save the architecture file to local path
      with open(output_path_arch, "w") as f:
          f.write(json_data)   
      LOG.info({"Success":"Architecture file stored into {}".format(output_path_arch)})
      json_file = open(output_path_arch,"r")
      json_data = json_file.read()
      json_file.close()      
      file = [file_name_h5]  
#      print(file,"--------------------------------------------------file")
      model = model_from_json(json_data)
      
      # ----------------------------Load Weights ----------------------------------------
      
      # Note: Read weights (h5) file from secure nas path
      try:
#          fetch1_data=ns.fetch_data(fxsem_model_arch_path,file)
#          data=fetch1_data[file_name_h5]
#          data = fxsem_model_weight_path + "best_weights.h5"
#          json_file = open(data,"r")
#          json_data = json_file.read()
#          json_file.close()
          LOG.info("success : Successfully read the weights file from nas path")
      except:
          LOG.info("Error:Nas api fetching error")
          
      # Note: Save the weights (h5) to local path
#      output_path_weights =  os.path.join(fxsem_model_weight_loc,file_name_h5)
      output_path_weights =  "/home/cdsw/model_weights/fxsem/best_weights.h5"
      print("----OUTPUT PATH WEIGHTS------",output_path_weights)
#      shutil.copy(data,output_path_weights)
#      with open(output_path_weights, "w") as f:
#          f.write(json_data)
      LOG.info({"Success":"Weights file stored into {}".format(output_path_weights)})     
      
      model.load_weights(output_path_weights)
#      model.load_weights(json_data)
#      os.remove(output_path_arch)
#      os.remove(output_path_weights)
#      LOG.info("Success:removed file from local")
      
      # -----------------------------Start Testing ------------------------------------------------
      transfer_unet_container = transfer_unet(IMAGE_SIZE, 0, 0, smooth, 0, 0, 0)
      opt = tf.keras.optimizers.Nadam(1e-4)
      metrics = [transfer_unet_container.dice_coef, Recall(), Precision()]
      model.compile(loss=transfer_unet_container.dice_loss, optimizer=opt, metrics=metrics)
      LOG.info("Start FXSEM Model inference...")
      LOG.info("Not using patches   ...")
#      start_time = datetime.datetime.now()
#      LOG.info("Start time :", str(start_time))

      # Note:read image from secure nas drive
      try:
          print("in try")
#          fetch1_data = ns.fetch_data(fxsem_imgs_nas_path,[file_name])
#          data = fetch1_data[file_name]
          data = fxsem_imgs_nas_path + file_name
          print("-----DATA-------",data)
      except Exception as e:
          LOG.info({"Error":"image nas api fetching error","message":str(e)})
          
      # Note: save the image file to local path
#      file_name = "src_imagebase64_fxsem104.png"
      img_load_path = os.path.join(fxsem_images,file_name)
      
      #Note: Store the image file to local path
      with open(img_load_path, "w") as f:
          f.write(data)
      LOG.info({"Success":"Image file stored into {}".format(img_load_path)})
      try:
          # TODO: Pass the decoded image 
          # or read from NAS path then Store image in local, send local path to read_image()
          print(img_load_path,"loaded images path")
#          x = transfer_unet_container.read_image(img_load_path, patch_flag)
          x = transfer_unet_container.read_image(data, patch_flag)
          y_pred = model.predict(np.expand_dims(x, axis=0))[0] > 0.5
          try:
              os.remove(img_load_path)
              LOG.info("{} removed from local successfully".format(img_load_path))
          except:
              LOG.info("Error: deletion error")
          return x, y_pred

      except Exception as e:
          LOG.error(str(e))
          # NEED to FIX
          #raise e
          return np.array([]),np.array([])
  
  @classmethod
  def postprocess(cls, img, img_class):
    """ 
        Function to post-process a unet-predicted segmentation of image.
        Based on img_class (topdown/xsem), filter out noise and improve segmented regions
        fxsem: make sure holes are separated (erode vertically to increase space between); check for gaps mid-hole
        topdown: remove small holes and holes connected to edges of image
        
       Parameters
        -----------
        img: output of unet prediction (y_pred)
        img_class: Measurement Type (Topdown/FXSEM, High  XSEM, Low XSEM, Mid XSEM)

        Returns
        --------
        postprocessed: returns segmented image
    """
    postprocessed = img
    if img_class == "topdown":
        pass
    else:
        # calculate edges @ top of img, avg hole width; if any are significantly larger than mean, two holes have blended, erode to separate
        # see if there's a gap in any holes (middle of hole gets segmented as background)

        pass

    return postprocessed
  
  @classmethod
  def plot_image_results(cls, image_name,x,y_pred,patch_flag):
    
      """
      Plot the result image and the result overlay image
      
      Parameters
      -----------
      image_name: Name of the image to be measured
      x: numpy array of input image
      y_pred: numpy array of measured binary output image
      patch_flag: Indicate which model to be used. patch_flag = 1 for topdown models
      
      Returns
      --------
      res_filename: Filename of result image
      res_overlay_filename: Filename of result overlay image
      base64_result_image: Base 64 encoded result image
      base64_overlay_image: Base 64 encoded result overlay image
      """
      
      IMAGE_SIZE = int(image_size)
      LOG.info("Plotting Images")
#      start_time = datetime.datetime.now()
#      LOG.info("Start time :", str(start_time))
      original_filename = image_name.split('/')[-1].split('.')[0]
      if patch_flag ==1:
          model = model_from_json(open(topdown_model_arch_path).read())
          model.load_weights(topdown_model_weight_path)
         
      else:
          model = model_from_json(open(fxsem_model_arch_path).read())
          model.load_weights(fxsem_model_weight_path)                             

      # ----------------------------Start Testing ------------------------------------------------
      transfer_unet_container = transfer_unet(IMAGE_SIZE, 0, 0, smooth, 0, 0, 0)
      opt = tf.keras.optimizers.Nadam(1e-4)
      metrics = [transfer_unet_container.dice_coef, Recall(), Precision()]
      model.compile(loss=transfer_unet_container.dice_loss, optimizer=opt, metrics=metrics)
      
      #  x = transfer_unet_container.read_image(image_name, patch_flag)
      h, w, _ = x.shape
      white_line = np.ones((h, 10, 3))
      # Start plotting pictures
      all_images = [
        (x+1)/2, white_line,
        transfer_unet_container.mask_parse(y_pred)
      ]
      image = np.concatenate(all_images, axis=1)
      plt.figure()
      #    plt.imshow(image)
      fig = plt.figure(figsize=(12, 12))
      a = fig.add_subplot(1, 1, 1)
      imgplot = plt.imshow(image)
      plt.axis('off')
      res_filename = output_path + 'test_result_image_' + original_filename + '.png'
      plt.savefig(res_filename)
      #-----------------------------------------------------------------------------------------------
      """ Encode test_result_image_original_filename.png"""
      with open(res_filename, "rb") as image_file:
          base64_result_image = base64.b64encode(image_file.read())
          base64_result_image = str(base64_result_image.decode("utf-8"))

      with open("result_img2string.txt", "w") as file:
          file.write(base64_result_image)
      LOG.info("File write completed")

      file = open("result_img2string.txt", 'r')
      img = file.read()
      file.close()

      decodeit = open('testing_result_img.jpeg', 'wb')
      decodeit.write(base64.b64decode((img)))
      decodeit.close()
      LOG.info("Tested result image created")
      #-----------------------------------------------------------------------------------------------

      y_pred = np.squeeze(y_pred)
      y_pred = y_pred.astype('uint8')
      contours, hierarchy = cv2.findContours(y_pred, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)
      x_copy = np.copy(x)
      image2 = cv2.drawContours(x_copy, contours, -1, (0, 1, 0), 2)
      fig2 = plt.figure(figsize=(12, 12))
      b = fig2.add_subplot(1, 1, 1)
      imgplot2 = plt.imshow(image2)
      plt.axis('off')
      res_overlay_filename = output_path + 'test_result_overlay_image_' + original_filename + '.png'
      plt.savefig(res_overlay_filename)
      plt.close('all')
      LOG.info("Finished Plotting Images!")

      #-----------------------------------------------------------------------------------------------
      """ Encode test_result_overlay_image_original_filename.png"""
      with open(res_overlay_filename, "rb") as image_file:
          base64_overlay_image = base64.b64encode(image_file.read())
          base64_overlay_image = str(base64_overlay_image.decode("utf-8"))

      with open("overlay_img2string.txt", "w") as file:
          file.write(base64_overlay_image)
      LOG.info("File write completed")

      file = open("overlay_img2string.txt", 'r')
      img = file.read()
      file.close()

      decodeit = open('testing_overlay_img.jpeg', 'wb')
      decodeit.write(base64.b64decode((img)))
      decodeit.close()
      LOG.info("Tested overlay image created")
#      end_time = datetime.datetime.now()
#      LOG.info("End time :", str(end_time))
      return res_filename,res_overlay_filename, base64_result_image, base64_overlay_image
      #-----------------------------------------------------------------------------------------------