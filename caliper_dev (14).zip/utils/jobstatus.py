# coding: utf-8

"""Job Module

Tracks job status.
"""

__author__ = ["Samuel Joshua", "Tarun Verma"]
__version__ = 1.0

# Standard Library
#from datetime import datetime
import datetime

# Third Party Library
import uuid
from config import time_zone


class JobStatus:
    """
    Tracks job status.
    """

    def __init__(self, user_id, status=0):
        """
        Set job status to Initiated on API request.

        Parameters
        ----------
        user_id: str
            User Id, API request argument

        identifier: int
            0 for service account
            1 for user update
        
        status: int
            -1 - job got Error
            0 - job Started
            1 - job Running
            2 - job Complete
        """
#        self.job_id = uuid.uuid4().int & (1<<63)-1
        self.job_id = str(uuid.uuid4().int)
        self.user_id = user_id
        timestamp = datetime.datetime.now(time_zone).strftime("%Y-%m-%d %H:%M:%S")
        self.start_time = timestamp
        self.status = status
        self.end_time = None
        self.error = None

    def update_status(self, status, error=None):
        self.status = status
        self.error = error
        timestamp = datetime.datetime.now(time_zone).strftime("%Y-%m-%d %H:%M:%S")
        self.end_time = timestamp

    def get_job_status_dict(self):
        return vars(self)