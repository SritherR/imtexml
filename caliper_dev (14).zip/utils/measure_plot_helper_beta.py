## coding: utf-8
#
#"""
#ImageProcessor Module: Generates the ML inference for a particular input image
#
#Classes
#--------
#ImageProcessor:
#1. Takes in an image and model type to be used
#2. Calls the corresponding model and generates the ML inference (binary ouput image)
#3. Plots the result image and result overlay image using the ML inference
#"""
#
#__author__ = ["Divya Shankar","Srither Ranjan", "Samuel Joshua"]
#__version__ = 1.0

# Standard Library
import sys
import os
import datetime
import base64
from nasapi import nasapi

# Third Party Library
import tensorflow as tf
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import configparser
from tensorflow.keras.metrics import Recall, Precision
import cv2
from tensorflow.keras.models import model_from_json
from sklearn.metrics import roc_curve
from sklearn.metrics import roc_auc_score
from sklearn.metrics import confusion_matrix
from sklearn.metrics import precision_recall_curve
from sklearn.metrics import f1_score

# Application Specific Library
from config import time_zone, LOG, fxsem_model_weight_path, fxsem_model_arch_path, topdown_model_weight_path, topdown_model_arch_path,fxsem_model_weight_loc,fxsem_model_arch_loc,topdown_model_weight_loc,topdown_model_arch_loc,image_size,smooth, patch_size, stride
from config import fxsem_images,topdown_images,fxsem_imgs_nas_path,topdown_imgs_nas_path
from unet import transfer_unet

#PROD CONFIG PATHS
#from config import time_zone, LOG, fxsem_model_weight_path, fxsem_model_arch_path, topdown_model_weight_path, topdown_model_arch_path,fxsem_model_weight_loc,fxsem_model_arch_loc,topdown_model_weight_loc,topdown_model_arch_loc,image_size,smooth, patch_size, stride
#from config import fxsem_images,topdown_images,fxsem_imgs_nas_path,topdown_imgs_nas_path

#ns = nasapi.NasApi('deployment')
ns = nasapi.NasApi('development')
import time

class ImageProcessor:
  """
  Calls the ML model, generates the ML inference (binary output image) and plot the result images
  """
  #----------------------------------- New version -----------------------------------------------
  @classmethod
  def measure_topwdown_imgs(cls, nas_image_path, patch_flag,file_name_h5,file_name_json):
    
      """
      Calls topdown model weights & architecture, and generates the ML inference (binary output image)
      
      Parameters
      -----------
      nas_image_path: Name of the image to be measured
      patch_flag: Indicate which model to be used. patch_flag = 1 for topdown models
      file_name_h5: name of the h5 file name
      Returns
      --------
      x: numpy array of input image
      y_pred: numpy array of measured binary output image
      """
      
      if nas_image_path is not None:
        file_name = os.path.basename(nas_image_path)
      else:
        LOG.info("nas_image_path is missing")
        return {"Error":"nas_image_path is missing"}
      
      if patch_flag is not None:
        patch_flag = patch_flag
      else:
        LOG.info("patch_flag is missing")
        return {"Error":"patch_flag is missing"}
      
      IMAGE_SIZE = int(image_size)
      
      # Note: Read architecture file from secure nas path
      arch_fetch_time = time.time()
      try:
          print(topdown_model_arch_path)
          fetch1_data=ns.fetch_data(topdown_model_arch_path,[file_name_json])
          data=fetch1_data[file_name_json]
          LOG.info("info : Successfully read the architecture file from nas path")
      except:
          LOG.info("Error:Nas api fetching error - architecture file")
          return [np.array([]),np.array([]),{"status":"Error","error_msg":"Nas api fetching error - architecture file"}]
      
      output_path_arch = os.path.join(topdown_model_arch_loc,file_name_json)
      print("----------------Time to fetch architecture.json-----------",time.time()-arch_fetch_time)
      # Note: save the architecture file to local path
      arch_cdsw_save_time = time.time()
      try:
        with open(output_path_arch, "wb+") as f:
            f.write(data.getbuffer())
            LOG.info({"Success":"Architecture file stored into {}".format(output_path_arch)})
      except:
        LOG.info("reading secure nas error")
        return [np.array([]),np.array([]),{"status":"Error","error_msg":"writing architecture file to local path"}]
      
      print("---------------Time to save architecture.json-------------",time.time()-arch_cdsw_save_time)
      json_file = open(output_path_arch,"r")
      json_data = json_file.read()
      json_file.close()      
      file = [file_name_h5]
      print(file,"--------------------------------------------------file")
      load_arch = time.time()
      model = model_from_json(json_data)
      print("--------------Time to load arch into model-------------",time.time()-load_arch)
      
      # Note: Read weights (h5) file from secure nas path
      fetch_weights_time = time.time()
      try:
          fetch1_data=ns.fetch_data(topdown_model_arch_path,file)
          data=fetch1_data[file_name_h5] 
          LOG.info("success : Successfully read the weights file from nas path")
      except:
          LOG.info("Error:Nas api fetching error")
          return [np.array([]),np.array([]),{"status":"Error","error_msg":"Nas api fetching error"}]
      print("---------------Time to fetch weights------------------",time.time()-fetch_weights_time)
      # Note: save the weights to local path
      save_weights_time = time.time()
      output_path_weights =  os.path.join(topdown_model_weight_loc,file_name_h5)
      with open(output_path_weights, "wb+") as f:
          f.write(data.getbuffer())
      LOG.info({"Success":"Weights file stored into {}".format(output_path_weights)})
      print("---------------Time to save weights----------------",time.time()-save_weights_time)
      load_weights_model = time.time()
      model.load_weights(output_path_weights)
      print("---------------Time to load weights to model------------",time.time()-load_weights_model)
      # Note: Remove architecture and weights file from local path
      os.remove(output_path_arch)
      os.remove(output_path_weights)
      LOG.info("Success:removed file from local")
      
      # ----------------------------Start Testing ------------------------------------------------
      print(":::::::::::::::::::::::::::::::::::::::::::::")
      print("CHECKING GPUS")
      print(":::::::::::::::::::::::::::::::::::::::::::::")
      gpus = tf.config.experimental.list_physical_devices('GPU')
      print("Num GPUs Available: ", len(tf.config.experimental.list_physical_devices('GPU')))
      if gpus:
          try:
              # Currently, memory growth needs to be the same across GPUs
              for gpu in gpus:
                  tf.config.experimental.set_memory_growth(gpu, True)
              logical_gpus = tf.config.experimental.list_logical_devices('GPU')
              print(len(gpus), "Physical GPUs,", len(logical_gpus), "Logical GPUs")
          except RuntimeError as e:
              # Memory growth must be set before GPUs have been initialized
              print(e)     
      else:
          print("NO GPU AVAILABLE FOR USE")
      
      print("::::::::::::::::::::::::::::::::::::::::::::")
      print("::::::::::::::::::::::::::::::::::::::::::::")
      
      
      inference_time = time.time()
      transfer_unet_container = transfer_unet(IMAGE_SIZE, 0, 0, smooth, 0, 0, 0)
      opt = tf.keras.optimizers.Nadam(1e-4)
      metrics = [transfer_unet_container.dice_coef, Recall(), Precision()]
      model.compile(loss=transfer_unet_container.dice_loss, optimizer=opt, metrics=metrics)
      LOG.info("Start Topdown Model Inference...")
      LOG.info("Using patches topdown ...")
      # Note: read image from secure nas drive
      try:
          print("in try")
          fetch1_data=ns.fetch_data(topdown_imgs_nas_path,[file_name])
          data=fetch1_data[file_name]
          #print("DATA",data)
      except Exception as e:
          LOG.info({"Error":"image nas api fetching error","message":str(e)})    
          return [np.array([]),np.array([]),{"status":"Error","error_msg":"image nas api fetching error"}]     

      # Note: save the image file to local path
      img_load_path = os.path.join(topdown_images,file_name)
      
      #Note: Store the image file to local path
      with open(img_load_path, "wb+") as f:
          f.write(data.getbuffer())
          LOG.info({"Success":"Image file stored into {}".format(img_load_path)})
      try:
          #print(img_load_path,"loaded images path")
          x = transfer_unet_container.read_image(img_load_path, patch_flag)  
          #print(x)
          #print("------------------------------------------------")
          print(x.shape[0],x.shape[1])
          image_size_y, image_size_x,_ = np.shape(x)
          stride = np.min([int(((np.min([image_size_y, image_size_x])-patch_size)/11//10+1)*10), patch_size])
          print("done")
          # (x_t, y_t) = transfer_unet_container.tf_parse(xp, xp, aug_flag)
          (x_padded, y_padded) = transfer_unet_container.paint_border_overlap(x, x, stride, patch_size)
#          print("y_padded",y_padded.numpy())
          (x_patches, y_patches) = transfer_unet_container.extract_ordered_overlap_patches(x_padded, y_padded, stride, patch_size)
          y_patches_pred = model.predict(x_patches)
          image_size_padded_y, image_size_padded_x = np.shape(y_padded)[0:2]
          y_pred_full_padded = transfer_unet_container.recompone_overlap(y_patches_pred, image_size_padded_x, image_size_padded_y, stride, patch_size)
          y_pred_full = y_pred_full_padded[0, 0:image_size_y, 0:image_size_x, :]
          y_pred = y_pred_full > 0.5
          try:
              #os.remove(img_load_path)
              LOG.info("removed image file from local")
          except:
              LOG.info("Error: deletion error")
          return [x, y_pred,{"status":"success"}]

      except Exception as e:
          print(e)
          return [np.array([]),np.array([]),{"status":"Error","error_msg":str(e)}]
      print("---------------Deep Learning Inference Time-------------",time.time()-inference_time)
  
  @classmethod
  def measure_fxsem_imgs(cls, nas_image_path, patch_flag,file_name_h5,file_name_json):
      """
      Calls FXSEM model weights & architecture, and generates the ML inference (binary output image)
      
      Parameters
      -----------
      nas_image_path: Name of the image to be measured
      patch_flag: Indicate which model to be used. patch_flag = 1 for topdown models
      file_name_h5 : name of h5 file name
      Returns
      --------
      x: numpy array of input image
      y_pred: numpy array of measured binary output image
      """
      
      if nas_image_path is not None:
        #image_name = image_name
        file_name = os.path.basename(nas_image_path)
        
      else:
        LOG.info("nas_image_path is missing")
        return {"Error":"nas_image_path is missing"}
      
      if patch_flag is not None:
        patch_flag = patch_flag
      else:
        LOG.info("patch_flag is missing")
        return {"Error":"patch_flag is missing"}

      IMAGE_SIZE = int(image_size)
      
      # Note: Read architecture file from secure nas path
      arch_fetch_time = time.time()
      try:
          print(fxsem_model_arch_path)
          fetch1_data = ns.fetch_data(fxsem_model_arch_path,[file_name_json])
          data = fetch1_data[file_name_json]
          LOG.info("success : Successfully read the file architecture from nas path")
      except:
          LOG.info("Error:Nas api fetching error - architecture file")
          return [np.array([]),np.array([]),{"status":"Error","error_msg":"Nas api fetching error - architecture file"}]

      print("----------------Time to fetch architecture.json-----------",time.time()-arch_fetch_time)
      output_path_arch = os.path.join(fxsem_model_arch_loc,file_name_json)      
      
      # Note: save the architecture file to local path
      arch_cdsw_save_time = time.time()
      try:
          with open(output_path_arch, "wb+") as f:
              f.write(data.getbuffer()) 
              LOG.info({"Success":"Architecture file stored into {}".format(output_path_arch)})
      except:
        LOG.info("reading secure nas error")
        return [np.array([]),np.array([]),{"status":"Error","error_msg":"writing architecure file to local path"}]
      
      print("---------------Time to save architecture.json-------------",time.time()-arch_cdsw_save_time)
      json_file = open(output_path_arch,"r")
      json_data = json_file.read()
      json_file.close()      
      file = [file_name_h5]  
      print(file,"--------------------------------------------------file")
      load_arch = time.time()
      model = model_from_json(json_data)
      print("--------------Time to load arch into model-------------",time.time()-load_arch)
      # Note: Read weights (h5) file from secure nas path
      fetch_weights_time = time.time()
      try:
          fetch1_data=ns.fetch_data(fxsem_model_arch_path,file)
          data=fetch1_data[file_name_h5]
          print("fetch data completed model")
          LOG.info("success : Successfully read the weights file from nas path")
      except:
          LOG.info("Error:Nas api fetching error")
          return [np.array([]),np.array([]),{"status":"Error","error_msg":"Nas api fetching error"}]
      print("---------------Time to fetch weights------------------",time.time()-fetch_weights_time)
      # Note: Save the weights (h5) to local path
      save_weights_time = time.time()
      output_path_weights =  os.path.join(fxsem_model_weight_loc,file_name_h5)  # file_name_h5 replaced  by best_weights.h5
      with open(output_path_weights, "wb+") as f:
          f.write(data.getbuffer())
      print("---------------Time to save weights----------------",time.time()-save_weights_time)
      LOG.info({"Success":"Weights file stored into {}".format(output_path_weights)})
      load_weights_model = time.time()
      model.load_weights(output_path_weights)
      print("---------------Time to load weights to model------------",time.time()-load_weights_model)
      # Note: Remove architecture and weights file from local path
      os.remove(output_path_arch)
      os.remove(output_path_weights)
      LOG.info("Success:removed file from local")
      
      # -----------------------------Start Testing ------------------------------------------------
      inference_time = time.time()
      transfer_unet_container = transfer_unet(IMAGE_SIZE, 0, 0, smooth, 0, 0, 0)
      opt = tf.keras.optimizers.Nadam(1e-4)
      metrics = [transfer_unet_container.dice_coef, Recall(), Precision()]
      model.compile(loss=transfer_unet_container.dice_loss, optimizer=opt, metrics=metrics)
      LOG.info("Start FXSEM Model inference...")
      LOG.info("Not using patches   ...")

      # Note:read image from secure nas drive
      try:
          print("in try")
          fetch1_data = ns.fetch_data(fxsem_imgs_nas_path,[file_name])
          data = fetch1_data[file_name]
          #print("DATA",data)
      except Exception as e:
          LOG.info({"Error":"image nas api fetching error","message":str(e)})
          return [np.array([]),np.array([]),{"status":"Error","error_msg":"image nas api fetching error"}]
          
      # Note: save the image file to local path
      img_load_path = os.path.join(fxsem_images,file_name)
      
      #Note: Store the image file to local path
      with open(img_load_path, "wb+") as f:
          f.write(data.getbuffer())
      LOG.info({"Success":"Image file stored into {}".format(img_load_path)})
      try:
          x = transfer_unet_container.read_image(img_load_path, patch_flag)
          y_pred = model.predict(np.expand_dims(x, axis=0))[0] > 0.5
          try:
              #os.remove(img_load_path)
              LOG.info("{} removed from local successfully".format(img_load_path))
          except:
              LOG.info("Error: deletion error")
          return [x, y_pred,{"status":"success"}]

      except Exception as e:
          LOG.error(str(e))
          return [np.array([]),np.array([]),{"status":"Error","error_msg":str(e)}]
      print("---------------Deep Learning Inference Time-------------",time.time()-inference_time)