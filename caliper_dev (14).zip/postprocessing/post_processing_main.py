import shutil
from postprocessing.coarse_post_processing import main_coarse
from postprocessing.fine_post_processing import main_fine
import os
import cv2
import numpy as np
import matplotlib.pyplot as plt
import shutil
import time
from config import LOG
import traceback

def post_process_main(original_img, seg_img, algorithm_name, pixel_size, params):
    print("IN POST PROCESSING MAIN")
    LOG.info("Beginning post processing")
    ## check parameters
    pass_check = True
    missing_parameters = []
    if "xsem".casefold() in algorithm_name.casefold():
        img_type = "xsem"
    elif "topdown".casefold() in algorithm_name.casefold():
        img_type = "topdown"
    if (not "bounding_box" in params) and (not "polygon_bounding_box" in params):
        missing_parameters.append("bounding_box or polygon_bounding_box")
    if img_type=="topdown":
        if not "radius_division_ratio" in params["configuration_parameters"]:
            missing_parameters.append("radius_division_ratio")
        if not "linear_approximation_factor" in params["configuration_parameters"]:
            missing_parameters.append("linear_approximation_factor")
        if not "planar_tem" in params["configuration_parameters"]:
            missing_parameters.append("planar_tem")
        else:
            if params["configuration_parameters"]["planar_tem"]==1:
                if not "radius_to_measure" in params["configuration_parameters"]:
                    missing_parameters.append("radius_to_measure")
    if len(missing_parameters)!=0:
        message = ""
        for i in missing_parameters:
            message += i+' '
        error_msg = (404, "Error - Required parameter "+ message+ "missing.")
        pass_check = False

    ## initialize outputs
    extra_output = -1
    img_processed = -1

          
    ## main process
    if pass_check == True:
        try:
          original_img = cv2.cvtColor(original_img.astype(np.uint8), cv2.COLOR_GRAY2BGR)
          seg_img = cv2.cvtColor(seg_img.astype(np.uint8), cv2.COLOR_GRAY2BGR)
          
          print("Beginning coarse post processing")
          img_processed, img, pass_check2, extra_output = main_coarse(seg_img, img_type, params)

          if pass_check2 == True:
              error_msg = (200, "Success")
              if (img_type == "topdown"):

                  LOG.info("Beginning fine post processing")
                  print("Beginning fine post processing")

                  print("Time Fine")
                  start = time.time()
                  img_processed, extra_output = main_fine(original_img, img_processed, extra_output, pixel_size, params)
                  end = time.time()
                  print(end-start) 
          else:
              error_msg = (501, "Error - Segmentation Failure")

        except Exception as e:
            print(e)
            traceback.print_exc()
            error_msg = (202, "Error Encountered During Post Processing")

    return img_processed, error_msg, extra_output