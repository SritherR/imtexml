import shutil
from postprocessing.coarse_post_processing import main_coarse
from postprocessing.fine_post_processing import main_fine
#from coarse_post_processing import main_coarse
#from fine_post_processing import main_fine
import os
import cv2
import numpy as np
import shutil
import time

def post_process_main(original_img, seg_img, algorithm_name, pixel_size, params):

    ## check parameters
    pass_check = True
    missing_parameters = []
    if "xsem".casefold() in algorithm_name.casefold():
        img_type = "xsem"
    elif "topdown".casefold() in algorithm_name.casefold():
        img_type = "topdown"
    if not "bounding_box" in params:
        missing_parameters.append("bounding_box")
    if img_type=="topdown":
        if not "radius_division_ratio" in params["configuration_parameters"]:
            missing_parameters.append("radius_division_ratio")
        if not "linear_approximation_factor" in params["configuration_parameters"]:
            missing_parameters.append("linear_approximation_factor")
        if not "planar_tem" in params["configuration_parameters"]:
            missing_parameters.append("planar_tem")
        else:
            if params["configuration_parameters"]["planar_tem"]==1:
                if not "radius_to_measure" in params["configuration_parameters"]:
                    missing_parameters.append("radius_to_measure")
    if len(missing_parameters)!=0:
        message = ""
        for i in missing_parameters:
            message += i+' '
        error_msg = (404, "Error - Required parameters: "+ message+ "missing.")
        pass_check = False

    ## initialize outputs
    extra_output = -1
    img_processed = -1

    ## main process
    if pass_check == True:
        try:
            print("Inside Try block of Post Processing Main")
            seg_img = seg_img.astype(np.uint8)
            img_processed, pass_check2, extra_output = main_coarse(seg_img, img_type, params)
            if pass_check2 == True:
                error_msg = (200, "Success")
                if (img_type == "topdown"):
                    img_processed, extra_output = main_fine(original_img, img_processed, extra_output, pixel_size, params)
            else:
                error_msg = (501, "Error - image segmentation not accurate")
        except Exception as e:
            print(e)
            error_msg = (202, "Warning - not handled exception encountered. image ignored")
    return img_processed, error_msg, extra_output

