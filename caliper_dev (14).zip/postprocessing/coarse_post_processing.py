import cv2, os
import matplotlib.pyplot as plt, numpy as np
import skimage.transform
from skimage.filters import median
from skimage.measure import profile_line, regionprops, label
from skimage.morphology import skeletonize
from skimage import measure


def remove_artifacts_xsem(img):
    contours, hier = cv2.findContours(img, cv2.RETR_LIST, cv2.CHAIN_APPROX_SIMPLE)
    avg_size = np.median([cv2.contourArea(cnt) for cnt in contours])
    img_copy = img.copy()
    for i, cnt in enumerate(contours):
        if cv2.contourArea(cnt) < avg_size * 0.75:
            cv2.drawContours(img_copy, [cnt], -1, color=(0, 0, 0), thickness=cv2.FILLED)
    contours, hier = cv2.findContours(img_copy, cv2.RETR_LIST, cv2.CHAIN_APPROX_SIMPLE)
    avg_height = np.mean([max(cnt[:, 0][:, 1]) - min(cnt[:, 0][:, 1]) for cnt in contours])
    for i, cnt in enumerate(contours):
        if (max(cnt[:, 0][:, 1]) - min(cnt[:, 0][:, 1]) < avg_height * 0.75):
            cv2.drawContours(img_copy, [cnt], -1, color=(0, 0, 0), thickness=cv2.FILLED)
    return img_copy


def remove_artifacts_topdown(img, contours):
    avg_size = np.median([cv2.contourArea(cnt) for cnt in contours])
    for i, cnt in enumerate(contours):
        if cv2.contourArea(cnt) < avg_size * 0.55:  # or cv2.contourArea(cnt) > avg_size*1.5:
            cv2.drawContours(img, [cnt], -1, color=(0, 0, 0), thickness=cv2.FILLED)
    return img


def remove_edge_intersects(img, contours, params):

    if "bounding_box" in params:
      print("bounding_box")
      print(params["bounding_box"])
      x1,y1,x2,y2 = params["bounding_box"][0]
      l1= x1
      l2= y1
      l3= x2
      l4= y2
      for cntr in contours:
          x, y, w, h = cv2.boundingRect(cntr)
          if x <= l1 or y <= l2 or x + w >= l3 or y + h >= l4:
              cv2.drawContours(img, [cntr], -1, color=(0, 0, 0), thickness=cv2.FILLED)
    elif "polygon_bounding_box" in params:

      # polygon bounding box: keep original image uncropped and later exclude holes from binarization which are outside bounds
      cropbox_x1 = 0
      cropbox_y1 = 0

      # create a mask of the polygon
      # do an & with the input image to get rid of all holes outside the mask

      xs = params['polygon_bounding_box'][::2]
      ys = params['polygon_bounding_box'][1::2]
      polypoints = np.array((xs, ys)).T
      mask = np.zeros(img.shape[:2], dtype='uint8')  # black image the shape of original image

      # add white polygon to make mask
      cv2.drawContours(mask, [polypoints], 0, 255, -1)
      cv2.drawContours(mask, [polypoints], 0, 255, 2)
      
      # keep only segmented holes under polygon mask 
      tmp_img = img & mask

      for cntr in contours:
        for point in cntr:
          if tmp_img[point[0][1]][point[0][0]]==0:
            cv2.drawContours(img, [cntr], -1, color=(0, 0, 0), thickness=cv2.FILLED)
            break
    return img


def find_chg_points(img, horizontal_div, m1, m2):
    m, n = img.shape
    img = remove_first_last_single_row(img, (m2 - m1) // horizontal_div + m1, (m2 - m1) // horizontal_div + m1)
    horz_scan = profile_line(img, (((m2 - m1) // horizontal_div) + m1, 0), (((m2 - m1) // horizontal_div) + m1, n))
    horz_scan = horz_scan.flatten()
    chg = np.argwhere(np.diff(horz_scan) != 0)
    return chg


def average_points_from_lines(horiz_lines):
    dictionary = {}
    for i in horiz_lines:
        length = len(i)
        if length not in dictionary:
            dictionary[length] = 1
        else:
            dictionary[length] += 1
    number_of_gaps = max(dictionary, key=dictionary.get)
    averaged_points = []
    for horiz_line in horiz_lines:
        if len(horiz_line) == number_of_gaps:
            for horiz_point in horiz_line:
                if horiz_point not in averaged_points:
                    found_close_point = False
                    for i, averaged_point in enumerate(averaged_points):
                        if abs(horiz_point - averaged_point) < 10:
                            averaged_points[i] = (averaged_point + horiz_point) // 2
                            found_close_point = True
                            break
                    if found_close_point == False:
                        averaged_points.append(horiz_point)
    points = sorted(averaged_points)
    return points


def find_mid_points(points):
    mids = []
    if len(points) != 0:
        i = 0
        keep = []
        while i < len(points) - 1:
            width = points[i + 1] - points[i]
            if width > 5:
                keep.append(i)
                keep.append(i + 1)
            i += 2
        mid_hole_edges = points[keep].flatten()
        mids = mid_hole_edges[1:-1:2] + ((mid_hole_edges[2::2] - mid_hole_edges[1:-1:2]) // 2)
    return mids

def fill_holes(img):
    im_floodfill = img.copy()
    h, w = img.shape
    mask = np.zeros((h + 2, w + 2), np.uint8)
    cv2.floodFill(im_floodfill, mask, (0, 0), 255)
    im_floodfill_inv = cv2.bitwise_not(im_floodfill)
    im_out = img | im_floodfill_inv
    return im_out


def complete_circles(img):
    contours, hierarchy = cv2.findContours(img, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_NONE)
    hull = []
    for i in range(len(contours)):
        hull.append(cv2.convexHull(contours[i], False))
    for i in range(len(contours)):
        color_contours = (0, 255, 0)  # green - color for contours
        color = (255, 0, 0)  # blue - color for convex hull
        cv2.drawContours(img, hull, i, color, -1)
    return img, hull


def find_centroids(img_processed):
    contours, hier = cv2.findContours(img_processed, cv2.RETR_LIST, cv2.CHAIN_APPROX_SIMPLE)
    centroids = []
    for c in contours:
        M = cv2.moments(c)
        if M["m00"] != 0:
            cX = int(M["m10"] / M["m00"])
            cY = int(M["m01"] / M["m00"])
            centroids.append([cX, cY])
    return centroids


def check_seg_suitability_xsem(img, bb):
    # check shapes similarity
    img = img[bb[1]:bb[3], bb[0]:bb[2]]
    img1 = cv2.cvtColor(img, cv2.COLOR_GRAY2RGB)
    img2 = skeletonize(img1)
    ret, img3 = cv2.threshold(img2, 127, 255, 0)
    gray_img = cv2.cvtColor(img3, cv2.COLOR_RGB2GRAY)
    labels = label(gray_img)
    props = regionprops(labels)
    sum_ = 0
    cnt = 0
    for i in props:
        if i.eccentricity > 0.01:
            sum_ += i.eccentricity
            cnt += 1
    if cnt != 0:
        eccentricity = sum_ / cnt
    else:
        return False, -1
    eccentricity = sum_ / cnt
    if eccentricity > 0.99:
        return True, eccentricity
    else:
        return False, eccentricity


def check_seg_suitability_topdown(img):
    contours, hierarchy = cv2.findContours(img, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_NONE)
    labels = label(img)
    props = regionprops(labels)
    sum_ = 0
    cnt = 0
    for i in props:
        sum_ += i.eccentricity
        cnt += 1
    if cnt != 0:
        eccentricity = sum_ / cnt
    else:
        return False, -1
    if eccentricity < 0.72:
        return True, eccentricity
    else:
        return False, eccentricity


def remove_faulty(img_processed, bb):
    print("BB in remove_faulty: ",bb)
    img_processed = img_processed / 255
    img = img_processed[bb[1]:bb[3], bb[0]:bb[2]].copy()
    m1 = min(np.where(np.mean(img, axis=1) > 0.05)[0])
    m2 = max(np.where(np.mean(img, axis=1) > 0.05)[0])
    chg_points = []
    mid_points = []
    range_values = np.arange(1.8, 2.2, 0.1)
    for i in range_values:
        chg = find_chg_points(img, i, m1, m2).flatten()
        mid = find_mid_points(chg)
        # chg, mid = find_chg_and_mid_points(img, i, m1, m2)
        if len(chg) > 0:
            chg_points.append(chg)
        if len(mid) > 0:
            mid_points.append(mid)
    chg_points = average_points_from_lines(chg_points)
    mid_points = average_points_from_lines(mid_points)
    # take out those that have gaps
    points = chg_points
    for i in range(0, len(points) - 1, 2):
        img = img_processed[bb[1]:bb[3], bb[0]:bb[2]].copy()
        win = img[:, points[i]: points[i + 1]]
        row_avg = np.mean(win, axis=1)
        for k, avg in enumerate(row_avg):
            if avg > 0.55:
                row_avg[k] = 1
            else:
                row_avg[k] = 0
        # print(row_avg)
        row_avg = np.insert(row_avg, 0, 1)
        row_avg = np.append(row_avg, 1)
        white_locs = np.argwhere(row_avg == 1)
        white_locs = white_locs.flatten()
        if len(white_locs) < 1:
            continue
        chg = np.diff(white_locs)
        chg2 = np.argwhere(chg > 15)
        # print(len(chg2))
        if len(chg2) == 0 or len(chg2)==1:
            continue
        else:
            # print(chg2)
            seed_point_x = int(round((points[i] + points[i + 1]) / 2)) + bb[0]
            seed_point_y = (m2 - m1) // 2 + m1 + bb[1]
            labeled = measure.label(img_processed, background=0, connectivity=2)
            if img_processed[seed_point_y, seed_point_x] == 1:
                label = labeled[seed_point_y, seed_point_x]  # known pixel location
                rp = measure.regionprops(labeled)
                props = rp[label - 1]
                for coords in props.coords:
                    img_processed[coords[0], coords[1]] = 0
    # take out those that are interconnected
    points = mid_points
    for i in range(0, len(points), 1):
        img = img_processed[bb[1]:bb[3], bb[0]:bb[2]].copy()
        win = img[:, points[i]: points[i] + 2]
        for row_num, row in enumerate(win):
            for pixel in row:
                if pixel == 1:
                    seed_point_x = points[i] + bb[0]
                    seed_point_y = row_num + bb[1]
                    if img_processed[seed_point_y, seed_point_x] == 1:
                        labeled = measure.label(img_processed, background=0, connectivity=2)
                        label = labeled[seed_point_y, seed_point_x]  # known pixel location
                        rp = measure.regionprops(labeled)
                        props = rp[label - 1]
                        for coords in props.coords:
                            img_processed[coords[0], coords[1]] = 0
    img_processed = cv2.convertScaleAbs(img_processed * 255)  # convert back to 0-255 and uint8
    return img_processed, chg_points, mid_points


def check_mask_removal_ratio(img, img_processed):
    n_white_pix_init = np.sum(img == 255)
    n_white_pix_final = np.sum(img_processed == 255)
    white_ratio = 0
    if n_white_pix_final != 0:
        white_ratio = n_white_pix_final / n_white_pix_init
        if white_ratio > 0.65:
            return True, white_ratio
    return False, white_ratio

def remove_first_last_single_row(img_processed, m1, m2):
    i=0
    if img_processed[int((m2 - m1) // 2 + m1), i] == 1:
        seed_point_x = i
        seed_point_y = int((m2 - m1) // 2 + m1)
        labeled = measure.label(img_processed, background=0, connectivity=2)
        label = labeled[seed_point_y, seed_point_x]  # known pixel location
        rp = measure.regionprops(labeled)
        props = rp[label - 1]
        for coords in props.coords:
            img_processed[coords[0], coords[1]] = 0
    i= len(img_processed[0]) - 1
    if img_processed[int((m2 - m1) // 2 + m1), i] == 1:
        seed_point_x = i
        seed_point_y = int((m2 - m1) // 2 + m1)
        labeled = measure.label(img_processed, background=0, connectivity=2)
        label = labeled[seed_point_y, seed_point_x]  # known pixel location
        rp = measure.regionprops(labeled)
        props = rp[label - 1]
        for coords in props.coords:
            img_processed[coords[0], coords[1]] = 0
    return img_processed

def remove_first_last(img_processed, m1, m2):
    for i in range(0, 50, 1):
        if img_processed[int((m2 - m1) // 2 + m1), i] == 255:
            seed_point_x = i
            seed_point_y = int((m2 - m1) // 2 + m1)
            labeled = measure.label(img_processed, background=0, connectivity=2)
            label = labeled[seed_point_y, seed_point_x]  # known pixel location
            rp = measure.regionprops(labeled)
            props = rp[label - 1]
            for coords in props.coords:
                img_processed[coords[0], coords[1]] = 0
            break
    for i in range(len(img_processed[0]) - 1, len(img_processed[0]) - 50, -1):
        if img_processed[int((m2 - m1) // 2 + m1), i] == 255:
            seed_point_x = i
            seed_point_y = int((m2 - m1) // 2 + m1)
            labeled = measure.label(img_processed, background=0, connectivity=2)
            label = labeled[seed_point_y, seed_point_x]  # known pixel location
            rp = measure.regionprops(labeled)
            props = rp[label - 1]
            for coords in props.coords:
                img_processed[coords[0], coords[1]] = 0
            break
    return img_processed


def main_coarse(img, img_type, params):
    extra_output ={}
    image_type = img_type
    if image_type == "xsem":
        bb = params["bounding_box"][0]
        if not 255 in np.unique(img):
          img = img * 255
        m1 = min(np.where(np.round(np.mean(img, axis=1)) > 0)[0])
        m2 = max(np.where(np.round(np.mean(img, axis=1)) > 0)[0])
        m, n, l = img.shape
        img = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        img_processed = remove_artifacts_xsem(img)
        img_processed = remove_first_last(img_processed, m1, m2)
        img_processed = fill_holes(img_processed)
        img_processed, chg_points, mid_points = remove_faulty(img_processed, bb)
        eccentricity_pass, eccentricity = check_seg_suitability_xsem(img_processed, bb)
        mask_removal_pass, white_ratio = check_mask_removal_ratio(img, img_processed)
        if eccentricity_pass == False or mask_removal_pass == False:
            pass_check = False
        else:
            pass_check = True
        img = cv2.cvtColor(img, cv2.COLOR_GRAY2BGR)
        # if eccentricity_pass == False:
        #     cv2.putText(img, 'Inaccurate Segmentation, Ecc: ' + str(round(eccentricity, 2)), (5, 25),
        #                 cv2.FONT_HERSHEY_SIMPLEX,
        #                 1, (0, 0, 255), 2, cv2.LINE_AA)
        # else:
        #     cv2.putText(img, 'Ecc: ' + str(round(eccentricity, 2)), (5, 25), cv2.FONT_HERSHEY_SIMPLEX,
        #                 1, (0, 0, 255), 2, cv2.LINE_AA)
        # if mask_removal_pass == False:
        #     cv2.putText(img, 'Inaccurate Segmentation, Ratio: ' + str(round(white_ratio, 2)), (5, 50),
        #                 cv2.FONT_HERSHEY_SIMPLEX,
        #                 1, (0, 0, 255), 2, cv2.LINE_AA)
        # else:
        #     cv2.putText(img, 'Ratio: ' + str(round(white_ratio, 2)), (5, 50), cv2.FONT_HERSHEY_SIMPLEX,
        #                 1, (0, 0, 255), 2, cv2.LINE_AA)
        # for i in chg_points:
        #     cv2.circle(img, (82+i, (m2 - m1) // 2 + m1), radius=5, color=(0, 255, 0), thickness=-1)
        # for i in mid_points:
        #     cv2.circle(img, (82+i, (m2 - m1) // 2 + m1), radius=5, color=(0, 0, 255), thickness=-1)

    elif image_type == "topdown":

        # initial centroids
        img = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        initial_centroids = find_centroids(img)
        extra_output["initial_centroids"] = initial_centroids
        # print(len(initial_centroids))
        img_processed, hull = complete_circles(img)
        img_processed = remove_edge_intersects(img_processed, hull, params)
        img_processed = remove_artifacts_topdown(img_processed, hull)
        img_processed = fill_holes(img_processed)
        eccentricity_pass, eccentricity = check_seg_suitability_topdown(img_processed)
        print("eccentricity")
        img_processed = cv2.cvtColor(img_processed, cv2.COLOR_GRAY2RGB)
        if eccentricity_pass == False:
            pass_check = False
        else:
            pass_check = True
    return img_processed, img, pass_check, extra_output