#ENV changes
'''
from dotenv import load_dotenv
import os

env_path = ".env.{env}".format(env=os.environ.get("PY_ENV"))
load_dotenv(dotenv_path=env_path)

PG_DEV = {
  "user": os.getenv('user'),
  "password":os.getenv('password'),
  "host":os.getenv('host'),
  "db":os.getenv('db'),
  "Port" :os.getenv('Port')
}
'''

PG_DEV = {
  "user": "caliper_su",
  "password":"caliper$123",
  "host":"vau-lda-016",
  "db":"caliper",
  "Port" : "5432"
}

#super user
#PG_DEV = {
#  "user": "caliper_su",
#  "password":"caliper_su$123",
#  "host":"dcalpa1824",
#  "db":"caliper",
#  "Port" : "5432"
#}

#read only user
#PG_PRD = {
#  "user": "caliper_nu",
#  "password":"caliper_nu&123",
#  "host":"dcalpa1824",
#  "db":"caliper",
#  "Port" : "5432"
#}