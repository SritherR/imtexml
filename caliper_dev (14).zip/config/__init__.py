# coding: utf-8

"""Configuration Module

Pulls Configuration.
"""

__author__ = ["Divya Shankar","Samuel Joshua","Srither Ranjan"]
__version__ = 1.0

# Standard Library
from os import path

# Third Party Library
from logger import AMATLogger
import pytz
import joblib

# Application Specific Library
from ._postgres_cons import PG_DEV
#from ._postgres_cons import PG_PRD

# We must use this conversion since Cloudera works on UTC
time_zone = pytz.timezone("US/Pacific")

# Use below for Cloudera
PATH = "/home/cdsw/"

LOG = AMATLogger.get_rotating_logger(logpath=PATH + 'log',filename='process')


"""
[testing settings]
"""
master_expected_input_keys = {'algo_id','job_id','demo_id','image','image_name','imageObject','inputs','user_id','uuid','x_limstoken','measured'}

auto_pixel_required_keys = {'image_id','image_obj','image_name','rotation','X-LimsToken'}

# TODo: Find Important variables
log_path = '/dat/usr/x0107686/caliper/log/fxsem/'

base_path = '/dat/usr/x0107686/caliper/imgs/'

#LIMS DB PATHS:
lims_db_qa = "http://sc-dev-140/smslimscache/api/images/"

lims_db_prod = "https://sc-db-315/smslimscache/api/images/"


# NAS PATHS:
source_path_dev = "/var/lib/cdsw/calip-nas-dev/"

#source_path_prd = "/var/lib/cdsw/calip-nas-prd"

source_measurements_path_dev = source_path_dev + "measurements/"
#source_measurements_path_prd = source_path_prd + "measurements/"

fxsem_model_weight_path = source_path_dev + 'model_weights/fxsem/'
#fxsem_model_weight_path = source_path_prd + 'model_weights/fxsem/'

fxsem_model_arch_path = source_path_dev + 'model_weights/fxsem/'
#fxsem_model_arch_path = source_path_prd + 'model_weights/fxsem/'

topdown_model_weight_path = source_path_dev + 'model_weights/topdown/'
#topdown_model_weight_path = source_path_prd + 'model_weights/topdown/'

topdown_model_arch_path = source_path_dev + 'model_weights/topdown/'
#topdown_model_arch_path = source_path_prd + 'model_weights/topdown/'

fxsem_imgs_nas_path = source_path_dev + "imgs/fxsem/"
#fxsem_imgs_nas_path = source_path_prd + "imgs/fxsem/"

topdown_imgs_nas_path = source_path_dev + "imgs/topdown/"
#topdown_imgs_nas_path = source_path_prd + "imgs/topdown/"

model_nasapi_path = r"/var/lib/cdsw/calipalgdev/measurement_algos"
#model_nasapi_path = r"/var/lib/cdsw/calipalgprd/measurement_algos"

auto_pixel_nasapi_path = r"/var/lib/cdsw/calipalgdev/auto_pixelsize/"
#auto_pixel_nasapi_path = r"/var/lib/cdsw/calipalgprd/auto_pixelsize/"

y_pred_imgs_nasapi_path = "/var/lib/cdsw/calipalgdev/y_pred_imgs/"
#y_pred_imgs_nasapi_path = "/var/lib/cdsw/calipalgprd/y_pred_imgs/"

postprocessing_nasapi_path = '/var/lib/cdsw/calipalgdev/post_proc/'
#postprocessing_nasapi_path = '/var/lib/cdsw/calipalgprd/post_proc/'

measurement_algos_nasapi_path = '/var/lib/cdsw/calipalgdev/measurement_algos/'
#measurement_algos_nasapi_path = '/var/lib/cdsw/calipalgprd/measurement_algos/'

nas_upload_image = source_path_dev + "imgs/upload_image/" 

# Local Configs
fxsem_model_weight_loc = PATH+"model_weights/fxsem/"

topdown_model_weight_loc = PATH+"model_weights/topdown/"

fxsem_model_arch_loc = PATH+"model_weights/fxsem/"

topdown_model_arch_loc = PATH+"model_weights/topdown/"

fxsem_images = PATH+"imgs/fxsem/"

topdown_images = PATH+"imgs/topdown/"

model_local_path = PATH+"models/"

auto_pixel_local_path = PATH+"auto_pixel_models/"

y_pred_cdsw_path = PATH+"y_pred_imgs/"

file_extension = 'png'  #refer

image_size = 512
smooth = 1e-15

#patch_flag = 0
patch_size = 256
#stride = 50
stride = 100

PGSQL_CONF = PG_DEV

#PGSQL_CONF = PG_PRD
