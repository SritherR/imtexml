# measure on binarized full xsem images
import numpy as np, pandas as pd
import math
from PIL import Image
from skimage.measure import label, regionprops, regionprops_table, profile_line
from skimage.draw import line
from scipy import ndimage as ndi, spatial
import matplotlib.pyplot as plt
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import PolynomialFeatures
from sklearn.linear_model import Ridge, LinearRegression
from scipy.ndimage.filters import uniform_filter1d
from scipy import stats
import cv2, os
# from transfer_unet_helper import transfer_unet
# from tensorflow.keras.models import model_from_json
import skimage.transform
import traceback


def measure(img, pixel_size, params):

    try:

        if "bounding_box" not in params:
            return -1, -1, -1, (400, "Missing bounding box.")

        bounding_box = params["bounding_box"][0]

        x1,y1,x2,y2 = bounding_box
        bw_data = img[y1:y2, x1:x2]

        ignore_points = []
        if 'ignore_points' in params:
            if len(params["ignore_points"][0]) != 0:
                ignore_points = [(ip_x - x1, ip_y - y1) for (ip_x, ip_y) in params['ignore_points']]

        #        plt.figure()
#        plt.imshow(bw_data, cmap='gray')
#        plt.show()

        try:
            ignore_offset = params["configuration_parameters"]["masking_offset"]
        except KeyError:
            return -1, -1, -1, (400, "Missing offset configuration parameter.")

        TOP_OFFSET = 0
        x_offset = x1
        y_offset = y1

        msmts, summ_stats, linemarkings = [], [], []

        m, n = bw_data.shape[0], bw_data.shape[1]

        # find how many holes -- how many pairs of points are in a horizontal scan at the center (vertically) of the image
        horz_scan = profile_line(bw_data, (m//2,0), (m//2,n), mode='nearest')
        horz_scan = horz_scan.flatten()

        start_in = False
        end_in = False
        if horz_scan[0] == 255:
            # bounding box starts mid hole
            start_in = True

        if horz_scan[-1] == 255:
            # bounding box ends mid hole
            end_in = True

        # plt.figure()
        # plt.plot(horz_scan)
        chg = np.argwhere(np.diff(horz_scan) != 0)
        # plt.plot(chg, [1]*len(chg), "r*")
        # plt.show()
        
        if len(chg) == 0:
          return -1, -1, -1, (500, "Error detecting holes for measurement.")

        # if bounding box starts in the middle of a hole, take out the first chg point
        if start_in:
            chg = chg[1:]
        # if bounding box ends in the middle of a hole, take out the last chg point
        if end_in:
            chg = chg[:-1]

        # move the bounding box edge in to where the first pixel of every row is 0
        # same on the other edge. otherwise have to do more advanced processing later.
        # --> instead of using 0 as the beginning of mids, use the first place where horz_scan == 0. or would need to use a for loop over all rows in the image to find the highest index at which the horz_scan == 0. takes longer...
        # this would also help fix the mask height being measured at the wrong place.
        # need to do the more advanced processing later anyway because if horz_scan DOESNT start with 255, the very top of the lane may include some pixels from the left hole

        # some chg points are right next to each other -- remove these
        keep = np.argwhere((chg[1:] - chg[:-1]).flatten() != 1)
        mid_hole_edges = chg[keep].flatten()
        mid_hole_edges = np.append(mid_hole_edges, chg[-1])


        # find hole "lanes" -- midway points between 2&3, 4&5, 6&7, etc. must be whole numbers bc indices (pixels)
        # mids = mid_hole_edges[1:-1:2] + ((mid_hole_edges[2::2] - mid_hole_edges[1:-1:2]) // 2)
        # mids = np.append([0],mids)
        # mids = np.append(mids, n-1)
        #
#        plt.imshow(bw_data, cmap='gray')
#        plt.plot(mids, [m//2]*len(mids), "b*")
#        plt.show()

        if start_in:
            start_col = np.max((bw_data != 255).argmax(axis=1))
        else:
            start_col = 1
        # if bounding box ends in the middle of a hole, take out the last chg point
        if end_in:

            flipped_bw_data = np.fliplr(bw_data)
            end_col = n - 1 - np.max((flipped_bw_data != 255).argmax(axis=1))
        else:
            end_col = n - 1

        mids = mid_hole_edges[1:-1:2] + ((mid_hole_edges[2::2] - mid_hole_edges[1:-1:2]) // 2)
        mids = np.append([start_col], mids)
        mids = np.append(mids, end_col)

        tops = []
        # find top point to measure from -- the top of the lowest start + the offset
        for lidx in range(len(mids)-1):
            start_x = mids[lidx]
            end_x = mids[lidx+1]

            hole_img = bw_data[:,start_x:end_x]

            for r in range(hole_img.shape[0]):
                if sum(hole_img[r,:] > 0) > 0:
                    # top found
                    tops.append(r)
                    break

        # find lowest top
        lowest = min(tops)
        start_search = lowest + TOP_OFFSET
        
        mask_thickness, depths = [],[]

        # first is 0:mids[0]
        # second is mids[0]:mids[1]
        # last is mids[-2]:mids[-1]

        all_CDs = []
        bow_cds = []
        bow_cd_locs = []
        pinch_cds = []
        pinch_cd_locs = []
        pinch_lm, bow_lm = [], []
        depth_lm, mt_lm = [],[]

        ctr_drift_dist = []
        ctr_drift = []
        ctr_drift_angular = []
        cd_cont = []

        try:
            for lidx in range(len(mids)-1):
                start_x = mids[lidx] + 1
                end_x = mids[lidx+1]

                skip_hole = False

                for ip_x, ip_y in ignore_points:
                    if (start_x-ignore_offset < ip_x) and (end_x+ignore_offset > ip_x):
                        skip_hole = True
                if skip_hole:
                    continue

                hole_img = bw_data[start_search:, start_x:end_x]

                this_hole_CD = []
                this_hole_CD_pts = []
                this_hole_center_ind = []

                # plt.figure()
                # plt.imshow(img[:,x1+start_x:x1+end_x], cmap='gray')

                top_ctr, bot_ctr = 0,0
                for r in range(hole_img.shape[0]):

                      # IF there is a segmentation issue, don't necessarily want to stop searching, just skip over the row
                    if (sum(hole_img[r,:] > 0) < 2):  # if there are less than 2 white pixels, stop searching (don't allow a single pixel to be considered)
                      # stop at bottom of hole
                      # get bottom ctr

                        if r > hole_img.shape[0] * (3/4):
                            #bot_ctr = hole_info[lidx]['center_ind'][-1]
                            bot_ctr = this_hole_center_ind[-1]
                            break
                        else:
                            # fill in 0s for this CD -- record segmentation issue

                            this_hole_CD.append(0)
                            this_hole_CD_pts.append([0,0,0,0])
                            this_hole_center_ind.append(0)

                            continue

                    row = hole_img[r,:]

                    # should measure to the INSIDE of the label edge; don't pick the point outside the label, pick the point inside
                    e1 = np.argwhere(row > 0).flatten()[0]
                    e2 = np.argwhere(row[e1+1:] == 0).flatten()
                    if len(e2) > 0:
                        e2 = e1 + e2[0]#-1 # measure to inside of label on the right (code picks the first 0 point, want the 1 point before that)
                    else:
                        e2 = hole_img.shape[1] -1

                    # above assumes perfect segmentation, what if there is black area between 2 edges (ie at top of hole there is a u shape in segmentation)
                    row_reversed = row[::-1]
                    e2 = len(row_reversed) - np.argwhere(row_reversed > 0).flatten()[0]


                    # top of hole
                    if top_ctr == 0:
                        # calculate the center index at top of hole
                        # started with top_Ctr = 0, continued and skipped this part if some hole area wasn't found, so this is the first time top_ctr isn't 0, ie its the top
                        # and this if statement won't get hit again, now that top_ctr is not 0.
                        top_ctr = int(np.mean([e1,e2]))

                    this_hole_CD.append(e2-e1)
                    this_hole_CD_pts.append([x_offset + start_x + e1, y_offset + start_search + r, x_offset + start_x + e2, y_offset + start_search + r])
                    ctr_index = int(np.mean([e1, e2]))
                    this_hole_center_ind.append(ctr_index)

                    #plt.plot(ctr_index, start_search+y_offset+r, "r*")


                # bottom of hole reached;
                # for each hole, calculate mask height and recess depth

                # bot_ctr is still 0 because didn't hit hole end during CD scan for loop - take last ctr point
                #bot_ctr = hole_info[lidx]['center_ind'][-1]
                bot_ctr = this_hole_center_ind[-1]
                #plt.plot(bot_ctr, y2, "g*")

                #            plt.figure()
                #            plt.imshow(img[:,x1+start_x:x1+end_x], cmap='gray')
                #            plt.plot([top_ctr - 1,top_ctr - 1], [0,600], "r")
                #            plt.plot([top_ctr + 1,top_ctr + 1], [0,600], "r")
                #            plt.plot([0,end_x-start_x], [y2,y2], "b")
                #            plt.show()
                #
                #            print("Taking vertical slice...")
                #            print("X bounds:", x1+int(start_x + top_ctr - 1), x1+int(start_x + top_ctr + 1))

                vert_slice = img[:y1, x1+int(start_x + top_ctr - 1): x1+int(start_x + top_ctr + 1)]
                #
                #            plt.figure()
                #            plt.imshow(vert_slice, cmap='gray')
                #            plt.show()

                col_sig = stats.mode(vert_slice, axis=1)[0]
                col_sig = col_sig.flatten()

                top = np.argwhere(col_sig == 255).flatten()

                if len(top) == 0:
                    # no white above top of bounding box, append 0 and no linemarking
                    mask_thickness.append(0)
                else:
                    top = top[0]
                    mask_thickness.append(y1 - top)
                    #mask_thickness_points.append([x1 + start_x+  top_ctr, top, x1 + start_x + top_ctr, y1])
                    mt_lm.append({"Points": [x1 + start_x+  top_ctr, top, x1 + start_x + top_ctr, y1], "Color": "cyan",
                              "Adjustable": 1, "Annotation": ""})

                depth_slice = img[y2:, x1+int(start_x + bot_ctr - 2):x1+int(start_x + bot_ctr + 1)]
                #col_sig = stats.mode(depth_slice, axis=1)[0]
                col_sig = np.mean(depth_slice, axis=1)
                col_sig = col_sig.flatten()
                bot = np.argwhere(col_sig == 0).flatten()

                if len(bot) == 0:
                    # no depth below bounding box, add 0
                    depths.append(0)
                else:
                    bot = bot[0] #-1 # stop at last white pixel -- UNET typically rounds off bottom of holes, so don't subtract the 1 for now.

                    depths.append(bot)
                    #depth_points.append([x1 + start_x+  bot_ctr, y2, x1 + start_x + bot_ctr, y2+bot])
                    depth_lm.append({"Points": [x1 + start_x + bot_ctr, y2, x1 + start_x + bot_ctr, y2+bot],
                                 "Color": "green", "Adjustable": 1, "Annotation": ""})



                #bow_loc = np.argmax(hole_info[lidx]['CD'])
                #CDs = hole_info[lidx]['CD']
                CDs = np.array(this_hole_CD)
                # store this hole information
                all_CDs.append(CDs)
                CD_pts = np.array(this_hole_CD_pts)

                bow_loc = np.flatnonzero(CDs ==CDs.max())[0]  # if there is a tie, pick the first max -- the highest bow
                # hole_info[lidx]['BowCD'] = hole_info[lidx]['CD'][bow_loc]
                # hole_info[lidx]['BowCD_pts'] = hole_info[lidx]['CD_pts'][bow_loc]
                # hole_info[lidx]['BowLoc'] = bow_loc

                bow_cds.append(CDs[bow_loc])
                bow_cd_locs.append(bow_loc)
                bowpts = CD_pts[bow_loc]
                #bow_lm.append({"Points": bowpts, "Color": "blue", "Adjustable": 0, "Annotation": ""})
                bow_lm.append({"Points": bowpts.tolist(), "Color": "pink", "Adjustable": 1, "Annotation": ""})

                pinch_loc = np.flatnonzero(CDs ==(CDs[np.nonzero(CDs)]).min())[-1]  # if there is a tie, pick the LAST min -- the lowest pinch
                # hole_info[lidx]['PinchCD'] = hole_info[lidx]['CD'][pinch_loc]
                # hole_info[lidx]['PinchCD_pts'] = hole_info[lidx]['CD_pts'][pinch_loc]
                # hole_info[lidx]['PinchLoc'] = pinch_loc

                pinch_cds.append(CDs[pinch_loc])
                pinch_cd_locs.append(pinch_loc)
                pinch_pts = CD_pts[pinch_loc]
                #pinch_lm.append({"Points": pinch_pts, "Color": "green", "Adjustable": 0, "Annotation": ""})
                pinch_lm.append({"Points": pinch_pts.tolist(), "Color": "magenta", "Adjustable": 1, "Annotation": ""})

                # hole_info[lidx]['Center_Drift_Dist'] = top_ctr - bot_ctr
                ctr_drift_dist.append(top_ctr-bot_ctr)

                # for stats calculations, remove 0s
                CDs = CDs[np.nonzero(CDs)]

                #Calculate L2Norm -- 3 sigma of residuals of CDs & straight line fitted through CDs
                x = np.array(range(len(CDs))).reshape(-1,1)
                y = CDs.reshape(-1,1) #np.array(hole_info[lidx]['CD']).reshape(-1,1)

                # model = make_pipeline(PolynomialFeatures(1), Ridge())
                # model.fit(x,y)
                # yy = model.predict(x)
                model = LinearRegression()
                model.fit(x,y)
                yy = model.predict(x)
                y = y.flatten()
                yy = yy.flatten()

                l2norm = 3 * math.sqrt(sum((y - yy.flatten())**2))
                #hole_info[lidx]['CD_continuity'] = l2norm
                cd_cont.append(l2norm)
                #
                # Calculate LER = 3 sigma of residuals between vertical @ hole center @ top of hole & all other calculated hole centers
                # vector of the center at the top of hole, repeated for each CD calculation
                # vector of the center of the hole at each CD calculation (midpt between x2 and x1)
                #top_ctr_vec = np.array([top_ctr]*len(hole_info[lidx]['center_ind']))
                top_ctr_vec = np.array([top_ctr] * len(this_hole_center_ind))
                # smooth center indices
                #ctr = uniform_filter1d(hole_info[lidx]['center_ind'], size=11)
                ctr = uniform_filter1d(this_hole_center_ind, size=11)
                LER = 3 * math.sqrt(sum((top_ctr_vec - ctr.flatten())**2)) # test this
                #hole_info[lidx]['Center_Drift'] = LER
                ctr_drift.append(LER)

                # Calculate LER2 - fit line through hole centers & take 3 sigma of residuals w actual hole centers
                model = LinearRegression()
                xx = np.array(range(len(ctr))).reshape(-1,1)
                model.fit(xx,ctr)
                ctr_fit = model.predict(xx)
                l2norm2 = 3 * math.sqrt(sum((ctr - ctr_fit.flatten())**2))
                #hole_info[lidx]['Center_Drift_Angular'] = l2norm2
                ctr_drift_angular.append(l2norm2)
        except Exception as e:
            return -1, -1, -1, (500, "Error calculating measurements for hole {}.".format(lidx))

        bow_cds = np.array(bow_cds)
        bow_cd_locs = np.array(bow_cd_locs)
        pinch_cds = np.array(pinch_cds)
        pinch_cd_locs = np.array(pinch_cd_locs)

        ctr_drift_dist = np.array(ctr_drift_dist)
        ctr_drift = np.array(ctr_drift)
        ctr_drift_angular = np.array(ctr_drift_angular)
        cd_cont = np.array(cd_cont)

        # add linemarkings data
        linemarkings.append({"Measurement": "Bow CD [nm]", "Linemarkings": bow_lm})
        linemarkings.append({"Measurement": "Pinch CD [nm]", "Linemarkings": pinch_lm})
        linemarkings.append({"Measurement": "Mask Height [nm]", "Linemarkings": mt_lm})
        linemarkings.append({"Measurement": "Depth [nm]", "Linemarkings": depth_lm})

        # calculate the crossover location (from bow to pinch)
        # calculate the area before the crossover and the area after the crossover
        # calculate the cummulative difference between linear fit of CD averages and vector of CD averages
        # calculate the bow extent (ratio of ^diff to area under linear fit)*100

        # make df of all CDs for all holes -- align by top CD, drop the lowest CDs for all

        #shortest_hole = min([len(hi['CD']) for k,hi in hole_info.items()])
        shortest_hole = min([len(cds) for cds in all_CDs])

        CD_df = pd.DataFrame()
        # for hidx, hinfo in hole_info.items():
        #     CD_df[hidx] = hinfo['CD'][:shortest_hole]
        for hidx, cds in enumerate(all_CDs):
            CD_df[hidx] = cds[:shortest_hole]

        # replace 0s with Nan so they will get ignored in averaging
        CD_df = CD_df.replace(0, np.NaN)

        CD_avgs = CD_df.mean(axis=1)
        CD_avgs = uniform_filter1d(CD_avgs.to_numpy(), size=11)

        top5_avg = np.mean(CD_avgs[:5])
        bot5_avg = np.mean(CD_avgs[-5:len(CD_avgs)])

        model = LinearRegression()
        model.fit(np.array([0, len(CD_avgs)]).reshape(-1,1), np.array([top5_avg, bot5_avg]).reshape(-1,1))
        yy = model.predict(np.arange(len(CD_avgs)).reshape(-1,1))

        yy = yy.flatten()

        cumm_diff = sum(abs(yy - CD_avgs))

        # to find crossover point, remove first 10 points and last 10 points, which can intersect with fit line due to fitting,
        # find where the CD_avgs vector intersects (crosses over) the fit straight line, add 10 for the first 10 removed pts
        yy_find = yy[10:]
        CD_avgs_find = CD_avgs[10:]

        t = 0.01
        index = np.argwhere(abs(yy_find - CD_avgs_find) < t)
        while (index.size == 0) and t < 0.5:  # try increasing thresholds until 0.5, then call it No Crossover
            t += 0.01
            index = np.argwhere(abs(yy_find - CD_avgs_find) < t)

        if index.size == 0:
            crossover = len(CD_avgs)-1
            diff_right = 0
        else:
            crossover = index.flatten()[0] + 10

            mean_vect_right = CD_avgs[crossover:]
            yy_right = yy[crossover:]

            x2_right = np.arange(len(yy_right))

            auc_right = np.trapz(mean_vect_right, x2_right)
            aul_right = np.trapz(yy_right, x2_right)

            diff_right = auc_right - aul_right

        mean_vect_left = CD_avgs[:crossover]
        yy_left = yy[:crossover]
        x2_left = np.arange(len(yy_left))
        auc_left = np.trapz(mean_vect_left, x2_left)
        aul_left = np.trapz(yy_left, x2_left)
        diff_left = auc_left - aul_left

        AUC = np.trapz(CD_avgs, np.arange(len(CD_avgs)))
        AUL = np.trapz(yy, np.arange(len(yy)))
        diff = AUC - AUL

        isBow = diff > 0
        bowextent = diff/AUL * 100

        # LINEMARKINGS
        # Bow, Pinch CD for each hole
        # Average Bow location (vertical bar)
        # Average Pinch location (vertical bar)
        # Crossover location (horizontal bar)

        #avg_pinch_loc = np.mean([hole_info[lidx]['PinchLoc'] for lidx in hole_info.keys()])
        #avg_bow_loc = np.mean([hole_info[lidx]['BowLoc'] for lidx in hole_info.keys()])
        avg_pinch_loc = np.mean(pinch_cd_locs)
        avg_bow_loc = np.mean(bow_cd_locs)

        # add linemarkings for avg bow and pinch location, crossover

        linemarkings.append({"Measurement": "Crossover", "Linemarkings": [{
            "Points": [x_offset + mids[0],  y_offset + start_search + crossover, x_offset + mids[-1]-1, y_offset + start_search + crossover],
            "Color": "red", "Adjustable": 0, "Annotation": ""}]})

        linemarkings.append({"Measurement": "Bow CD Location [nm]", "Linemarkings": [
            {"Points": [x_offset + 20, y_offset + start_search, x_offset + 20, y_offset + start_search + avg_bow_loc],
             "Color": "pink", "Adjustable": 0, "Annotation": ""}]})

        linemarkings.append({"Measurement": "Pinch CD Location [nm]", "Linemarkings": [
            {"Points": [x_offset + 15, y_offset + start_search, x_offset + 15, y_offset + start_search + avg_pinch_loc],
             "Color":"magenta", "Adjustable": 0, "Annotation": ""}]})

        # top & bot CDs
        top_cds = np.array([cd[0] for cd in all_CDs])
        bot_cds = np.array([cd[-1] for cd in all_CDs])

        all_CDs = np.array([np.array(l) for l in all_CDs])
        bow_cds = np.array(bow_cds)
        bow_cd_locs = np.array(bow_cd_locs)
        pinch_cds = np.array(pinch_cds)
        pinch_cd_locs = np.array(pinch_cd_locs)
        ctr_drift_dist = np.array(ctr_drift_dist)
        ctr_drift = np.array(ctr_drift)
        ctr_drift_angular = np.array(ctr_drift_angular)
        cd_cont = np.array(cd_cont)
        depths = np.array(depths)
        mask_thickness = np.array(mask_thickness)

        # all_CDs might be a ragged array..
        avg_cds = [np.mean(CD_array) for CD_array in all_CDs]

        summ_stats.append({"Name": "Average CD [nm]", "Value": round(np.mean(avg_cds) * pixel_size, 5),
                           "Summarized_Measurement": "CD [nm]"})

        # calculate summary stats
        summ_stats.append({"Name": 'Average Bow CD [nm]', "Value": round(np.mean(bow_cds) * pixel_size, 5),
                           "Summarized_Measurement": "Bow CD [nm]"})
        summ_stats.append({"Name": 'Average Pinch CD [nm]', "Value": round(np.mean(pinch_cds) * pixel_size, 5),
                           "Summarized_Measurement": "Pinch CD [nm]"})
        summ_stats.append({"Name": 'Average CD Continuity', "Value": round(np.mean(cd_cont), 5),
                           "Summarized_Measurement": "CD Continuity"})
        summ_stats.append({"Name": "Average Center Drift [nm]", "Value": round(np.mean(ctr_drift) * pixel_size, 5),
                           "Summarized_Measurement": "Center Drift [nm]"})
        summ_stats.append({"Name": "Average Center Drift Horizontal Distance [nm]",
                           "Value": round(np.mean(ctr_drift_dist) * pixel_size, 5),
                           "Summarized_Measurement": "Center Drift Horizontal Distance [nm]"})
        summ_stats.append({"Name": 'Average Center Drift Angular', "Value": round(np.mean(ctr_drift_angular), 5),
                           "Summarized_Measurement": "Center Drift Angular"})
        summ_stats.append({"Name": 'Average Top CD [nm]', "Value": round(np.mean(top_cds) * pixel_size, 5),
                           "Summarized_Measurement": "Top CD [nm]"})
        summ_stats.append({"Name": "Average Bottom CD [nm]", "Value": round(np.mean(bot_cds) * pixel_size, 5),
                           "Summarized_Measurement": "Bottom CD [nm]"})
        summ_stats.append({"Name": 'isBow', "Value": isBow, "Summarized_Measurement": ""})
        summ_stats.append({"Name": 'BowExtent', "Value": round(bowextent, 5), "Summarized_Measurement": ""})
        summ_stats.append({"Name": 'Area Before Crossover [nm^2]', "Value": round(diff_left * pixel_size, 5),
                           "Summarized_Measurement": ""})
        summ_stats.append({"Name": 'Area After Crossover [nm^2]', "Value": round(diff_right * pixel_size, 5),
                           "Summarized_Measurement": ""})
        summ_stats.append(
            {"Name": 'Cumulative Pixels From Linear Fit', "Value": round(cumm_diff, 5), "Summarized_Measurement": ""})

        summ_stats.append({"Name": 'Average Mask Height [nm]', "Value": round(np.mean(mask_thickness) * pixel_size, 5),
                           "Summarized_Measurement": "Mask Height [nm]"})
        summ_stats.append({"Name": 'Average Depth [nm]', "Value": round(np.mean(depths) * pixel_size, 5),
                           "Summarized_Measurement": "Depth [nm]"})
        summ_stats.append({"Name": '3Sigma Depth [nm]', "Value": round(3*np.std(depths) * pixel_size, 5),
                           "Summarized_Measurement": "Depth [nm]"})


        # record data collected for holes in measurements
        msmts.append({"Name": "CD [nm]", "Value": (all_CDs * pixel_size).round(5)})
        msmts.append({"Name": "Bow CD [nm]", "Value": (bow_cds * pixel_size).round(5)})
        msmts.append({"Name": "Bow CD Location [nm]", "Value": (bow_cd_locs * pixel_size).round(5)})
        msmts.append({"Name": "Pinch CD [nm]", "Value": (pinch_cds * pixel_size).round(5)})
        msmts.append({"Name": "Pinch CD Location [nm]", "Value": (pinch_cd_locs * pixel_size).round(5)})
        msmts.append({"Name": "Center Drift Horizontal Distance [nm]", "Value": (ctr_drift_dist * pixel_size).round(5)})
        msmts.append({"Name": "Center Drift [nm]", "Value": (ctr_drift * pixel_size).round(5)})
        msmts.append({"Name": "Center Drift (Angular)", "Value": ctr_drift_angular.round(5)})  # no pix size bc angles
        msmts.append({"Name": "CD Continuity", "Value": cd_cont.round(5)})  # no pix size bc measure of residuals
        msmts.append({"Name": "Depth [nm]", "Value": (depths * pixel_size).round(5)})
        msmts.append({"Name": "Mask Height [nm]", "Value": (mask_thickness * pixel_size).round(5)})

        msmts.append({"Name": "Top CD [nm]", "Value": (top_cds * pixel_size).round(5)})
        msmts.append({"Name": "Bottom CD [nm]", "Value": (bot_cds * pixel_size).round(5)})

        return msmts, summ_stats, linemarkings, (200, "Success.")

    except Exception as e:

        return -1, -1, -1, (500, "Error in Full XSEM Measurement case.")
