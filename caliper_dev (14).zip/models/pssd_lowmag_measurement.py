import numpy as np, pandas as pd
import math
from skimage import morphology
import cv2, os
import matplotlib.pyplot as plt
import skimage.transform
from scipy import signal
from skimage import exposure

def measure(img, pixel_size, params):
    measurements = -1
    linemarkings = -1
    summ = -1
    params_check = True
    missing_parameters = []
    if ('bounding_box' not in params):
        return -1, -1, -1, (400, "Missing bounding box.")
    try:
      measurements = []
      linemarkings = []
      summ = []
      img_org = img.copy()
      bounding_box = params["bounding_box"][0]
      
      plt.figure()
      plt.imshow(img)
      plt.show()
      
      if bounding_box is not None:
        x1,y1,x2,y2 = bounding_box
        x1=bounding_box[0]
        y1=bounding_box[1]
        x2 = bounding_box[2]
        y2 = bounding_box[3]
        img = img_org[y1:y2,x1:x2]
      else:
        x1=0
        y1=0
        x2 = len(img_org[0])
        y2 = len(img_org)
        img = img_org
  #    linemarkings.append({"Points": [x1, y1, x2, y1], "Color": "purple"})
  #    linemarkings.append({"Points": [x1, y2, x2, y2], "Color": "purple"})
  #    linemarkings.append({"Points": [x1, y1, x1, y2], "Color": "purple"})
  #    linemarkings.append({"Points": [x2, y1, x2, y2], "Color": "purple"})
      top_slice = img[5:25, :]
      if np.mean(np.mean(top_slice))<100:
          minv = 0.3
          maxv = 0.5
      else:
          minv = 0.4
          maxv = 0.6
      plt.figure()
      plt.imshow(img)
      plt.show()
      p1, p2 = int(minv*255), int(maxv*255)
      top_slice_adj = exposure.rescale_intensity(top_slice, in_range=(p1, p2))
      top_slice_smooth = top_slice_adj
      bin_top_slice = cv2.threshold(top_slice_smooth, int(0.8*255),255,cv2.THRESH_BINARY)[1]
      kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE,(6,6))
      filled_pillars = cv2.morphologyEx(bin_top_slice,cv2.MORPH_OPEN,kernel)
      edge_bars = np.pad(filled_pillars, ((0,2), (0,2)), 'constant', constant_values=(0))
      filled_edges = cv2.bitwise_not(morphology.area_opening(cv2.bitwise_not(filled_pillars), 1000))
      final = filled_edges[:,2:-2]
      col_sig = np.round(np.mean(final, axis= 0))
      spaces = np.argwhere(col_sig>0).flatten()
      chg = np.argwhere(np.diff(spaces.flatten())>25).flatten()
      pillar_edges = spaces[chg]
      for i in chg:
          pillar_edges= np.insert(pillar_edges, 1, spaces[i+1])
      pillar_edges= np.insert(pillar_edges, 1, spaces[0])
      pillar_edges= np.insert(pillar_edges, 1, spaces[-1])
      pillar_edges = np.sort(pillar_edges)
      midpts = pillar_edges[0::2] + ((pillar_edges[1::2] - pillar_edges[0:-1:2]) // 2)
      minv = 0.2
      maxv = 0.7
      p1, p2 = int(minv*255), int(maxv*255)
      img2 = exposure.rescale_intensity(img, in_range=(p1, p2))
      binamt = 0.4;
      s = 0.9;
      filt_img3 = signal.medfilt2d(img2, [5,15])
      if params["configuration_parameters"]["globalbinarize"]==True:
          space_filled = cv2.threshold(filt_img3, int(binamt*255), 255, cv2.THRESH_BINARY)[1]
      else:
          space_filled = cv2.adaptiveThreshold(filt_img3, int(s*255), cv2.ADAPTIVE_THRESH_MEAN_C,
                                               cv2.THRESH_BINARY, 11, 12);
      lookahead = 30;
      depths = []
      for i in range(len(midpts)):
          slice1 = space_filled[:, midpts[i]-5:midpts[i]+5]
          row_means = np.round(np.mean(slice1, axis=1)/255)
          bottom = np.argwhere(row_means==0).flatten()[0]
          if np.sum(row_means[bottom:bottom+lookahead]) >= lookahead/6:
              index1 = np.argwhere(row_means[bottom:] == 1).flatten()[0]
              if True in (row_means[bottom+index1:] == 0):
                  bottom = bottom + np.argwhere(row_means[bottom+index1:] == 0).flatten()[0]
          depths.append(bottom)
      for i in range(len(midpts)):
          if depths[i] < np.mean(depths) - 2*np.std(depths):
              depths[i] = 0 # set as zero so it will be removed below when taking mean
          elif depths[i] > np.mean(depths) + 2*np.std(depths):
              depths[i] = 0 # set as zero so it will be removed below when taking mean
      # if bounding box given, calculate mask thicknesses
      depths_converted = [i*pixel_size for i in depths]
      meas_list = depths_converted
      meas_list = [round(elem, 5) for elem in meas_list]
      measurements.append({"Name": "Depth", "Value": meas_list})
      meas_num = np.mean(depths_converted)
      meas_num = round(meas_num, 5)
      summ.append({"Name": "Average Depth", "Value": meas_num, "Summarized Measurement": "Depth"})
      points= []
      for i, mid in enumerate(midpts):
          points.append({"Points": [x1 + mid, y1, x1 + mid, y1 + depths[i]], "Color": "blue", \
                                   "adjustable": 0, "annotation": ""})
      # points.append({"Points": [x1, y1, x2, y1], "Color": "yellow","adjustable": 0, "annotation": ""})
      linemarkings.append({"Measurement": "Depth", "Linemarkings": points})

      # plot on mask
      plt.figure(figsize=(10,10))
      plt.imshow(img_org, cmap='gray')
  #    print(linemarkings)
      for lm in linemarkings[0]["Linemarkings"]:
  #        print(lm)
          x1,y1,x2,y2 = lm["Points"]
          plt.plot([x1,x2], [y1,y2], c=lm["Color"])
      plt.show()
      error_msg = (200, "Success")
      return measurements, summ, linemarkings, error_msg
    except Exception as e:
        print(e)
        error_msg = (500, "Measurement failed.")
        return -1, -1, -1, error_msg