# MAIN FILE FOR MEASUREMENT -- POINT OF ENTRY FOR UI TO MSMT CODE
from models.full_xsem_measurements import measure as fxsem
from models.highmagbot_xsem_measurement import measure as xsem_highmag_bot
from models.highmagmid_xsem_measurement import measure as xsem_highmag_mid
from models.highmagtop_xsem_measurement import measure as xsem_highmag_top
from models.draco_topdown_measurements import measure as topdown
from models.pssd_lowmag_measurement import measure as pssd_lowmag
from models.full_xsem_without_unet_mask import measure as fxsem_wo_unet_mask
from models.planar_tem_classical import measure as planar_tem_classical
from models.test_no_reqs import measure as test

#from full_xsem_measurements import measure as fxsem
#from highmagbot_xsem_measurement import measure as xsem_highmag_bot
#from highmagmid_xsem_measurement import measure as xsem_highmag_mid
#from highmagtop_xsem_measurement import measure as xsem_highmag_top
#from draco_topdown_measurements import measure as topdown
#from pssd_lowmag_measurement import measure as pssd_lowmag

def measure(img, algorithm_name, pixel_size, params):

    if algorithm_name == "Full XSEM":
        return fxsem(img, pixel_size, params)
    elif algorithm_name == "High Mag XSEM Top":
        return xsem_highmag_top(img, pixel_size, params)
    elif algorithm_name == "High Mag XSEM Middle":
        return xsem_highmag_mid(img, pixel_size, params)
    elif algorithm_name == "High Mag XSEM Bottom":
        return xsem_highmag_bot(img, pixel_size, params)
    elif algorithm_name == "Topdown":
        return topdown(img, pixel_size, params)
    elif algorithm_name == "PSSD Low Mag":
        return pssd_lowmag(img, pixel_size, params)
    elif algorithm_name == "Full XSEM Classical":
        return fxsem_wo_unet_mask(img, pixel_size, params)
    elif algorithm_name == "Planar TEM Classical":
        return planar_tem_classical(img, pixel_size, params)
    elif algorithm_name == "Test No Required Inputs":
        return test(img, pixel_size, params)
    else:
        return -1, -1, -1, (500, "Measurement Algorithm Does Not Exist.")