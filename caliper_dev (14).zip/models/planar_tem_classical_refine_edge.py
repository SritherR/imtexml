import cv2, os
import matplotlib.pyplot as plt, numpy as np
from skimage.measure import profile_line
import scipy.interpolate
import matplotlib.pyplot as plt, numpy as np
from skimage.measure import profile_line
import scipy.interpolate
from sklearn.metrics import mean_squared_error
from skimage.draw import line
import math
from scipy import ndimage, misc
import time

def complete_circles(img):
    contours, hierarchy = cv2.findContours(img, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_NONE)
    hull = []
    for i in range(len(contours)):
        hull.append(cv2.convexHull(contours[i], False))
    for i in range(len(contours)):
        color_contours = (0, 255, 0)  # green - color for contours
        color = (255, 0, 0)  # blue - color for convex hull
        cv2.drawContours(img, hull, i, color, -1)
    return img, hull

def fill_enclosed_holes(img):
    im_floodfill = img.copy()
    h, w = img.shape
    mask = np.zeros((h + 2, w + 2), np.uint8)
    for i in range(min(h,w)):
        if img[i,i]==0:
            cv2.floodFill(im_floodfill, mask, (i, i), 255)
            break
    im_floodfill_inv = cv2.bitwise_not(im_floodfill)
    im_out = img | im_floodfill_inv
    return im_out

def find_centroids(img_binary_mask, contours):
    centroids = []
    processed_contours = []
    for c in contours:
        M = cv2.moments(c)
        if M["m00"] != 0:
            cX = int(M["m10"] / M["m00"])
            cY = int(M["m01"] / M["m00"])
            centroids.append([cX, cY])
            processed_contours.append(c)
    return centroids, processed_contours


def find_limit(horz_scan, thres, type_img, radius_to_measure, point1, point2, time):
    plot = False
    try:
        horz_scan = horz_scan.astype(float)
        derv_1_y = []
        for num in range(1, len(horz_scan) - 1):
            derv_1_y.append((horz_scan[num + 1] - horz_scan[num - 1]) / 2)
        # print(horz_scan)
        # print(derv_1_y)
        min_der = min(derv_1_y)
        for i, j in enumerate(derv_1_y):
            derv_1_y[i] = derv_1_y[i]+ abs(min_der)
        derv_1_y = np.insert(derv_1_y, 0, 0.0)
        derv_1_y = np.append(derv_1_y, 0.0)

        if type_img == 0:
            pos1_x = np.argmax(derv_1_y[3:-3]) + 3
            pos1_y = derv_1_y[pos1_x]
        elif type_img==1 and radius_to_measure=="exterior":
            if time == 1:
                interval = derv_1_y[3:int(len(horz_scan) / 2) -5]
                pos1_x = np.argmax(interval) + 3
                pos1_y = derv_1_y[pos1_x]
            else:
                interval = derv_1_y[3:-3]
                pos1_x = np.argmax(interval) + 3
                pos1_y = derv_1_y[pos1_x]
        elif type_img==1 and radius_to_measure=="interior":
            if time == 1:
                interval = derv_1_y[3:int(len(horz_scan) / 2) + 5]
                pos1_x = np.argmax(interval) + 3
                pos1_y = derv_1_y[pos1_x]
            else:
                interval = derv_1_y[3:-3]
                pos1_x = np.argmax(interval) + 3
                pos1_y = derv_1_y[pos1_x]
        alpha1, alpha2, alpha3 = 0.2, 0.2, 0.5
        # find alpha1% of max in derv_1_y and then y in horz_scan
        value1 = pos1_y - alpha1 * pos1_y
        index = -1
        # for i in range(pos1_x, len(derv_1_y) - 1):
        #     if derv_1_y[i] >= value1 and derv_1_y[i + 1] <= value1:
        #         index = i
        #         break
        for i in range(pos1_x, len(derv_1_y) - 2):
            if derv_1_y[i] >= value1 and derv_1_y[i + 1] <= value1:
                index = i
                break
        if index == -1:
            # print(np.argmin(derv_1_y[pos1_x, len(derv_1_y) - 1]))
            index = np.argmin(derv_1_y[pos1_x, len(derv_1_y) - 1]) + pos1_x
            value1 = np.average([derv_1_y[pos1_x], derv_1_y[index]])
        x = [pos1_x, index + 1]
        if x[0] != x[1]:
            y = [derv_1_y[pos1_x], derv_1_y[index + 1]]
            alpha = (y[1] - y[0]) / (x[1] - x[0])
            if alpha != 0:
                beta = y[0] - alpha * x[0]
                x_new1 = (value1 - beta) / alpha
            else:
                x_new1 = x[0]
        else:
            x_new1 = x[0]
        # transfer to horz_scan and find y
        index = int(np.floor(x_new1))
        x = [index, index + 1]
        if x[0] != x[1]:
            y = [horz_scan[index], horz_scan[index + 1]]
            alpha = (y[1] - y[0]) / (x[1] - x[0])
            beta = y[0] - alpha * x[0]
            y_new1 = alpha * x_new1 + beta
        else:
            y_new1 = alpha * x[0] + beta

        index = -1
        # find alpha2% of max in derv_1_y and then y in horz_scan
        value2 = pos1_y - alpha2 * pos1_y
        # for i in range(0, pos1_x):
        #     if derv_1_y[i] <= value2 and derv_1_y[i + 1] >= value2:
        #         index = i
        #         break
        for i in range(1, pos1_x):
            if derv_1_y[i] <= value2 and derv_1_y[i + 1] >= value2:
                index = i
                break
        if index == -1:
            index = np.argmin(derv_1_y[1: pos1_x][::-1]) + 1
            value2 = np.average([derv_1_y[pos1_x], derv_1_y[index]])
        x = [index, pos1_x]
        if x[0] != x[1]:
            y = [derv_1_y[index], derv_1_y[pos1_x]]
            alpha = (y[1] - y[0]) / (x[1] - x[0])
            if alpha != 0:
                beta = y[0] - alpha * x[0]
                x_new2 = (value2 - beta) / alpha
            else:
                x_new2 = x[0]
        else:
            x_new2 = x[0]
        index = int(np.ceil(x_new2))
        x = [index - 1, index]
        if x[0] != x[1]:
            y = [horz_scan[index - 1], horz_scan[index]]
            alpha = (y[1] - y[0]) / (x[1] - x[0])
            beta = y[0] - alpha * x[0]
            y_new2 = alpha * x_new2 + beta
        else:
            y_new2 = alpha * x[0] + beta

        # find alpha3% in horz scan
        x = [x_new1, x_new2]
        y = [y_new1, y_new2]
        alpha = (y[1] - y[0]) / (x[1] - x[0])
        if y[0] != y[1]:
            beta = y[0] - alpha * x[0]
            y_new3 = (y[1] - y[0]) * alpha3 + y[0]
            x_new3 = (y_new3 - beta) / alpha
        else:
            y_new3 = (y[1] - y[0]) * alpha3 + y[0]
            x_new3 = x[0]
        # print(x_new3)
        # # find x of value_80% in derv_1_y and then y in horz_scan
        # value_80 = pos1_y - 0.2 * pos1_y
        # index = -1
        # for i in range(pos1_x, len(derv_1_y) - 1):
        #     if derv_1_y[i] >= value_80 and derv_1_y[i + 1] <= value_80:
        #         index = i
        #         break
        # x = [pos1_x, index + 1]
        # if x[0] != x[1]:
        #     y = [int(derv_1_y[pos1_x]), int(derv_1_y[index + 1])]
        #     alpha = (y[1] - y[0]) / (x[1] - x[0])
        #     beta = y[0] - alpha * x[0]
        #     x_new1 = (value_80 - beta) / alpha
        # else:
        #     x_new1 = x[0]
        # # transfer to horz_scan and find y
        # index = int(np.floor(x_new1))
        # x = [index, index + 1]
        # if x[0] != x[1]:
        #     y = [int(horz_scan[index]), int(horz_scan[index + 1])]
        #     alpha = (y[1] - y[0]) / (x[1] - x[0])
        #     beta = y[0] - alpha * x[0]
        #     y_new1 = alpha * x_new1 + beta
        # else:
        #     y_new1 = alpha * x[0] + beta
        #
        # # find x of value_20% in derv_1_y and then y in horz_scan
        # value_20 = pos1_y - 0.2 * pos1_y
        # for i in range(0, pos1_x):
        #     if derv_1_y[i] <= value_20 and derv_1_y[i + 1] >= value_20:
        #         index = i
        #         break
        # x = [index, pos1_x]
        # if x[0] != x[1]:
        #     y = [int(derv_1_y[index]), int(derv_1_y[pos1_x])]
        #     alpha = (y[1] - y[0]) / (x[1] - x[0])
        #     beta = y[0] - alpha * x[0]
        #     x_new2 = (value_20 - beta) / alpha
        # else:
        #     x_new2 = x[0]
        # # transfer to horz_scan and find y
        # index = int(np.ceil(x_new2))
        # x = [index - 1, index]
        # if x[0] != x[1]:
        #     y = [int(horz_scan[index - 1]), int(horz_scan[index])]
        #     alpha = (y[1] - y[0]) / (x[1] - x[0])
        #     beta = y[0] - alpha * x[0]
        #     y_new2 = alpha * x_new2 + beta
        # else:
        #     y_new2 = alpha * x[0] + beta
        #
        # # find 50%
        # x = [x_new1, x_new2]
        # y = [y_new1, y_new2]
        # alpha = (y[1] - y[0]) / (x[1] - x[0])
        # if y[0] != y[1]:
        #     beta = y[0] - alpha * x[0]
        #     y_new3 = (y[1] - y[0]) * thres + y[0]
        #     x_new3 = int(round((y_new3 - beta) / alpha))
        # else:
        #     y_new3 = (y[1] - y[0]) * thres + y[0]
        #     x_new3 = int(x[0])
        found = True
        if plot == True:
            plt.figure(1, figsize=(10,10))
            plt.subplot(211)
            plt.title("Derivative of Gray Level")
            for i, j in enumerate(derv_1_y):
                plt.plot(i, j, '.', markersize=10, color='black')
            plt.plot(pos1_x, pos1_y, '.', markersize=14, color='red')
            plt.plot(x_new1, value_80, '.', markersize=14, color='green')
            plt.plot(x_new2, value_20, '.', markersize=14, color='green')

            plt.subplot(212)
            plt.title("Gray Level")
            for i, j in enumerate(horz_scan):
                plt.plot(i, j, '.', markersize=10, color='black')
            plt.plot(x_new1, y_new1, '.', markersize=14, color='green')
            plt.plot(x_new2, y_new2, '.', markersize=14, color='green')
            plt.plot(x_new3, y_new3, '.', markersize=14, color='red')
            plt.show()
    except:
#        print("fail")
        x_new3 = 0
        x_new1 = 0
        x_new2 = 0
        found = False
    return int(x_new3), int(x_new1), int(x_new2), found


def moving_average(a, n):
    helper = a
    helper = np.append(helper, a[0:n])
    helper = np.insert(helper, 0, a[-n:])
    output = []
    for i, xi in enumerate(a):
        index = i + n
        output.append(round(np.sum(helper[index - n:index + n + 1]) / (2 * n + 1)))
    return output

def find_points(point1, point2, img_mask, ratio):
    x = [point1[1], point2[1]]
    y = [point1[0], point2[0]]
    dx = (x[0] - x[1])
    dy = (y[0] - y[1])
    distance = (dx ** 2 + dy ** 2) ** 0.5
    radial = distance / ratio
    if dx == 0:
        point3_x = round(point2[1])
        point3_y = round(point2[0] + radial)
        point4_x = round(point2[1])
        point4_y = round(point2[0] - radial)
    else:
        angle = math.atan(dy / dx)
        point3_x = round(x[1] + radial * math.cos(angle))
        point3_y = round(y[1] + radial * math.sin(angle))
        point4_x = round(x[1] - radial * math.cos(angle))
        point4_y = round(y[1] - radial * math.sin(angle))
    point3_x = min(point3_x, len(img_mask) - 1)
    point3_y = min(point3_y, len(img_mask[0]) - 1)
    point4_x = min(point4_x, len(img_mask) - 1)
    point4_y = min(point4_y, len(img_mask[0]) - 1)

    return point3_x, point3_y, point4_x, point4_y

def fine_process(img_mask, img_original, ratio, contours, centroids, thres, type_img, radius_to_measure, times):
    #cv2.cvtColor(img_original, cv2.COLOR_RGB2GRAY)
    img_original_gray = img_original#cv2.cvtColor(img_original, cv2.COLOR_RGB2GRAY).astype(int)
    img_original = cv2.cvtColor(img_original, cv2.COLOR_GRAY2RGB)
    # plt.figure()
    # plt.imshow(img_original, cmap='gray')
    # plt.show()
    final_perimeter_points = []
    uncertainties = []
    for i, c in enumerate(centroids):
        perimeter_points = []
        processed_points_x = []
        processed_points_y = []
        point1 = c
        cont = contours[i]
        # if i==13:
        for j, cont1 in enumerate(cont):
            # if j==5:
            point2 = cont1[0]
            point3_x, point3_y, point4_x, point4_y = find_points(point1, point2, img_mask, ratio)
#            print(point3_x, point3_y, point4_x, point4_y)
            rr, cc = line(int(point3_x), int(point3_y), int(point4_x), int(point4_y))
            distance_0 = ((point1[1] - rr[0]) ** 2 + (point1[0] - cc[0]) ** 2) ** 0.5
            distance_end = ((point1[1] - rr[-1]) ** 2 + (point1[0] - cc[-1]) ** 2) ** 0.5
            if radius_to_measure=="exterior" and type_img == 1:
                rr = rr[::-1]
                cc = cc[::-1]
                if distance_0 > distance_end:
                    rr = rr[::-1]
                    cc = cc[::-1]
            else:
                rr = rr[::-1]
                cc = cc[::-1]
                if distance_0 < distance_end:
                    rr = rr[::-1]
                    cc = cc[::-1]
            # img_original[point1[1],point1[0]]=[255, 0, 0]
            # img_original[point2[1],point2[0]]=[0, 255, 0]
            gray_level = img_original_gray[rr, cc]
            if type_img == 1 and radius_to_measure=="interior":
                x1v, x_limit1, x_limit2, found = find_limit(-gray_level, thres, type_img, radius_to_measure, point1, point2, times)
            elif type_img == 1 and radius_to_measure=="exterior":
                x1v, x_limit1, x_limit2, found = find_limit(gray_level, thres, type_img, radius_to_measure, point1, point2, times)
            elif type_img == 0:
                x1v, x_limit1, x_limit2, found = find_limit(gray_level, thres, type_img, radius_to_measure, point1, point2, times)
            # img_original[point3_x,point3_y]=[255, 255, 0]
            # img_original[point4_x,point4_y]=[255, 255, 0]
            if found == True:
                processed_points_x.append(rr[x1v])
                processed_points_y.append(cc[x1v])
                # img_original[rr[x1v], cc[x1v]] = [0, 0, 255]
                uncertainties.append(np.sqrt((rr[x_limit1]-rr[x_limit2])**2+(cc[x_limit1]-cc[x_limit2])**2))
#            radius = 25
#            plt.figure(figsize=(10, 10))
#            plt.imshow(img_original[c[1]-radius:c[1]+radius, c[0]-radius:c[0]+radius])
#            plt.show()
#            break
        processed_points_x = moving_average(processed_points_x, 11)
        processed_points_y = moving_average(processed_points_y, 11)
        processed_points_x= [int(s) for s in processed_points_x]
        processed_points_y = [int(s) for s in processed_points_y]
#        print(processed_points_x)
        img_original[processed_points_x, processed_points_y] = [255, 0, 0]
        for pi, pj in enumerate(processed_points_x):
            for ki, kj in enumerate(processed_points_x):
                if pj == kj and pi != ki and pj!=0 and kj!=0:
                    rr, cc = line(pj, processed_points_y[pi], kj, processed_points_y[ki])
                    img_original[rr, cc] = [255, 0, 0]
                    break
        for pi, pj in enumerate(processed_points_y):
            for ki, kj in enumerate(processed_points_y):
                if pj == kj and pi != ki and pj!=0 and kj!=0:
                    rr, cc = line(processed_points_x[pi], pj, processed_points_x[ki], kj)
                    img_original[rr, cc] = [255, 0, 0]
                    break
        for point_num, point in enumerate(processed_points_x):
            perimeter_points.append([[processed_points_y[point_num], processed_points_x[point_num]]])

        final_perimeter_points.append(np.array(perimeter_points))
        # else:
        #     perimeter_points.append([[0, 0]])
        #     final_perimeter_points.append(np.array(perimeter_points))
    # to see result in binary
    # plt.figure()
    # plt.imshow(img_original, cmap='gray')
    # plt.show()
    img_original[np.all(img_original != (255, 0, 0), axis=-1)] = (0,0,0)
    # img_original[np.all(img_original == (0, 255, 0), axis=-1)] = (0,0,0)
    img_original[np.all(img_original == (255, 255, 255), axis=-1)] = (0,0,0)
    img_original[np.all(img_original == (255, 0, 0), axis=-1)] = (255,255,255)
    img_original = cv2.cvtColor(img_original,cv2.COLOR_BGR2GRAY)
    img_original= fill_enclosed_holes(img_original)
    # img_original = cv2.cvtColor(img_original,cv2.COLOR_GRAY2BGR)
    return final_perimeter_points, img_original, uncertainties

def main_fine(img_original, img_mask, extra_output, pixel_size, params):
    planar_type = 1
    img_binary_mask = img_mask#cv2.threshold(cv2.cvtColor(img_mask, cv2.COLOR_RGB2GRAY), int(0.5 * 255), 255, cv2.THRESH_BINARY)[1]
    radius_to_measure = params['configuration_parameters']["radius_to_measure"]
    ratio = params['configuration_parameters']["radius_division_ratio"]
    thres = params['configuration_parameters']["linear_approximation_factor"]
    if planar_type == 0:
        img_original = cv2.medianBlur(img_original, 3)
        temp_contours, hier = cv2.findContours(img_binary_mask, cv2.RETR_LIST, cv2.CHAIN_APPROX_NONE)
    elif planar_type==1:
        img_original2 = cv2.medianBlur(img_original, 3)
        img_original = cv2.medianBlur(img_original, 11)
        temp_contours, hier = cv2.findContours(img_binary_mask, cv2.RETR_LIST, cv2.CHAIN_APPROX_NONE)
    contours = []
    for i, cnt in enumerate(temp_contours):
        if len(temp_contours)>0:
            cv2.drawContours(img_binary_mask, [cnt], -1, color=(255, 255, 255), thickness=cv2.FILLED)
            contours.append(cnt)
    centroids, contours = find_centroids(img_binary_mask, contours)
    times = 1
    perimeter_points, image, uncertainties = fine_process(img_mask, img_original, ratio, contours, centroids, thres, planar_type,
                                           radius_to_measure, times)
    if planar_type==1:
        ratio = ratio*2
        times = 2
        perimeter_points, image, uncertainties = fine_process(img_mask, img_original2, ratio, perimeter_points, centroids, thres,
                                               planar_type, radius_to_measure, times)
        # image = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
        image, hull = complete_circles(image)
    else:
        # image = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
        image, hull = complete_circles(image)
    # image = cv2.cvtColor(image, cv2.COLOR_GRAY2BGR)
    # print("Final graph")
    # plt.figure()
    # plt.imshow(image, cmap='gray')
    # plt.show()
    final_centroids, contours = find_centroids(image, contours)
    # # for i in final_centroids:
    # #     cv2.circle(image, (i[0], i[1]), radius=5, color=(0, 0, 255), thickness=-1)
    # # for i in extra_output["initial_centroids"]:
    # #     cv2.circle(image, (i[0], i[1]), radius=5, color=(255, 0, 0), thickness=-1)
    extra_output["final_centroids"] = final_centroids
    extra_output["uncertainty"] = pixel_size * np.mean(uncertainties)

    return image, extra_output