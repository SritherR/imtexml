import copy
import numpy as np, pandas as pd
import cv2, math
from PIL import Image
from skimage.measure import label, regionprops, regionprops_table  # , profile_line
from skimage.draw import line
from scipy import ndimage as ndi, spatial
import matplotlib.pyplot as plt
import traceback
import pickle


# bounding box/polygon roi? - yes, but will already be cropped coming out of the UI, so no worries
def elements(array):
    return array.ndim and array.size


def profile_line(image, start_coords, end_coords, *,
                 spacing=1, order=1, endpoint=True):
    coords = []
    n_points = int(np.ceil(spatial.distance.euclidean(start_coords, end_coords)
                           / spacing))
    for s, e in zip(start_coords, end_coords):
        coords.append(np.linspace(s, e, n_points, endpoint=endpoint))
    profile = ndi.map_coordinates(image, coords, order=order)
    return coords, profile


def compute_circle_width(centroid, r, theta, img, x_offset, y_offset):
    """ centroid: [x,y] center of circle
        r: radius over which to measure circle
        theta: angle in radians to measure circle diameter
        img: [mxn] image from which to take intensity values for diameter

        return
            w: width of circle along theta angle
            pos: [x1,y1,x2,y2] endpoints of width bar"""

    xi = np.round([centroid[0] - r * np.cos(theta), centroid[0] + r * np.cos(theta)]).astype(int)
    yi = np.round([centroid[1] - r * np.sin(theta), centroid[1] + r * np.sin(theta)]).astype(int)

    # Extract intensity values along some profile line
    # Extract intensity values along some profile line
    # xx, yy = line(xi[0], yi[0], xi[1], yi[1])
    # p = img[yy, xx].astype(int)
    #
    # ep1_idx = np.argmax(p == 1)
    # ep1 = np.array((xx[ep1_idx], yy[ep1_idx]))
    # ep2_idx = len(p) - np.argmax(np.flip(p) == 1)
    # ep2 = np.array((xx[ep2_idx], yy[ep2_idx]))

    (rr, cc), p = profile_line(img, (yi[0], xi[0]), (yi[1], xi[1]))  # x,y are flipped in image coordinates
    foreground_ind = np.where(p > 0)
    ep1_ind = foreground_ind[0][0]
    ep2_ind = foreground_ind[0][-1]

    ep1_x = cc[ep1_ind]
    ep1_y = rr[ep1_ind]
    ep2_x = cc[ep2_ind]
    ep2_y = rr[ep2_ind]

    width = np.linalg.norm(np.array([ep2_x, ep2_y]) - np.array([ep1_x, ep1_y]))

    return width, [ep1_x + x_offset, ep1_y + y_offset, ep2_x + x_offset, ep2_y + y_offset]


def remove_holes(img, ignore_points):
    contours, hierarchy = cv2.findContours(img, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_NONE)
    #    ignore_points = [ignore_points]
    ignore_areas = []
    #    print(ignore_points)
    if len(ignore_points[0]) != 0:
        for point in ignore_points:
            for idx, contour in enumerate(contours):
                result = cv2.pointPolygonTest(contour, (point[0], point[1]), False)
                if result == 1 or result == 0:
                    cv2.drawContours(img, contours, idx, (0, 0, 0), -1)
                    x, y, w, h = cv2.boundingRect(contours[idx])
                    ignore_areas.append([x - 5, y - 5, x + w + 5, y + h + 5])
                    break
    return img, ignore_areas


# signature should be measure(img, pixel_size, params)
# bounding box is in params as
def measure(img, pixel_size, params):
    print(params)
    # with open('/dat/proj/AIM/Yannis/saved_dictionary.pkl', 'wb') as f:
    #     pickle.dump(params, f)

    img_org = copy.deepcopy(img)
    # plt.figure()
    # plt.imshow(img_org, cmap='gray')
    # plt.title('Before Remove Holes')
    # plt.show()

    if ('bounding_box' not in params) and ('polygon_bounding_box' not in params):
        return -1, -1, -1, (500, "Measurement failed.")

    if 'bounding_box' in params:

        cropbox_x1 = params['bounding_box'][0][0]
        cropbox_y1 = params['bounding_box'][0][1]

        x1, y1, x2, y2 = params['bounding_box'][0]
        img = img[y1:y2, x1:x2]
    else:
        # polygon bounding box: keep original image uncropped and later exclude holes from binarization which are outside bounds
        cropbox_x1 = 0
        cropbox_y1 = 0

        # create a mask of the polygon
        # do an & with the input image to get rid of all holes outside the mask
        xs = params['polygon_bounding_box'][::2]
        ys = params['polygon_bounding_box'][1::2]

        polypoints = np.array((xs, ys)).T

        print(polypoints)

        mask = np.zeros(img.shape[:2], dtype='uint8')  # black image the shape of original image

        # plt.figure()
        # plt.imshow(mask, cmap='gray')
        # plt.title('Mask')
        # plt.show()

        # add white polygon to make mask
        cv2.drawContours(mask, [polypoints], 0, 255, -1)
        cv2.drawContours(mask, [polypoints], 0, 255, 2)

        # keep only segmented holes under polygon mask (mask is white and original img was white)
        img = img & mask

    # plt.figure()
    # plt.imshow(img, cmap='gray')
    # plt.title('Before Remove Holes')
    # plt.show()
    #
    # remove ignore_points from mask
    # remove holes given the 'mask feature' tool from UI
    final_ignore_points = [[]]
    if 'ignore_points' in params:
        ignore_points = params['ignore_points']
        final_ignore_points = []
        if len(ignore_points[0]) != 0:
            for i, ignore_point in enumerate(ignore_points):
                if ignore_point[0] - x1 > 0 and ignore_point[1] - y1 > 0 and x2 - ignore_point[0] > 0 and y2 - \
                        ignore_point[1] > 0:
                    ign_x = ignore_point[0] - x1
                    ign_y = ignore_point[1] - y1
                    final_ignore_points.append([ign_x, ign_y])
        if len(final_ignore_points) == 0:
            final_ignore_points = [[]]
    try:
        img_with_ignore_holes = copy.deepcopy(img)
        # plt.figure()
        # plt.imshow(img_with_ignore_holes, cmap='gray')
        # plt.title('Before Remove Holes')
        # plt.show()
        img, ignore_areas = remove_holes(img, final_ignore_points)
    except Exception:
        traceback.print_exc()
        return -1, -1, -1, (500, "Failure masking points from measurement.")

    # process config
    config = params["configuration_parameters"]
    try:
        nAngles = config['n_diameters']
        area_dev_fact = config['area_deviation_factor']
        circ_dev_fact = config['circularity_deviation_factor']
    except KeyError:
        missing = ""
        if 'n_diameters' not in config:
            missing += "n_diameters; "
        if 'area_deviation_factor' not in config:
            missing += 'area_deviation_factor; '
        if 'circularity_deviation_factor' not in config:
            missing += 'circularity_deviation_factor'
        return -1, -1, -1, (400, "Missing required configuration parameter(s):{}".format(missing))

    # plt.figure()
    # plt.imshow(img, cmap='gray')
    # plt.title('After Remove Holes')
    # plt.show()

    # msmts = [{"Name":"xxx", "Value":?}]
    # ss = [{"Name:"xxx","Value":x,"Summarized_Measurement":"xxx"}]
    # linemarkings = [{"Measurement":"xxx", "Linemarkings":[
    #   {"Points":[x1,y1,...], "Color":"xxx", "Adjustable":0, "Annotation":""},...] }]
    msmts = []
    linemarkings = []  # (x1,y1,x2,y2)
    ss = []
    try:
        print()
        print("Beginning measurement - identifying image regions")
        print()
        label_img = label(img)  # skimage label function discretizes image for regionprops_table

        regions = regionprops_table(label_img, properties=('area', 'major_axis_length',
                                                           'minor_axis_length', 'perimeter',
                                                           'centroid', 'eccentricity', 'bbox'))

        region_data = pd.DataFrame(regions)

        label_img_with_ignore_holes = label(img_with_ignore_holes)
        # plt.figure()
        # plt.imshow(label_img_with_ignore_holes)
        # plt.show()
        regions_with_ignore_holes = regionprops_table(label_img_with_ignore_holes,
                                                      properties=('area', 'major_axis_length',
                                                                  'minor_axis_length', 'perimeter',
                                                                  'centroid', 'eccentricity', 'bbox'))
        region_data_with_ignore_holes = pd.DataFrame(regions_with_ignore_holes)

        region_data['circularity'] = region_data['perimeter'] ** 2 / (4 * (region_data['area'] * math.pi))

        # Define min area as mean - 2*std and max are as mean + 2*std -- OR Have kwargs input for parameters hardcoded above
        # -- for each case (as in gmm preprocess) set the proper values

        # std is frequently greater than the mean because of noise - lots of small noise relative to holes - but how to decide a threshold?
        Min_area = region_data["area"].mean() - area_dev_fact * (region_data["area"].std())
        Max_area = region_data["area"].mean() + area_dev_fact * (region_data["area"].std())
        Min_circularity = region_data["circularity"].mean() - circ_dev_fact * (region_data["circularity"].std())
        Max_circularity = region_data["circularity"].mean() + circ_dev_fact * (region_data["circularity"].std())

        print("Calculated min, max area and circularity:")
        print(Min_area)
        print(Max_area)
        print(Min_circularity)
        print(Max_circularity)

        # throw away holes with improper area
        keep_holes1 = (region_data['area'] > Min_area) & (region_data['area'] < Max_area) & (
                region_data['circularity'] > Min_circularity) & (region_data['circularity'] < Max_circularity)

        # if any bbox points are touching the boundary, toss out
        # bbox-0, bbox-2 are row, bbox-1, bbox-3 = col
        keep_holes2 = (region_data["bbox-0"] > 0) & (region_data["bbox-1"] > 0) & (
                    region_data["bbox-2"] < label_img.shape[0]) & (region_data["bbox-3"] < label_img.shape[1])

        keep_holes = keep_holes1 & keep_holes2
        region_data_org = copy.deepcopy(region_data)
        region_data = region_data[keep_holes]

        region_data_ignore = region_data_org[~keep_holes]
        # print(region_data_ignore.filter(regex= "bbox"))
        if not region_data_ignore.empty:
            for rectangle in range(0, region_data_ignore.filter(regex="bbox").shape[0]):
                ignore_areas.append([region_data_ignore.filter(regex="bbox").iloc[rectangle, 0] - 5, \
                                     region_data_ignore.filter(regex="bbox").iloc[rectangle, 1] - 5, \
                                     region_data_ignore.filter(regex="bbox").iloc[rectangle, 2] + 5, \
                                     region_data_ignore.filter(regex="bbox").iloc[rectangle, 3] + 5])

        # # remove holes given the 'mask feature' tool from UI
        # if 'ignore_points' in params:
        #     ignore_points = params['ignore_points']
        #     if len(ignore_points[0])!=0:
        #         for ip_x, ip_y in ignore_points:
        #             ip_x = ip_x - cropbox_x1
        #             ip_y = ip_y - cropbox_y1
        #
        #             keep_holes = keep_holes & ~(((region_data["bbox-0"] < ip_y) & (region_data["bbox-2"] > ip_y)) & ((region_data["bbox-1"] < ip_x) & (region_data["bbox-3"] > ip_x)))

        #        print()
        #        print("REGION DATA HEAD:")
        #        print(region_data.head())
        #        print()

        if region_data.empty:
            return -1, -1, -1, (500, "No holes detected.")

        # Store measurements from region props
        msmts.append(
            {"Name": "Major Axis Length", "Value": (np.array(region_data['major_axis_length']) * pixel_size).round(5)})
        ss.append(
            {"Name": "Average Major Axis", "Value": round(region_data['major_axis_length'].mean() * pixel_size, 5),
             "Summarized_Measurement": "Major Axis Length"})

        msmts.append(
            {"Name": "Minor Axis Length", "Value": (np.array(region_data['minor_axis_length']) * pixel_size).round(5)})
        ss.append(
            {"Name": "Average Minor Axis", "Value": round(region_data['minor_axis_length'].mean() * pixel_size, 5),
             "Summarized_Measurement": "Minor Axis Length"})

        msmts.append({"Name": "Circularity", "Value": (np.array(region_data['circularity'])).round(5)})
        ss.append({"Name": "Average Circularity", "Value": round(region_data['circularity'].mean(), 5),
                   "Summarized_Measurement": "Circularity"})

        msmts.append({"Name": "Area", "Value": (np.array(region_data['area']) * pixel_size).round(5)})
        ss.append({"Name": "Average Area", "Value": round(region_data['area'].mean() * pixel_size, 5),
                   "Summarized_Measurement": "Area"})

        ss.append({"Name": "Average Major to Minor Axis Ratio",
                   "Value": round((region_data['major_axis_length'] / region_data['minor_axis_length']).mean(), 5),
                   "Summarized_Measurement": ["Major Axis Length", "Minor Axis Length"]})

        ss.append({"Name": "Average Eccentricity", "Value": round(region_data['eccentricity'].mean(), 5),
                   "Summarized_Measurement": None})

        # Between-hole distances
        # sort bounding boxes according to column 2 = y position of origin of bb
        bb_data = region_data.filter(regex='bbox')
        bb_data_with_ignore_holes = region_data_with_ignore_holes.filter(regex='bbox')
        BR_sorted = bb_data.sort_values(by="bbox-0",
                                        ignore_index=True)  # sort by the starting column of the bounding box
        BR_sorted_with_ignore_holes = bb_data_with_ignore_holes.sort_values(by="bbox-0", ignore_index=True)

        # holes
        hole_columns = BR_sorted["bbox-0"]
        diffcol = np.array(hole_columns[1:]) - np.array(hole_columns[0:-1])
        risingedge = np.where(diffcol > 30)
        indx = np.unique(risingedge)
        # each value in indx marks the start of a new column. Since its sorted in order of bbox1 already, go through the rows
        # and just split at these indx
        # what if there's just one row of holes? put all of them in one group
        if len(indx) == 0:
            BR_sorted_rowwise = [BR_sorted.sort_values(by="bbox-1")]
        else:
            BR_sorted_rowwise = []

            for i in range(len(indx)):
                if i == 0:
                    BR_sorted_rowwise.append(BR_sorted.iloc[i:indx[i] + 1].sort_values(by="bbox-1"))
                else:
                    BR_sorted_rowwise.append(BR_sorted.iloc[indx[i - 1] + 1:indx[i] + 1].sort_values(by="bbox-1"))

            BR_sorted_rowwise.append(BR_sorted.iloc[indx[i] + 1:].sort_values(by="bbox-1"))

        # holes + ignore_holes
        hole_columns = BR_sorted_with_ignore_holes["bbox-0"]
        diffcol = np.array(hole_columns[1:]) - np.array(hole_columns[0:-1])
        risingedge = np.where(diffcol > 30)
        indx = np.unique(risingedge)
        # each value in indx marks the start of a new column. Since its sorted in order of bbox1 already, go through the rows
        # and just split at these indx
        # what if there's just one row of holes? put all of them in one group
        if len(indx) == 0:
            BR_sorted_rowwise_with_ignore_holes = [BR_sorted_with_ignore_holes.sort_values(by="bbox-1")]
        else:
            BR_sorted_rowwise_with_ignore_holes = []

            for i in range(len(indx)):
                if i == 0:
                    BR_sorted_rowwise_with_ignore_holes.append(
                        BR_sorted_with_ignore_holes.iloc[i:indx[i] + 1].sort_values(by="bbox-1"))
                else:
                    BR_sorted_rowwise_with_ignore_holes.append(
                        BR_sorted_with_ignore_holes.iloc[indx[i - 1] + 1:indx[i] + 1].sort_values(by="bbox-1"))

            BR_sorted_rowwise_with_ignore_holes.append(
                BR_sorted_with_ignore_holes.iloc[indx[i] + 1:].sort_values(by="bbox-1"))

        # Horizontal distances

        dist_bar = []
        points_x1_bar = []
        points_x2_bar = []
        points_y_bar = []

        dist_nit = []
        points_x1_nit = []
        points_x2_nit = []
        points_y_nit = []

        def rectangle_test(contour, point):
            if contour[0] <= point[0] and contour[2] >= point[0] \
                    and contour[1] <= point[1] and contour[3] >= point[1]:
                return 1  # point is inside rectangle
            else:
                return 0

        def ignore_point_function(ignore_areas, point1, point2):
            # check if it should be ignored
            passed_ignore_areas = True
            for contour in ignore_areas:
                result1 = rectangle_test(contour, point1)
                result2 = rectangle_test(contour, point2)
                if (result1 != 0) or (result2 != 0):
                    passed_ignore_areas = False
                    break
            return passed_ignore_areas

        for group in BR_sorted_rowwise_with_ignore_holes:
            d = len(group)  # number of holes in this row
            if d > 1:
                # between-hole dist is hole1's c2 -> hole2's c1
                for i in range(1, d):
                    # find horizontal nit
                    x1_nit = group.iloc[i - 1]["bbox-3"] + cropbox_x1
                    x2_nit = group.iloc[i]["bbox-1"] + cropbox_x1
                    y_nit = np.round((group.iloc[i]["bbox-2"] + group.iloc[i]["bbox-0"]) / 2) + cropbox_y1

                    # check if it should be ignored
                    point1 = [x1_nit, y_nit]
                    point2 = [x2_nit, y_nit]
                    passed_ignore_areas = ignore_point_function(ignore_areas, point1, point2)
                    if passed_ignore_areas == True:
                        dist_nit.append(x2_nit - x1_nit)
                        points_x1_nit.append(x1_nit)
                        points_x2_nit.append(x2_nit)
                        points_y_nit.append(y_nit)

                    # find horizontal bar
                    x1_bar = (group.iloc[i - 1]["bbox-3"] - group.iloc[i - 1]["bbox-1"]) / 2 + group.iloc[i - 1][
                        "bbox-1"] + cropbox_x1
                    x2_bar = (group.iloc[i]["bbox-3"] - group.iloc[i]["bbox-1"]) / 2 + group.iloc[i][
                        "bbox-1"] + cropbox_x1
                    y_bar = np.round((group.iloc[i]["bbox-2"] + group.iloc[i]["bbox-0"]) / 2) + cropbox_y1

                    # check if it should be ignored
                    point1 = [x1_bar, y_bar]
                    point2 = [x2_bar, y_bar]
                    passed_ignore_areas = ignore_point_function(ignore_areas, point1, point2)
                    # if passed_ignore_areas==False:
                    #     print("here")
                    if passed_ignore_areas == True:
                        dist_bar.append(x2_bar - x1_bar)
                        points_x1_bar.append(x1_bar)
                        points_x2_bar.append(x2_bar)
                        points_y_bar.append(y_bar)

        # Horizontal Center to Center
        lm_bar = []
        if len(points_x1_bar) > 0:
            for i in range(len(points_x1_bar)):
                lm_bar.append({"Points": [points_x1_bar[i], points_y_bar[i], points_x2_bar[i], points_y_bar[i]],
                               "Color": "blue", "Adjustable": 1, "Annotation": ""})
        linemarkings.append({"Measurement": "Between Hole Center to Center Distance", "Linemarkings": lm_bar})
        msmts.append(
            {"Name": "Between Hole Center to Center Distance", "Value": (np.array(dist_bar) * pixel_size).round(5)})
        ss.append(
            {"Name": "Average Between Hole Center to Center Dist", "Value": round(np.mean(dist_bar) * pixel_size, 5),
             "Summarized_Measurement": "Between Hole Center to Center Distance"})
        ss.append({"Name": "LCDU Center to Center CD", "Value": round(3 * (np.std(dist_bar)) * pixel_size, 5),
                   "Summarized_Measurement": "Between Hole Center to Center Distance"})

        # Horizontal Edge to Edge
        lm_nit = []
        if len(points_x1_nit) > 0:
            for i in range(len(points_x1_nit)):
                lm_nit.append({"Points": [points_x1_nit[i], points_y_nit[i], points_x2_nit[i], points_y_nit[i]],
                               "Color": "red", "Adjustable": 1, "Annotation": ""})
        linemarkings.append({"Measurement": "Between Hole Edge to Edge Distance", "Linemarkings": lm_nit})
        msmts.append(
            {"Name": "Between Hole Edge to Edge Distance", "Value": (np.array(dist_nit) * pixel_size).round(5)})
        ss.append({"Name": "Average Between Hole Edge to Edge Dist", "Value": round(np.mean(dist_nit) * pixel_size, 5),
                   "Summarized_Measurement": "Between Hole Edge to Edge Distance"})
        ss.append({"Name": "LCDU Edge to Edge CD", "Value": round(3 * (np.std(dist_nit)) * pixel_size, 5),
                   "Summarized_Measurement": "Between Hole Edge to Edge Distance"})

        # Angular distances

        dist_bar_diag = []
        points_x1_bar_diag = []
        points_x2_bar_diag = []
        points_y1_bar_diag = []
        points_y2_bar_diag = []

        dist_nit_diag = []
        points_x1_nit_diag = []
        points_x2_nit_diag = []
        points_y1_nit_diag = []
        points_y2_nit_diag = []

        total_number_of_contours = 0
        connected_indices = []
        for group_num, group in enumerate(BR_sorted_rowwise_with_ignore_holes):
            d = len(group)  # number of holes in this row
            if d > 1 and len(BR_sorted_rowwise_with_ignore_holes) > 1 and group_num != len(
                    BR_sorted_rowwise_with_ignore_holes) - 1:
                group_below = BR_sorted_rowwise_with_ignore_holes[group_num + 1]
                # between-hole dist is hole1's c2 -> hole2's c1
                for i in range(0, d):
                    # find horizontal bar
                    x1_bar_diag = np.round((group.iloc[i]["bbox-1"] + group.iloc[i]["bbox-3"]) / 2) + cropbox_x1
                    y1_bar_diag = np.round((group.iloc[i]["bbox-2"] + group.iloc[i]["bbox-0"]) / 2) + cropbox_y1
                    for j in range(0, len(group_below) - 1):
                        x21_bar_diag = np.round(
                            (group_below.iloc[j]["bbox-1"] + group_below.iloc[j]["bbox-3"]) / 2) + cropbox_x1
                        x22_bar_diag = np.round(
                            (group_below.iloc[j + 1]["bbox-1"] + group_below.iloc[j + 1]["bbox-3"]) / 2) + cropbox_x1
                        # check if the below contours are within the neighboring contours of the current row
                        below_contours_checked = True
                        i_left = i - 1
                        if i_left >= 0:
                            x10_bar_diag = np.round(
                                (group.iloc[i_left]["bbox-1"] + group.iloc[i_left]["bbox-3"]) / 2) + cropbox_x1
                            if x10_bar_diag > x21_bar_diag:
                                below_contours_checked = False
                        i_right = i + 1
                        if i_right <= d - 1:
                            x12_bar_diag = np.round(
                                (group.iloc[i_right]["bbox-1"] + group.iloc[i_right]["bbox-3"]) / 2) + cropbox_x1
                            if x12_bar_diag < x22_bar_diag:
                                below_contours_checked = False
                        #
                        if x1_bar_diag > x21_bar_diag and x1_bar_diag < x22_bar_diag and below_contours_checked == True:
                            y21_bar_diag = np.round(
                                (group_below.iloc[j]["bbox-2"] + group_below.iloc[j]["bbox-0"]) / 2) + cropbox_y1
                            y22_bar_diag = np.round((group_below.iloc[j + 1]["bbox-2"] + group_below.iloc[j + 1][
                                "bbox-0"]) / 2) + cropbox_y1

                            # check if it should be ignored
                            point1 = [x1_bar_diag, y1_bar_diag]
                            point2 = [x21_bar_diag, y21_bar_diag]
                            passed_ignore_areas = ignore_point_function(ignore_areas, point1, point2)
                            if passed_ignore_areas == True:
                                dist_bar_diag.append(
                                    np.sqrt((x21_bar_diag - x1_bar_diag) ** 2 + (y1_bar_diag - y21_bar_diag) ** 2))
                                points_x1_bar_diag.append(x1_bar_diag)
                                points_x2_bar_diag.append(x21_bar_diag)
                                points_y1_bar_diag.append(y1_bar_diag)
                                points_y2_bar_diag.append(y21_bar_diag)

                            # check if it should be ignored
                            point1 = [x1_bar_diag, y1_bar_diag]
                            point2 = [x22_bar_diag, y22_bar_diag]
                            passed_ignore_areas = ignore_point_function(ignore_areas, point1, point2)
                            if passed_ignore_areas == True:
                                dist_bar_diag.append(
                                    np.sqrt((x22_bar_diag - x1_bar_diag) ** 2 + (y1_bar_diag - y22_bar_diag) ** 2))
                                points_x1_bar_diag.append(x1_bar_diag)
                                points_x2_bar_diag.append(x22_bar_diag)
                                points_y1_bar_diag.append(y1_bar_diag)
                                points_y2_bar_diag.append(y22_bar_diag)

                            # calculate nit points
                            # down left
                            rr, cc = line(int(x1_bar_diag), int(y1_bar_diag), int(x21_bar_diag), int(y21_bar_diag))
                            zeros_positions = np.argwhere(img_org[cc, rr] == 0)
                            if len(zeros_positions) >= 2:
                                start = zeros_positions[0]
                                end = zeros_positions[-1]
                                x1_nit_diag = rr[start]
                                x2_nit_diag = rr[end]
                                y1_nit_diag = cc[start]
                                y2_nit_diag = cc[end]
                                # check if it should be ignored
                                point1 = [x1_nit_diag, y1_nit_diag]
                                point2 = [x2_nit_diag, y2_nit_diag]
                                passed_ignore_areas = ignore_point_function(ignore_areas, point1, point2)
                                if passed_ignore_areas == True:
                                    dist_nit_diag.append(
                                        np.sqrt((x1_nit_diag - x2_nit_diag) ** 2 + (y1_nit_diag - y2_nit_diag) ** 2))
                                    points_x1_nit_diag.append(x1_nit_diag)
                                    points_x2_nit_diag.append(x2_nit_diag)
                                    points_y1_nit_diag.append(y1_nit_diag)
                                    points_y2_nit_diag.append(y2_nit_diag)
                            # down right
                            rr, cc = line(int(x1_bar_diag), int(y1_bar_diag), int(x22_bar_diag), int(y22_bar_diag))
                            zeros_positions = np.argwhere(img_org[cc, rr] == 0)
                            if len(zeros_positions) >= 2:
                                start = zeros_positions[0]
                                end = zeros_positions[-1]
                                x1_nit_diag = rr[start]
                                x2_nit_diag = rr[end]
                                y1_nit_diag = cc[start]
                                y2_nit_diag = cc[end]
                                # check if it should be ignored
                                point1 = [x1_nit_diag, y1_nit_diag]
                                point2 = [x2_nit_diag, y2_nit_diag]
                                passed_ignore_areas = ignore_point_function(ignore_areas, point1, point2)
                                if passed_ignore_areas == True:
                                    dist_nit_diag.append(
                                        np.sqrt((x1_nit_diag - x2_nit_diag) ** 2 + (y1_nit_diag - y2_nit_diag) ** 2))
                                    points_x1_nit_diag.append(x1_nit_diag)
                                    points_x2_nit_diag.append(x2_nit_diag)
                                    points_y1_nit_diag.append(y1_nit_diag)
                                    points_y2_nit_diag.append(y2_nit_diag)
                            connected_indices.append([i + total_number_of_contours, total_number_of_contours + d + j])
                            connected_indices.append(
                                [i + total_number_of_contours, total_number_of_contours + d + j + 1])
                            break
            total_number_of_contours += d

        # Inverse rows of contours and repeat this time from bottom to top to connect those that still remain
        BR_sorted_rowwise_inverse = []
        for group_num, group in enumerate(BR_sorted_rowwise_with_ignore_holes):
            BR_sorted_rowwise_inverse.insert(0, group.iloc[::-1])
        current_contour_num = 0
        total_d = 0
        for group_num, group in reversed(list(enumerate(BR_sorted_rowwise_inverse))):
            d = len(group)  # number of holes in this row
            if d > 1 and len(BR_sorted_rowwise_inverse) > 1 and group_num != len(BR_sorted_rowwise_inverse) - 1:
                group_below = BR_sorted_rowwise_inverse[group_num + 1]
                # between-hole dist is hole1's c2 -> hole2's c1
                for i in range(0, d):
                    x1_bar_diag = np.round((group.iloc[i]["bbox-1"] + group.iloc[i]["bbox-3"]) / 2) + cropbox_x1
                    y1_bar_diag = np.round((group.iloc[i]["bbox-2"] + group.iloc[i]["bbox-0"]) / 2) + cropbox_y1
                    for j in range(0, len(group_below) - 1):

                        if ([(total_number_of_contours - (current_contour_num + i)),
                             total_d + (d - j)] not in connected_indices) and \
                                ([total_d + (d - j),
                                  (total_number_of_contours - (current_contour_num + i))] not in connected_indices):

                            x21_bar_diag = np.round((group_below.iloc[j]["bbox-1"] + group_below.iloc[j][
                                "bbox-3"]) / 2) + cropbox_x1
                            x22_bar_diag = np.round((group_below.iloc[j + 1]["bbox-1"] + group_below.iloc[j + 1][
                                "bbox-3"]) / 2) + cropbox_x1
                            # check if the below contours are within the neighboring contours of the current row
                            below_contours_checked = True
                            i_left = i - 1
                            if i_left >= 0:
                                x10_bar_diag = np.round(
                                    (group.iloc[i_left]["bbox-1"] + group.iloc[i_left]["bbox-3"]) / 2) + cropbox_x1
                                if x10_bar_diag < x21_bar_diag:
                                    below_contours_checked = False
                            i_right = i + 1
                            if i_right <= d - 1:
                                x12_bar_diag = np.round(
                                    (group.iloc[i_right]["bbox-1"] + group.iloc[i_right]["bbox-3"]) / 2) + cropbox_x1
                                if x12_bar_diag > x22_bar_diag:
                                    below_contours_checked = False
                            #
                            if x1_bar_diag < x21_bar_diag and x1_bar_diag > x22_bar_diag:
                                y21_bar_diag = np.round((group_below.iloc[j]["bbox-2"] + group_below.iloc[j][
                                    "bbox-0"]) / 2) + cropbox_y1
                                y22_bar_diag = np.round((group_below.iloc[j + 1]["bbox-2"] + group_below.iloc[j + 1][
                                    "bbox-0"]) / 2) + cropbox_y1

                                # check if it should be ignored
                                point1 = [x1_bar_diag, y1_bar_diag]
                                point2 = [x21_bar_diag, y21_bar_diag]
                                passed_ignore_areas = ignore_point_function(ignore_areas, point1, point2)
                                if passed_ignore_areas == True:
                                    dist_bar_diag.append(
                                        np.sqrt((x21_bar_diag - x1_bar_diag) ** 2 + (y21_bar_diag - y1_bar_diag) ** 2))
                                    points_x1_bar_diag.append(x1_bar_diag)
                                    points_x2_bar_diag.append(x21_bar_diag)
                                    points_y1_bar_diag.append(y1_bar_diag)
                                    points_y2_bar_diag.append(y21_bar_diag)

                                # check if it should be ignored
                                point1 = [x1_bar_diag, y1_bar_diag]
                                point2 = [x22_bar_diag, y22_bar_diag]
                                passed_ignore_areas = ignore_point_function(ignore_areas, point1, point2)
                                if passed_ignore_areas == True:
                                    dist_bar_diag.append(
                                        np.sqrt((x22_bar_diag - x1_bar_diag) ** 2 + (y22_bar_diag - y1_bar_diag) ** 2))
                                    points_x1_bar_diag.append(x1_bar_diag)
                                    points_x2_bar_diag.append(x22_bar_diag)
                                    points_y1_bar_diag.append(y1_bar_diag)
                                    points_y2_bar_diag.append(y22_bar_diag)

                                # calculate nit points
                                rr, cc = line(int(x1_bar_diag), int(y1_bar_diag), int(x21_bar_diag), int(y21_bar_diag))
                                zeros_positions = np.argwhere(img_org[cc, rr] == 0)
                                if len(zeros_positions) >= 2:
                                    start = zeros_positions[0]
                                    end = zeros_positions[-1]
                                    x1_nit_diag = rr[start]
                                    x2_nit_diag = rr[end]
                                    y1_nit_diag = cc[start]
                                    y2_nit_diag = cc[end]
                                    # check if it should be ignored
                                    point1 = [x1_nit_diag, y1_nit_diag]
                                    point2 = [x2_nit_diag, y2_nit_diag]
                                    passed_ignore_areas = ignore_point_function(ignore_areas, point1, point2)
                                    if passed_ignore_areas == True:
                                        dist_nit_diag.append(
                                            np.sqrt(
                                                (x1_nit_diag - x2_nit_diag) ** 2 + (y1_nit_diag - y2_nit_diag) ** 2))
                                        points_x1_nit_diag.append(x1_nit_diag)
                                        points_x2_nit_diag.append(x2_nit_diag)
                                        points_y1_nit_diag.append(y1_nit_diag)
                                        points_y2_nit_diag.append(y2_nit_diag)
                                rr, cc = line(int(x1_bar_diag), int(y1_bar_diag), int(x22_bar_diag), int(y22_bar_diag))
                                zeros_positions = np.argwhere(img_org[cc, rr] == 0)
                                if len(zeros_positions) >= 2:
                                    start = zeros_positions[0]
                                    end = zeros_positions[-1]
                                    x1_nit_diag = rr[start]
                                    x2_nit_diag = rr[end]
                                    y1_nit_diag = cc[start]
                                    y2_nit_diag = cc[end]
                                    # check if it should be ignored
                                    point1 = [x1_nit_diag, y1_nit_diag]
                                    point2 = [x2_nit_diag, y2_nit_diag]
                                    passed_ignore_areas = ignore_point_function(ignore_areas, point1, point2)
                                    if passed_ignore_areas == True:
                                        dist_nit_diag.append(
                                            np.sqrt(
                                                (x1_nit_diag - x2_nit_diag) ** 2 + (y1_nit_diag - y2_nit_diag) ** 2))
                                        points_x1_nit_diag.append(x1_nit_diag)
                                        points_x2_nit_diag.append(x2_nit_diag)
                                        points_y1_nit_diag.append(y1_nit_diag)
                                        points_y2_nit_diag.append(y2_nit_diag)
                                break
            current_contour_num += d
            total_d += d

        # Angular Center to Center
        lm_bar_diag = []
        if len(points_x1_bar_diag) > 0:
            for i in range(len(points_x1_bar_diag)):
                lm_bar_diag.append({"Points": [points_x1_bar_diag[i], points_y1_bar_diag[i], points_x2_bar_diag[i],
                                               points_y2_bar_diag[i]],
                                    "Color": "blue", "Adjustable": 1, "Annotation": ""})
        linemarkings.append(
            {"Measurement": "Between Hole Angular Center to Center Distance", "Linemarkings": lm_bar_diag})
        msmts.append({"Name": "Between Hole Angular Center to Center Distance",
                      "Value": (np.array(dist_bar_diag) * pixel_size).round(5)})
        ss.append({"Name": "Average Between Hole Angular Center to Center Distance",
                   "Value": round(np.mean(dist_bar_diag) * pixel_size, 5),
                   "Summarized_Measurement": "Between Hole Angular Center to Center Distance"})
        ss.append(
            {"Name": "LCDU Angular Center to Center CD", "Value": round(3 * (np.std(dist_bar_diag)) * pixel_size, 5),
             "Summarized_Measurement": "Between Hole Angular Center to Center Distance"})
        #
        # # Angular Edge to Edge
        lm_nit_diag = []
        if len(points_x1_nit_diag) > 0:
            for i in range(len(points_x1_nit_diag)):
                lm_nit_diag.append({"Points": [points_x1_nit_diag[i], points_y1_nit_diag[i], points_x2_nit_diag[i],
                                               points_y2_nit_diag[i]],
                                    "Color": "red", "Adjustable": 1, "Annotation": ""})
        linemarkings.append({"Measurement": "Between Hole Angular Edge to Edge Distance", "Linemarkings": lm_nit_diag})
        msmts.append({"Name": "Between Hole Angular Edge to Edge Distance",
                      "Value": (np.array(dist_nit_diag) * pixel_size).round(5)})
        ss.append({"Name": "Average Between Hole Angular Edge to Edge Dist",
                   "Value": round(np.mean(dist_nit_diag) * pixel_size, 5),
                   "Summarized_Measurement": "Between Hole Angular Edge to Edge Distance"})
        ss.append({"Name": "LCDU Angular Edge to Edge CD", "Value": round(3 * (np.std(dist_nit_diag)) * pixel_size, 5),
                   "Summarized_Measurement": "Between Hole Edge to Edge Distance"})

        # Angular Width
        angles = np.linspace(0, math.pi, nAngles + 1)
        angles = angles[:-1]

        angular_width = []
        angular_linemarkings = []

        for i in range(len(region_data)):
            hole = region_data.iloc[i]
            centr_r = hole["centroid-0"]
            centr_c = hole["centroid-1"]
            r = hole[
                    'major_axis_length'] / 2 + 20  # add 10 pixels of padding outside the major axis length to make sure to capture edge
            centroid = (centr_c, centr_r)

            widths = []

            for theta in angles:
                w, angular_linemarking = compute_circle_width(centroid, r, theta, img, cropbox_x1, cropbox_y1)
                widths.append(w)
                angular_linemarkings.append({"Points": angular_linemarking, "Color": "white", "Adjustable": 0,
                                             "Annotation": ""})

            angular_width.append(np.array(widths) * pixel_size)

        angular_width = np.array(angular_width)
        if not isinstance(angular_linemarkings, list):
            angular_linemarkings = angular_linemarkings.tolist()

        # don't multiply angular width by pixel size, already done above
        msmts.append({"Name": "Angular Diameter", "Value": angular_width.round(5)})
        ss.append({"Name": "Average CD", "Value": round(np.mean(angular_width), 5),
                   "Summarized_Measurement": "Angular Diameter"})
        linemarkings.append({"Measurement": "Angular Diameter", "Linemarkings": angular_linemarkings})

        ss.append({"Name": "Local CDU", "Value": round(3 * np.std(np.mean(angular_width, 1) * pixel_size), 5),
                   "Summarized_Measurement": "Angular Diameter"})
        ss.append({"Name": "LCDU 2", "Value": round(3 * np.std(angular_width * pixel_size), 5),
                   "Summarized_Measurement": "Angular Diameter"})
        # except Exception as e

        #        print()
        #        print("LINEMARKINGS")
        #        print(linemarkings)
        #        print()

        # display linemarkings on image
        plt.figure()
        plt.title("Final Measurements")
        plt.imshow(img_org, cmap='gray')
        for msmt_lm_dat in linemarkings:
            lm_list = msmt_lm_dat['Linemarkings']
            for lm in lm_list:
                pts = lm['Points']
                plt.plot([pts[0], pts[2]], [pts[1], pts[3]], lm['Color'])
        plt.show()
    except Exception:
        traceback.print_exc()
        return -1, -1, -1, (500, "Measurement failed.")
    return msmts, ss, linemarkings, (200, "Success.")

# if __name__ == "__main__":
#     input = '/dat/proj/AIM/Yannis/output.png'
#     img = cv2.imread(input,0)
#     pixel_size = 10
#     params = {'configuration_parameters': {'linear_approximation_factor': 0.1, 'radius_division_ratio': 2.5, 'planar_tem': False, 'clogging': False, 'radius_to_measure': 'exterior', 'contour_approximation': 'simple', 'n_diameters': 15, 'area_deviation_factor': 1.5, 'circularity_deviation_factor': 1.5}, 'bounding_box': [[5, 5, 450, 450]], "ignore_points": [[140, 170]]}
#     measure(img, pixel_size, params)