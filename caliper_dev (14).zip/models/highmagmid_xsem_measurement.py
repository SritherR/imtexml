# measure on binarized full xsem images
import numpy as np, pandas as pd
import math
from skimage.measure import profile_line
from sklearn.linear_model import LinearRegression
from scipy.ndimage.filters import uniform_filter1d
import cv2, os
import matplotlib.pyplot as plt
import skimage.transform
from scipy import stats
import traceback


# if reference line not drawn, measure up from there
# if the bounding box not given, use entire image
# instead of reference line, bounding box top @ the interface?
# will bounding box be used to crop before sending to unet or is it used just for measurement, and UNET the whole image...
# for topdown, segment just inside bounding box, for xsem segment entire image, use bounding box for msmt reference
# how to measure mask height and depth without asking the user for another step
# if they press measure without it, prompt them to add
# if they press measure wihtout it, measure everything assuming no mask; if its there measure the top height or bottom depth

def cd_measurement(bw_data, mids, pixel_size, x_offset, y_offset, ignore_points, ignore_offset):
    """

    :param bw_data: cropped image to within bounding box
    :param mids: pts between each hole
    :param pixel_size: conversion parameter to nm
    :param x_offset: starting x point of bounding box, use to create linemarkings w 0,0 from original image
    :param y_offset: starting y point of bounding box, use to appropriately offset linemarkings
    :return: msmts, summ_stats, linemarkings, error (code,msg)
    """
    msmts, summ_stats, linemarkings = [], [], []

    tops = []
    # find top point to measure from -- the top of the lowest start + the offset
    for lidx in range(len(mids) - 1):
        start_x = mids[lidx]
        end_x = mids[lidx + 1]

        hole_img = bw_data[:, start_x:end_x]

        for r in range(hole_img.shape[0]):
            if sum(hole_img[r, :] > 0) > 0:
                # top found
                tops.append(r)
                break

    # find lowest top
    lowest = min(tops)
    start_search = lowest

    all_CDs = []
    bow_cds = []
    bow_cd_locs = []
    pinch_cds = []
    pinch_cd_locs = []
    pinch_lm, bow_lm = [], []

    ctr_drift_dist = []
    ctr_drift = []
    ctr_drift_angular = []
    cd_cont = []

    hole_info = {}
    for lidx in range(len(mids) - 1):
        start_x = mids[lidx] + 1
        end_x = mids[lidx + 1]

        skip_hole = False

        for ip_x, ip_y in ignore_points:
            if (start_x - ignore_offset < ip_x) and (end_x + ignore_offset > ip_x):
                skip_hole = True
        if skip_hole:
            continue

        hole_img = bw_data[start_search:, start_x:end_x]

        this_hole_CD = []
        this_hole_CD_pts = []
        this_hole_center_ind = []

        top_ctr, bot_ctr = 0, 0
        for r in range(hole_img.shape[0]):

            # IF there is a segmentation issue, don't necessarily want to stop searching, just skip over the row
            if sum(hole_img[r, :] > 0) < 2:  # if <2 white pix, stop search (don't consider single pixel)
                # fill in 0s for this CD
                this_hole_CD.append(0)
                this_hole_CD_pts.append(
                    [0, 0, 0, 0])  # x1 x2 y1 y2

                this_hole_center_ind.append(0)
                continue

            row = hole_img[r, :]

            # should measure to the INSIDE of the label edge; don't pick the point outside the label, pick the point inside
            e1 = np.argwhere(row > 0).flatten()[0]
            e2 = np.argwhere(row[e1:] == 0).flatten()
            if len(e2) > 0:
                e2 = e1 + e2[
                    0] - 1  # measure to inside of label on right (code picks the first 0 point, want the 1 point before that)
            else:
                e2 = hole_img.shape[1]

            if r == 0:
                # calculate the center index at top of hole
                top_ctr = e1 + (e2 - e1) / 2

            this_hole_CD.append(e2 - e1)
            this_hole_CD_pts.append(
                [start_x + e1 + x_offset, start_search + r + y_offset, start_x + e2 + x_offset,
                 start_search + r + y_offset])  # x1 x2 y1 y2

            this_hole_center_ind.append(e1 + ((e2 - e1) / 2))

        # use last calculated cd for bottom center
        bot_ctr = this_hole_center_ind[-1]

        # bow_loc = np.argmax(hole_info[lidx]['CD'])
        CDs = np.array(this_hole_CD)
        all_CDs.append(CDs)
        this_hole_CD_pts = np.array(this_hole_CD_pts)

        bow_loc = np.flatnonzero(CDs == CDs.max())[0]  # if there is a tie, pick the first max -- the highest bow
        bow_cds.append(this_hole_CD[bow_loc])
        bow_cd_locs.append(bow_loc)
        # bow_lm.append({"Points": this_hole_CD_pts[bow_loc], "Color": "blue", "Adjustable": 0, "Annotation": ""})
        bow_lm.append(
            {"Points": this_hole_CD_pts[bow_loc].tolist(), "Color": "pink", "Adjustable": 0, "Annotation": ""})

        pinch_loc = np.flatnonzero(CDs == (CDs[np.nonzero(CDs)]).min())[
            -1]  # if there is a tie, pick the LAST min -- the lowest pinch
        pinch_cds.append(CDs[pinch_loc])
        pinch_cd_locs.append(pinch_loc)
        # pinch_lm.append({"Points": this_hole_CD_pts[pinch_loc], "Color": "green", "Adjustable": 0, "Annotation": ""})
        pinch_lm.append(
            {"Points": this_hole_CD_pts[pinch_loc].tolist(), "Color": "magenta", "Adjustable": 0, "Annotation": ""})

        ctr_drift_dist.append(top_ctr - bot_ctr)

        # for stats calculations, remove 0s
        CDs = CDs[np.nonzero(CDs)]

        # Calculate L2Norm -- 3 sigma of residuals of CDs & straight line fitted through CDs
        x = np.array(range(len(CDs))).reshape(-1, 1)
        y = CDs.reshape(-1, 1)  # np.array(hole_info[lidx]['CD']).reshape(-1,1)

        # model = make_pipeline(PolynomialFeatures(1), Ridge())
        # model.fit(x,y)
        # yy = model.predict(x)
        model = LinearRegression()
        model.fit(x, y)
        yy = model.predict(x)
        y = y.flatten()
        yy = yy.flatten()

        l2norm = 3 * math.sqrt(sum((y - yy.flatten()) ** 2))
        cd_cont.append(l2norm)
        #
        # Calculate LER = 3 sigma of residuals between vertical @ hole center @ top of hole & all other calculated hole centers
        # vector of the center at the top of hole, repeated for each CD calculation
        # vector of the center of the hole at each CD calculation (midpt between x2 and x1)
        top_ctr_vec = np.array([top_ctr] * len(this_hole_center_ind))
        # smooth center indices
        ctr = uniform_filter1d(this_hole_center_ind, size=11)
        LER = 3 * math.sqrt(sum((top_ctr_vec - ctr.flatten()) ** 2))  # test this
        ctr_drift.append(LER)

        # Calculate LER2 - fit line through hole centers & take 3 sigma of residuals w actual hole centers
        model = LinearRegression()
        xx = np.array(range(len(ctr))).reshape(-1, 1)
        model.fit(xx, ctr)
        ctr_fit = model.predict(xx)
        l2norm2 = 3 * math.sqrt(sum((ctr - ctr_fit.flatten()) ** 2))
        ctr_drift_angular.append(l2norm2)

    bow_cds = np.array(bow_cds)
    bow_cd_locs = np.array(bow_cd_locs)
    pinch_cds = np.array(pinch_cds)
    pinch_cd_locs = np.array(pinch_cd_locs)

    avg_bow_loc = np.mean(bow_cd_locs)
    avg_pinch_loc = np.mean(pinch_cd_locs)

    ctr_drift_dist = np.array(ctr_drift_dist)
    ctr_drift = np.array(ctr_drift)
    ctr_drift_angular = np.array(ctr_drift_angular)
    cd_cont = np.array(cd_cont)

    top_cds = np.array([cd[0] for cd in all_CDs])
    bot_cds = np.array([cd[-1] for cd in all_CDs])

    all_CDs = np.array([np.array(l) for l in all_CDs])
    msmts.append({"Name": "Top CD [nm]", "Value": (top_cds * pixel_size).round(5)})
    msmts.append({"Name": "Bottom CD [nm]", "Value": (bot_cds * pixel_size).round(5)})

    msmts.append({"Name": "CD [nm]", "Value": (all_CDs * pixel_size).round(5)})
    msmts.append({"Name": "Bow CD [nm]", "Value": (bow_cds * pixel_size).round(5)})
    msmts.append({"Name": "Bow CD Location [nm]", "Value": (bow_cd_locs * pixel_size).round(5)})
    msmts.append({"Name": "Pinch CD [nm]", "Value": (pinch_cds * pixel_size).round(5)})
    msmts.append({"Name": "Pinch CD Location [nm]", "Value": (pinch_cd_locs * pixel_size).round(5)})
    msmts.append({"Name": "Center Drift Horizontal Distance [nm]", "Value": (ctr_drift_dist * pixel_size).round(5)})
    msmts.append({"Name": "Center Drift [nm]", "Value": (ctr_drift * pixel_size).round(5)})
    msmts.append({"Name": "Center Drift (Angular)", "Value": ctr_drift_angular.round(5)})  # no pix size bc angles
    msmts.append({"Name": "CD Continuity", "Value": cd_cont.round(5)})  # no pix size bc measure of residuals

    # add linemarkings data
    linemarkings.append({"Measurement": "Bow CD [nm]", "Linemarkings": bow_lm})
    linemarkings.append({"Measurement": "Pinch CD [nm]", "Linemarkings": pinch_lm})
    linemarkings.append({"Measurement": "Average Bow CD Location [nm]", "Linemarkings": [
        {"Points": [mids[0] + x_offset, start_search + y_offset, mids[0] + x_offset,
                    start_search + avg_bow_loc + y_offset], "Color": "pink",
         "Adjustable": 0, "Annotation": ""}
    ]})
    linemarkings.append({"Measurement": "Average Pinch CD Location [nm]", "Linemarkings": [
        {"Points": [mids[0] + 5 + x_offset, start_search + y_offset, mids[0] + 5 + x_offset,
                    start_search + avg_pinch_loc + y_offset], "Color": "magenta",
         "Adjustable": 0, "Annotation": ""}
    ]})
    # summarize
    avg_cds = [np.mean(CD_array) for CD_array in all_CDs]
    summ_stats.append({"Name": "Average CD [nm]", "Value": round(np.mean(avg_cds) * pixel_size, 5),
                       "Summarized_Measurement": "CD [nm]"})
    summ_stats.append({"Name": 'Average Bow CD [nm]', "Value": round(np.mean(bow_cds) * pixel_size, 5),
                       "Summarized_Measurement": "Bow CD [nm]"})
    summ_stats.append({"Name": 'Average Pinch CD [nm]', "Value": round(np.mean(pinch_cds) * pixel_size, 5),
                       "Summarized_Measurement": "Pinch CD [nm]"})
    summ_stats.append({"Name": 'Average Bow CD Location [nm]', "Value": round(avg_bow_loc * pixel_size, 5),
                       "Summarized_Measurement": "Bow CD Location [nm]"})
    summ_stats.append({"Name": 'Average Pinch CD Location [nm]', "Value": round(avg_pinch_loc * pixel_size, 5),
                       "Summarized_Measurement": "Pinch CD Location [nm]"})
    summ_stats.append({"Name": 'Average CD Continuity', "Value": round(np.mean(cd_cont), 5),
                       "Summarized_Measurement": "CD Continuity"})
    summ_stats.append({"Name": "Average Center Drift [nm]", "Value": round(np.mean(ctr_drift) * pixel_size, 5),
                       "Summarized_Measurement": "Center Drift [nm]"})
    summ_stats.append(
        {"Name": "Average Center Drift Horizontal Distance", "Value": round(np.mean(ctr_drift_dist) * pixel_size, 5),
         "Summarized_Measurement": "Center Drift Horizontal Distance [nm]"})
    summ_stats.append({"Name": 'Average Center Drift Angular', "Value": round(np.mean(ctr_drift_angular), 5),
                       "Summarized_Measurement": "Center Drift Angular"})
    summ_stats.append({"Name": 'Average Top CD [nm]', "Value": round(np.mean(top_cds) * pixel_size, 5),
                       "Summarized_Measurement": "Top CD [nm]"})
    summ_stats.append({"Name": "Average Bottom CD [nm]", "Value": round(np.mean(bot_cds) * pixel_size, 5),
                       "Summarized_Measurement": "Bottom CD [nm]"})

    return msmts, summ_stats, linemarkings, all_CDs, start_search


def calculate_crossover(CDs):
    # calculate the crossover location (from bow to pinch)
    # calculate the area before the crossover and the area after the crossover
    # calculate the cummulative difference between linear fit of CD averages and vector of CD averages
    # calculate the bow extent (ratio of ^diff to area under linear fit)*100

    # make df of all CDs for all holes -- align by top CD, drop the lowest CDs for all
    shortest_hole = min([len(cd) for cd in CDs])

    CD_df = pd.DataFrame()
    for hidx, hinfo in enumerate(CDs):
        CD_df[hidx] = hinfo[:shortest_hole]

    # replace 0s with Nan so they will get ignored in averaging
    CD_df = CD_df.replace(0, np.NaN)

    CD_avgs = CD_df.mean(axis=1)
    CD_avgs = uniform_filter1d(CD_avgs.to_numpy(), size=11)

    top5_avg = np.mean(CD_avgs[:5])
    bot5_avg = np.mean(CD_avgs[-5:len(CD_avgs)])

    model = LinearRegression()
    model.fit(np.array([0, len(CD_avgs)]).reshape(-1, 1), np.array([top5_avg, bot5_avg]).reshape(-1, 1))
    yy = model.predict(np.arange(len(CD_avgs)).reshape(-1, 1))

    yy = yy.flatten()

    # print(list(zip(yy,CD_avgs)))

    cumm_diff = sum(abs(yy - CD_avgs))

    yy_find = yy[10:]
    CD_avgs_find = CD_avgs[10:]

    # the 0.07 is a param, should change based on the case
    t = 0.01
    index = np.argwhere(abs(yy_find - CD_avgs_find) < t)
    while (index.size == 0) and t < 0.5:  # try increasing thresholds until 0.5, then call it No Crossover
        t += 0.01
        index = np.argwhere(abs(yy_find - CD_avgs_find) < t)

    if index.size == 0:
        crossover = len(CD_avgs) - 1
        diff_right = 0
    else:
        crossover = index.flatten()[0] + 10

        mean_vect_right = CD_avgs[crossover:]
        yy_right = yy[crossover:]

        x2_right = np.arange(len(yy_right))

        auc_right = np.trapz(mean_vect_right, x2_right)
        aul_right = np.trapz(yy_right, x2_right)

        diff_right = auc_right - aul_right

    mean_vect_left = CD_avgs[:crossover]
    yy_left = yy[:crossover]
    x2_left = np.arange(len(yy_left))
    auc_left = np.trapz(mean_vect_left, x2_left)
    aul_left = np.trapz(yy_left, x2_left)
    diff_left = auc_left - aul_left

    AUC = np.trapz(CD_avgs, np.arange(len(CD_avgs)))
    AUL = np.trapz(yy, np.arange(len(yy)))
    diff = AUC - AUL

    isBow = diff > 0
    bowextent = diff / AUL * 100

    return crossover, isBow, bowextent, diff_left, diff_right, cumm_diff


def get_hole_delimiters(img, ignore_points, ignore_offset):
    m, n = img.shape[0], img.shape[1]
    # find how many holes -- how many pairs of points are in a horizontal scan at the center (vertically) of the image
    horz_scan = profile_line(img, (m // 2, 0), (m // 2, n), mode='nearest')
    horz_scan = horz_scan.flatten()

    # based on whether we start in white or black, skip first (its a right edge) or take first (its a left edge)
    start_in = False
    end_in = False
    if horz_scan[0] == 255:
        # bounding box starts mid hole
        start_in = True

    if horz_scan[-1] == 255:
        # bounding box ends mid hole
        end_in = True

    # plt.figure()
    # plt.plot(horz_scan)
    chg = np.argwhere(np.diff(horz_scan) != 0)
    # plt.plot(chg, [1]*len(chg), "r*")
    # plt.show()
    if start_in:
        chg = chg[1:]
    # if bounding box ends in the middle of a hole, take out the last chg point
    if end_in:
        chg = chg[:-1]
    # some chg points are right next to each other -- remove these
    keep = np.argwhere((chg[1:] - chg[:-1]).flatten() != 1)
    mid_hole_edges = chg[keep].flatten()
    mid_hole_edges = np.append(mid_hole_edges, chg[-1])

    if start_in:
        start_col = np.max((img != 255).argmax(axis=1))
    else:
        start_col = 1
    # if bounding box ends in the middle of a hole, take out the last chg point
    if end_in:

        flipped_bw_data = np.fliplr(img)
        end_col = n - 1 - np.max((img != 255).argmax(axis=1))
    else:
        end_col = n - 1

    # find hole "lanes" -- midway points between 2&3, 4&5, 6&7, etc. must be whole numbers bc indices (pixels)
    lanes = mid_hole_edges[1:-1:2] + ((mid_hole_edges[2::2] - mid_hole_edges[1:-1:2]) // 2)
    lanes = np.append([start_col], lanes)
    lanes = np.append(lanes, end_col)

    hole_centers = mid_hole_edges[:-1:2] + ((mid_hole_edges[1::2] - mid_hole_edges[:-1:2]) // 2)

    # # if any holes should be ignored, remove that center from the hole_centers list
    hole_centers_cleaned = []
    for lidx, hc in enumerate(hole_centers):
        start_x = lanes[lidx] + 1
        end_x = lanes[lidx + 1]

        skip_hole = False
        for ip_x, ip_y in ignore_points:
            if (start_x - ignore_offset < ip_x) and (end_x + ignore_offset > ip_x):
                skip_hole = True

        if not skip_hole:
            hole_centers_cleaned.append(hc)

    return hole_centers_cleaned, lanes


def measure(img, pixel_size, params):
    img_org = img.copy()
    if "bounding_box" not in params:
        return -1, -1, -1, (400, "Missing bounding box.")

    bounding_box = params["bounding_box"][0]

    x1, y1, x2, y2 = bounding_box
    cd_img = img[y1:y2, x1:x2]

    try:
        ignore_offset = params["configuration_parameters"]["masking_offset"]
    except KeyError:
        return -1, -1, -1, (400, "Missing offset configuration parameter.")

    try:
        x_offset = bounding_box[0]
        y_offset = bounding_box[1]

        ignore_points = []
        if 'ignore_points' in params:
            if len(params["ignore_points"][0]) != 0:
                ignore_points = [(ip_x - x1, ip_y - y1) for (ip_x, ip_y) in params['ignore_points']]
    except Exception:
        return (-1, -1, -1, (400, 'Error parsing mask points.'))

    try:
        # find hole centers & hole lanes
        try:
            hole_centers, lanes = get_hole_delimiters(cd_img, ignore_points, ignore_offset)
        except Exception:
            traceback.print_exc()
            return -1, -1, -1, (500, 'Error getting hole delimiters.')

        try:
            msmts, summ_stats, linemarkings, all_CDs, top_loc = cd_measurement(cd_img, lanes, pixel_size, x1, y1,
                                                                               ignore_points, ignore_offset)
        except Exception:
            traceback.print_exc()
            return -1, -1, -1, (500, 'Error measuring CDs')

        try:
            crossover, isBow, bowextent, area_left, area_right, cumm_diff = calculate_crossover(all_CDs)
        except Exception:
            traceback.print_exc()
            return -1, -1, -1, (500, 'Error calculating crossover data.')

        linemarkings.append({"Measurement": "Crossover Location [nm]", "Linemarkings": [
            {"Points": [lanes[0] + x1, top_loc + crossover + y1, lanes[-1] - 1 + x1,
                        top_loc + crossover + y1],
             "Color": "red", "Adjustable": 0, "Annotation": ""}]})

        summ_stats.append({"Name": "isBow", "Value": isBow, "Summarized_Measurement": ""})
        summ_stats.append({"Name": 'BowExtent', "Value": round(bowextent, 5), "Summarized_Measurement": ""})
        summ_stats.append({"Name": 'Crossover Location [nm]', "Value": round(crossover * pixel_size, 5),
                           "Summarized_Measurement": ""})
        summ_stats.append(
            {"Name": 'Area Before Crossover [nm^2]', "Value": round(area_left * pixel_size, 5),
             "Summarized_Measurement": ""})
        summ_stats.append(
            {"Name": 'Area After Crossover [nm^2]', "Value": round(area_right * pixel_size, 5),
             "Summarized_Measurement": ""})
        summ_stats.append({"Name": 'Cumulative Pixels From Linear Fit', "Value": round(cumm_diff, 5),
                           "Summarized_Measurement": ""})

        return msmts, summ_stats, linemarkings, (200, 'Success.')

    except Exception as e:
        print(e)
        traceback.print_exc()
        return -1, -1, -1, (500, 'Error in High Magnification XSEM Middle Case.')
