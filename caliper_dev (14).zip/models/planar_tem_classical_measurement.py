import numpy as np, pandas as pd
import cv2, math
from PIL import Image
from skimage.measure import label, regionprops, regionprops_table  #, profile_line
from skimage.draw import line
from scipy import ndimage as ndi, spatial
import matplotlib.pyplot as plt
import traceback

#nAngles = 15

def elements(array):
    return array.ndim and array.size


def profile_line(image, start_coords, end_coords, *,
                 spacing=1, order=1, endpoint=True):
    coords = []
    n_points = int(np.ceil(spatial.distance.euclidean(start_coords, end_coords)
                           / spacing))
    for s, e in zip(start_coords, end_coords):
        coords.append(np.linspace(s, e, n_points, endpoint=endpoint))
    profile = ndi.map_coordinates(image, coords, order=order)
    return coords, profile

def compute_circle_width(centroid, r, theta, img,x_offset, y_offset):
    """ centroid: [x,y] center of circle
        r: radius over which to measure circle
        theta: angle in radians to measure circle diameter
        img: [mxn] image from which to take intensity values for diameter

        return
            w: width of circle along theta angle
            pos: [x1,y1,x2,y2] endpoints of width bar"""

    xi = np.round([centroid[0] - r * np.cos(theta), centroid[0] + r * np.cos(theta)]).astype(int)
    yi = np.round([centroid[1] - r * np.sin(theta), centroid[1] + r * np.sin(theta)]).astype(int)

    (rr,cc), p = profile_line(img, (yi[0],xi[0]), (yi[1],xi[1]))  #x,y are flipped in image coordinates
    foreground_ind = np.where(p > 0)
    ep1_ind = foreground_ind[0][0]
    ep2_ind = foreground_ind[0][-1]

    ep1_x = cc[ep1_ind]
    ep1_y = rr[ep1_ind]
    ep2_x = cc[ep2_ind]
    ep2_y = rr[ep2_ind]

    width = np.linalg.norm(np.array([ep2_x, ep2_y]) - np.array([ep1_x, ep1_y]))

    return width, [ep1_x+x_offset, ep1_y+y_offset, ep2_x+x_offset, ep2_y+y_offset]

# signature should be measure(img, pixel_size, params)
# bounding box is in params as
def measure(img, pixel_size, params, cropbox_x1, cropbox_y1, ignore_points):

    msmts = []
    linemarkings = []  # (x1,y1,x2,y2)
    ss = []
    label_img = label(img)  # skimage label function discretizes image for regionprops_table
#    plt.figure()
#    plt.imshow(img)
#    plt.show()
    

    regions = regionprops_table(label_img, properties=('area', 'major_axis_length',
                                                       'minor_axis_length', 'perimeter',
                                                       'centroid', 'eccentricity', 'bbox'))
    region_data = pd.DataFrame(regions)

    region_data['circularity'] = region_data['perimeter'] ** 2 / (4 * (region_data['area'] * math.pi))

    # Define min area as mean - 2*std and max are as mean + 2*std -- OR Have kwargs input for parameters hardcoded above
    # -- for each case (as in gmm preprocess) set the proper values

    # std is frequently greater than the mean because of noise - lots of small noise relative to holes - but how to decide a threshold?
    area_factor = params['configuration_parameters']['area_deviation_factor']
    circularity_factor = params['configuration_parameters']['circularity_deviation_factor']
    Min_area = region_data["area"].mean() - area_factor*(region_data["area"].std())
    Max_area = region_data["area"].mean() + area_factor * (region_data["area"].std())
    Min_circularity = region_data["circularity"].mean() - circularity_factor * (region_data["circularity"].std())
    Max_circularity = region_data["circularity"].mean() + circularity_factor * (region_data["circularity"].std())

    # throw away holes with improper area
    keep_holes1 = (region_data['area'] > Min_area) & (region_data['area'] < Max_area) & (
                region_data['circularity'] > Min_circularity) & (region_data['circularity'] < Max_circularity)
        
    # if any bbox points are touching the boundary, toss out
    # bbox-0, bbox-2 are row, bbox-1, bbox-3 = col
    keep_holes2 = (region_data["bbox-0"] > 0) & (region_data["bbox-1"] > 0) & (region_data["bbox-2"] < label_img.shape[0]) & (region_data["bbox-3"] < label_img.shape[1])
    

    keep_holes = keep_holes1 & keep_holes2

    # remove holes given the 'mask feature' tool from UI
    if len(ignore_points[0])!=0:
      for ignore_point in ignore_points:
        ip_x, ip_y = ignore_point[0], ignore_point[1]
  #          ip_x = ip_x - cropbox_x1
  #          ip_y = ip_y - cropbox_y1
        keep_holes = keep_holes & ~(((region_data["bbox-0"] < ip_y) & (region_data["bbox-2"] > ip_y)) & ((region_data["bbox-1"] < ip_x) & (region_data["bbox-3"] > ip_x)))

    region_data = region_data[keep_holes]
    
    if region_data.empty:
        return -1, -1, -1, (500, "No holes detected.")

    # Store measurements from region props
#    print("here")
#    mylist = (np.array(region_data['major_axis_length']) * pixel_size).tolist()
#    print([ round(elem, 2) for elem in mylist ])
    
    meas_list = (np.array(region_data['major_axis_length']) * pixel_size).tolist()
    meas_list = [round(elem, 5) for elem in meas_list]
    msmts.append({"Name": "Major Axis Length", "Value": meas_list})
    meas_num = region_data['major_axis_length'].mean() * pixel_size
    meas_num = round(meas_num, 5)
    ss.append({"Name": "Average Major Axis", "Value": meas_num,
               "Summarized_Measurement": "Major Axis Length"})
    meas_list = (np.array(region_data['minor_axis_length']) * pixel_size).tolist()
    meas_list = [round(elem, 5) for elem in meas_list]
    msmts.append({"Name": "Minor Axis Length", "Value": meas_list})
    meas_num = region_data['minor_axis_length'].mean() * pixel_size
    meas_num = round(meas_num, 5)
    ss.append({"Name": "Average Minor Axis", "Value": meas_num,
               "Summarized_Measurement": "Minor Axis Length"})
    
    meas_list = (np.array(region_data['circularity'])).tolist()
    meas_list = [round(elem, 5) for elem in meas_list]
    msmts.append({"Name": "Circularity", "Value": meas_list})
    meas_num = region_data['circularity'].mean()
    meas_num = round(meas_num, 5)
    ss.append({"Name": "Average Circularity", "Value": meas_num,
               "Summarized_Measurement": "Circularity"})
    
    meas_list = (np.array(region_data['area']) * pixel_size).tolist()
    meas_list = [round(elem, 5) for elem in meas_list]
    msmts.append({"Name": "Area", "Value": meas_list})
    meas_num = region_data['area'].mean() * pixel_size
    meas_num = round(meas_num, 5)
    ss.append({"Name": "Average Area", "Value": meas_num,
               "Summarized_Measurement": "Area"})
    meas_num = (region_data['major_axis_length'] / region_data['minor_axis_length']).mean()
    meas_num = round(meas_num, 5)
    ss.append({"Name": "Average Major to Minor Axis Ratio",
               "Value": meas_num,
               "Summarized_Measurement": ["Major Axis Length", "Minor Axis Length"]})
    
    meas_num = region_data['eccentricity'].mean()
    meas_num = round(meas_num, 5)
    ss.append({"Name": "Average Eccentricity", "Value": meas_num,
               "Summarized_Measurement": None})

    # Between-hole distances
    # sort bounding boxes according to column 2 = y position of origin of bb
    bb_data = region_data.filter(regex='bbox')
    BR_sorted = bb_data.sort_values(by="bbox-0", ignore_index=True)  # sort by the starting column of the bounding box
    hole_columns = BR_sorted["bbox-0"]
    diffcol = np.array(hole_columns[1:]) - np.array(hole_columns[0:-1])
    risingedge = np.where(diffcol > 30)
    indx = np.unique(risingedge)
    if len(indx) == 0:
        BR_sorted_rowwise = [BR_sorted.sort_values(by="bbox-1")]
    else:
        BR_sorted_rowwise = []

        for i in range(len(indx)):
            if i == 0:
                BR_sorted_rowwise.append(BR_sorted.iloc[i:indx[i]+1].sort_values(by="bbox-1"))
            else:
                BR_sorted_rowwise.append(BR_sorted.iloc[indx[i-1]+1:indx[i]+1].sort_values(by="bbox-1"))

        BR_sorted_rowwise.append(BR_sorted.iloc[indx[i]+1:].sort_values(by="bbox-1"))
    dist = []
    points_x1 = []
    points_x2 = []
    points_y = []
    for group in BR_sorted_rowwise:
        d = len(group)  # number of holes in this row
        if d > 1:
            # between-hole dist is hole1's c2 -> hole2's c1
            for i in range(1, d):
                x1 = group.iloc[i - 1]["bbox-3"] + cropbox_x1
                x2 = group.iloc[i]["bbox-1"] + cropbox_x1
                y = np.round((group.iloc[i]["bbox-2"] + group.iloc[i]["bbox-0"]) / 2) + cropbox_y1
                dist.append(x2 - x1)
                #linemarkings.append((x1, y, x2, y))
                points_x1.append(x1)
                points_x2.append(x2)
                points_y.append(y)
    lm = []
    if len(points_x1) > 0:
        for i in range(len(points_x1)):
            lm.append({"Points": [points_x1[i], points_y[i], points_x2[i], points_y[i]],
                       "Color": "blue", "Adjustable": 0, "Annotation": ""})

    linemarkings.append({"Measurement": "Between Hole Distance", "Linemarkings": lm})
    meas_list = (np.array(dist) * pixel_size).tolist()
    meas_list = [round(elem, 5) for elem in meas_list]
    msmts.append({"Name": "Between Hole Distance", "Value": meas_list})
    meas_num = np.mean(dist) * pixel_size
    meas_num = round(meas_num, 5)
    ss.append({"Name": "Average Between Hole Dist", "Value": meas_num,
               "Summarized_Measurement": "Between Hole Distance"})
    meas_num = 3*(np.std(dist)) * pixel_size
    meas_num = round(meas_num, 5)
    ss.append({"Name": "LCDU Bar CD", "Value": meas_num,
               "Summarized_Measurement": "Between Hole Distance"})

    # Angular Width
    nAngles = params["configuration_parameters"]["n_diameters"]
    angles = np.linspace(0, math.pi, nAngles+1)
    angles = angles[:-1]
    angular_width = []
    angular_linemarkings = []
    for i in range(len(region_data)):
        hole = region_data.iloc[i]
        centr_r = hole["centroid-0"]
        centr_c = hole["centroid-1"]
        r = hole['major_axis_length'] / 2 + 20  # add 10 pixels of padding outside the major axis length to make sure to capture edge
        centroid = (centr_c, centr_r)
        widths = []
        for theta in angles:
            w, angular_linemarking = compute_circle_width(centroid, r, theta, img, cropbox_x1, cropbox_y1)
            widths.append(w)
            angular_linemarkings.append({"Points": angular_linemarking, "Color": "red", "Adjustable": 0,
                                         "Annotation": ""})
        angular_width.append(np.array(widths) * pixel_size)
    angular_width = np.array(angular_width)
    if not isinstance(angular_linemarkings, list):
        angular_linemarkings = angular_linemarkings.tolist()
    # don't multiply angular width by pixel size, already done above
#    print(angular_width.tolist())
    meas_list = angular_width.tolist()
    for i, meas_list_i in enumerate(meas_list):
      meas_list[i] = [round(elem, 5) for elem in meas_list_i ]
    msmts.append({"Name": "Angular Diameter", "Value": meas_list})
    meas_num = np.mean(angular_width)
    meas_num = round(meas_num, 5)
    ss.append({"Name": "Average CD", "Value": meas_num, "Summarized_Measurement": "Angular Diameter"})
    linemarkings.append({"Measurement": "Angular Diameter", "Linemarkings": angular_linemarkings})
    
    meas_num = 3 * np.std(np.mean(angular_width, 1)) * pixel_size
    meas_num = round(meas_num, 5)
    ss.append({"Name": "Local CDU", "Value": meas_num,
               "Summarized_Measurement": "Angular Diameter"})
    meas_num = 3 * np.std(angular_width) * pixel_size
    meas_num = round(meas_num, 5)
    ss.append({"Name": "LCDU 2", "Value": meas_num,
               "Summarized_Measurement": "Angular Diameter"})
    print(msmts, ss)
    return msmts, ss, linemarkings, (200, "Success.")

