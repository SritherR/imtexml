import numpy as np
import matplotlib.pyplot as plt

def find_limit(horz_scan, alpha1, alpha2, alpha3, plot=False):
    found = False
    try:
        # print(horz_scan)
        #find derivative of profile
        horz_scan = horz_scan.astype(float)
        derv_1_y = []
        for num in range(1, len(horz_scan) - 1):
            derv_1_y.append((horz_scan[num + 1] - horz_scan[num - 1]) / 2)
        #find maximum of derivative
        min_der = min(derv_1_y)
        for i, j in enumerate(derv_1_y):
            derv_1_y[i] = derv_1_y[i] + abs(min_der)
        derv_1_y = np.insert(derv_1_y, 0, 0.0)
        derv_1_y = np.append(derv_1_y, 0.0)
        pos1_x = np.argmax(derv_1_y[2:-2]) + 2
        pos1_y = derv_1_y[pos1_x]

        # find alpha1% of max in derv_1_y and then y in horz_scan
        value1 = pos1_y - alpha1 * pos1_y
        index = -1
        # for i in range(pos1_x, len(derv_1_y) - 1):
        #     if derv_1_y[i] >= value1 and derv_1_y[i + 1] <= value1:
        #         index = i
        #         break
        for i in range(pos1_x, len(derv_1_y) - 2):
            if derv_1_y[i] >= value1 and derv_1_y[i + 1] <= value1:
                index = i
                break
        if index == -1:
            # print(np.argmin(derv_1_y[pos1_x, len(derv_1_y) - 1]))
            index = np.argmin(derv_1_y[pos1_x, len(derv_1_y) - 1])+pos1_x
            value1 = np.average([derv_1_y[pos1_x], derv_1_y[index]])
        x = [pos1_x, index + 1]
        if x[0] != x[1]:
            y = [derv_1_y[pos1_x], derv_1_y[index + 1]]
            alpha = (y[1] - y[0]) / (x[1] - x[0])
            if alpha != 0:
                beta = y[0] - alpha * x[0]
                x_new1 = (value1 - beta) / alpha
            else:
                x_new1 = x[0]
        else:
            x_new1 = x[0]
        # transfer to horz_scan and find y
        index = int(np.floor(x_new1))
        x = [index, index + 1]
        if x[0] != x[1]:
            y = [horz_scan[index], horz_scan[index + 1]]
            alpha = (y[1] - y[0]) / (x[1] - x[0])
            beta = y[0] - alpha * x[0]
            y_new1 = alpha * x_new1 + beta
        else:
            y_new1 = alpha * x[0] + beta

        index = -1
        # find alpha2% of max in derv_1_y and then y in horz_scan
        value2 = pos1_y - alpha2 * pos1_y
        # for i in range(0, pos1_x):
        #     if derv_1_y[i] <= value2 and derv_1_y[i + 1] >= value2:
        #         index = i
        #         break
        for i in range(1, pos1_x):
            if derv_1_y[i] <= value2 and derv_1_y[i + 1] >= value2:
                index = i
                break
        if index == -1:
            index = np.argmin(derv_1_y[1: pos1_x][::-1])+1
            value2 = np.average([derv_1_y[pos1_x], derv_1_y[index]])
        x = [index, pos1_x]
        if x[0] != x[1]:
            y = [derv_1_y[index], derv_1_y[pos1_x]]
            alpha = (y[1] - y[0]) / (x[1] - x[0])
            if alpha != 0:
                beta = y[0] - alpha * x[0]
                x_new2 = (value2 - beta) / alpha
            else:
                x_new2= x[0]
        else:
            x_new2 = x[0]
        # print("new")
        # print(y)
        # print(x)
        # print(alpha)
        # print(beta)
        # print(x_new2)
        # transfer to horz_scan and find y
        index = int(np.ceil(x_new2))
        x = [index - 1, index]
        if x[0] != x[1]:
            y = [horz_scan[index - 1], horz_scan[index]]
            alpha = (y[1] - y[0]) / (x[1] - x[0])
            beta = y[0] - alpha * x[0]
            y_new2 = alpha * x_new2 + beta
        else:
            y_new2 = alpha * x[0] + beta

        # find alpha3% in horz scan
        x = [x_new1, x_new2]
        y = [y_new1, y_new2]
        alpha = (y[1] - y[0]) / (x[1] - x[0])
        if y[0] != y[1]:
            beta = y[0] - alpha * x[0]
            y_new3 = (y[1] - y[0]) * alpha3 + y[0]
            x_new3 = (y_new3 - beta) / alpha
        else:
            y_new3 = (y[1] - y[0]) * alpha3 + y[0]
            x_new3 = x[0]
        # print(x_new3)
        found = True
        if plot == True:
            plt.figure(1, figsize=(10,10))
            plt.subplot(211)
            plt.title("Derivative of Gray Level")
            for i, j in enumerate(derv_1_y):
                plt.plot(i, j, '.', markersize=10, color='black')
            plt.plot(pos1_x, pos1_y, '.', markersize=14, color='red')
            plt.plot(x_new1, value1, '.', markersize=14, color='green')
            plt.plot(x_new2, value2, '.', markersize=14, color='green')

            plt.subplot(212)
            plt.title("Gray Level")
            for i, j in enumerate(horz_scan):
                plt.plot(i, j, '.', markersize=10, color='black')
            plt.plot(x_new1, y_new1, '.', markersize=14, color='green')
            plt.plot(x_new2, y_new2, '.', markersize=14, color='green')
            plt.plot(int(np.floor(x_new3)), y_new3, '.', markersize=14, color='red')
            plt.show()
    except:
        x_new3 = 0
        found = False
    # print(x_new3)
    return int(np.round(x_new3)), found