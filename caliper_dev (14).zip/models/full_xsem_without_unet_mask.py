# measure on binarized full xsem images
import numpy as np, pandas as pd
import math
from PIL import Image
from skimage.measure import label, regionprops, regionprops_table, profile_line
from skimage.draw import line
from scipy import ndimage as ndi, spatial
import matplotlib.pyplot as plt
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import PolynomialFeatures
from sklearn.linear_model import Ridge, LinearRegression
from scipy.ndimage.filters import uniform_filter1d
from scipy import stats
import cv2, os
# from transfer_unet_helper import transfer_unet
# from tensorflow.keras.models import model_from_json
import skimage.transform
import traceback
from scipy.ndimage import gaussian_filter
from medpy.filter.smoothing import anisotropic_diffusion
from scipy.signal import find_peaks, medfilt2d
from skimage import exposure
import numpy.matlib
from models.full_xsem_without_unet_mask_linear_approx import find_limit
from scipy.optimize import curve_fit
from skimage.morphology import rectangle
import skimage.filters as filters
from scipy import ndimage
from skimage.morphology import skeletonize
import pickle


def findcenter_Micronnew(img_org, hole_x, params):
    bg = img_org
    size_x = int(np.round(len(bg) * .25))
    img_center_patch = bg[size_x:size_x * 3, :]
    sig_img_patch = np.mean(img_center_patch, 0)
    grads = np.gradient(sig_img_patch)
    top_peaks = sorted(grads, reverse=True)[:3]
    mean_of_top_peaks = np.mean(top_peaks)

    height_thres = params['configuration_parameters']['threshold_signal_to_mean_ratio'] * mean_of_top_peaks
    print(height_thres)
    x1, _ = find_peaks(grads, height=height_thres)

    # relative height, plateau
    y1 = grads[x1]
    # print(x1)
    # plt.figure()
    # plt.plot(np.arange(0, len(grads)), grads)
    # plt.plot(x1, y1, "*-")
    # plt.show()

    F_mid = np.ceil(np.convolve(x1, [0.5, 0.5], 'valid'))
    x = F_mid[0::2]
    r, c = np.shape(img_org)
    y = np.round(r / 2.5)
    l = len(x)
    a0 = np.array(y)
    y = np.matlib.repmat(a0, 1, l)[0]
    # z = np.concatenate((x,y))
    # Center_points = z

    x2 = F_mid[1::2]
    l2 = len(x2)
    y2 = np.round(r / 2.5)
    a0 = np.array(y2)
    y2 = np.matlib.repmat(a0, 1, l2)[0]
    # z2 = np.concatenate((x2, y2))
    # Center_points2 = z2

    numPeaks = len(x1)
    holeCtrFound = False
    idx = 0
    while idx < (numPeaks - 1):
        if x1[idx] < hole_x and hole_x < x1[idx + 1]:
            holeCtrFound = True
            break
        idx = idx + 2
    if holeCtrFound == True:
        x_f = x2
        y_f = y2
    else:
        x_f = x
        y_f = y

    return x_f, y_f


def Gauss(x, A, B):
    y = A * np.exp(-1 * B * x ** 2)
    return y


def preprocess_whole_image(img_pre, params):
    # Preprocessing
    # remove background noise - a lot of rectangular artifacts
    x, y = params["configuration_parameters"]["rectangular_kernel_filter_size"]
    kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (x, y))
    background = cv2.morphologyEx(img_pre, cv2.MORPH_OPEN, kernel)
    # plt.figure()
    # plt.imshow(img_pre, cmap='gray')
    # plt.show()
    minv = 0.01
    maxv = 0.99
    p1, p2 = int(minv * 255), int(maxv * 255)
   # print(img_pre - background)
    I = exposure.rescale_intensity(img_pre - background, in_range=(p1, p2))
    # plt.figure()
    # plt.imshow(I, cmap='gray')
    # plt.show()
    # filter for clarity
    bg = gaussian_filter(I, sigma=.08)
    stre2 = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (5, 5))
    backgroundnew = cv2.morphologyEx(bg, cv2.MORPH_OPEN, stre2)
    img = bg - backgroundnew
    # plt.figure()
    # plt.imshow(img, cmap='gray')
    # plt.show()
    # ensure that the edges are not affected while removing noise
    if params['configuration_parameters']['diffuse_filter'] == True:
        img = anisotropic_diffusion(img, niter=2, kappa=50, gamma=0.1, voxelspacing=None, option=1)
    #    img= cv2.medianBlur(img, 3)
    minv = 0.01
    maxv = 0.99
    p1, p2 = int(minv * 255), int(maxv * 255)
    img = exposure.rescale_intensity(img, in_range=(p1, p2))
    # enhance vertical features
    img = medfilt2d(img, params["configuration_parameters"]["median_filter_size"])
    #    plt.figure()
    #    plt.imshow(img, cmap='gray')
    #    plt.show()
    return img


def preprocess_bottom(img_pre, params):
    #    # img = img_pre
    #    # Preprocessing
    ##    plt.figure()
    ##    plt.imshow(img_pre, cmap='gray')
    ##    plt.show()
    #    img = img_pre
    #    img = anisotropic_diffusion(img)
    ##    img= cv2.medianBlur(img, 3)
    #    minv = 0.25
    #    maxv = 0.85
    #    p1, p2 = int(minv * 255), int(maxv * 255)
    #    img = exposure.rescale_intensity(img, in_range=(p1, p2))
    #    img = medfilt2d(img, [5, 7])
    #
    #    plt.figure()
    #    plt.imshow(img, cmap='gray')
    #    plt.show()
    #
    ##    bottom_binarization_threshold = params["configuration_parameters"]["bottom_binarization_threshold"]
    ##    img_test = cv2.threshold(img, int(bottom_binarization_threshold * 255), 255, cv2.THRESH_BINARY)[1]
    ##    if np.all(img_test==0): #img_test.tolist().count(0)==len(img_test)
    ##        img_test = cv2.threshold(img, int(bottom_binarization_threshold/3 * 255), 255, cv2.THRESH_BINARY)[1]
    ##    if np.all(img_test == 0):  # img_test.tolist().count(0)==len(img_test)
    ##        img_test = cv2.threshold(img, int(bottom_binarization_threshold/30 * 255), 255, cv2.THRESH_BINARY)[1]
    #
    #    ret3,img_test = cv2.threshold(img,0,255,cv2.THRESH_BINARY+cv2.THRESH_OTSU)
    #
    #    img = img_test
    #    plt.figure()
    #    plt.imshow(img, cmap='gray')
    #    plt.show()
    #    one_hole_bottom_img_mean = np.mean(img, axis=1)
    #    # print(one_hole_bottom_img_mean)
    #    white_rows = np.argwhere(one_hole_bottom_img_mean>230)
    #    # print(white_rows)
    #    kernel = np.ones((3, 3), np.uint8)
    #    img = cv2.morphologyEx(img, cv2.MORPH_OPEN, kernel)  # /255

    ####################
    img = img_pre
    img = anisotropic_diffusion(img).astype(np.uint8)
    img = exposure.rescale_intensity(img)
    img = medfilt2d(img, [5, 7])

    bottom_binarization_threshold = params["configuration_parameters"]["bottom_binarization_threshold"]

    if bottom_binarization_threshold != 0:
        img = cv2.threshold(img, int(bottom_binarization_threshold * 255), 255, cv2.THRESH_BINARY)[1]
        if np.all(img == 0):  # img_test.tolist().count(0)==len(img_test)
            img = cv2.threshold(img, int(bottom_binarization_threshold / 3 * 255), 255, cv2.THRESH_BINARY)[1]
        if np.all(img == 0):  # img_test.tolist().count(0)==len(img_test)
            img = cv2.threshold(img, int(bottom_binarization_threshold / 30 * 255), 255, cv2.THRESH_BINARY)[1]
    else:
        ret, img = cv2.threshold(img, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)

    #    plt.figure()
    #    plt.imshow(img, cmap='gray')
    #    plt.show()

    return img


def measure(img_org, pixel_size, params):
    try:

        if "bounding_box" not in params:
            return -1, -1, -1, (400, "Missing bounding box.")
        if "reference_point" not in params:
            return -1, -1, -1, (400, "Missing hole reference point.")

        #      print(img_org)
        msmts, summ_stats, linemarkings = [], [], []
        mask_thickness, depths_temp = [], []
        all_CDs = []
        bow_cds = []
        bow_cd_locs = []
        pinch_cds = []
        pinch_cd_locs = []
        pinch_lm, bow_lm = [], []
        depth_lm, mt_lm = [], []
        top_cd_lm, bot_cd_lm = [], []
        ctr_drift_dist = []
        ctr_drift = []
        ctr_drift_angular = []
        cd_cont = []

        bounding_box = params["bounding_box"][0]

        x1, y1, x2, y2 = bounding_box
        x_offset = x1
        y_offset = y1
        img = img_org[y1:y2, x1:x2]
        #print("hole_position")

        hole_position = params['reference_point']
        #print(hole_position)
        hole_x = hole_position[0][0]
        hole_x = hole_x - x1

        # plt.figure()
        # plt.imshow(img_org_bin, cmap='gray')
        # plt.show()

        # crop section to look for hole bottoms, stop above bottom white text
        crop_bottom = len(img_org)
        for i in range(int(np.ceil(y2)), crop_bottom):
            times_255 = img_org[i].tolist().count(255)
            if times_255 > 5:  # text found
                crop_bottom = i
                break
        #      print(crop_bottom)
        hole_bottom_img = img_org[int(np.ceil(y2)):crop_bottom, :]

        hole_top_img = img_org[0:int(np.ceil(y1)), :]

        # plt.figure()
        # plt.imshow(img_org, cmap='gray')
        # plt.show()
        img = preprocess_whole_image(img, params)
        #### find center
        debug = 1
        X2, Y = findcenter_Micronnew(img, hole_x, params)
        # plt.figure()
        # plt.imshow(img_org[y1:y2, x1:x2], cmap='gray')
        # plt.plot(X2, Y, "r*")
        # plt.show()

        mids = X2.astype(int)
        bw_data = img_org[y1:y2, x1:x2]
        TOP_OFFSET = 0
        tops = []
        # find top point to measure from -- the top of the lowest start + the offset
        for lidx in range(len(mids) - 1):
            start_x = mids[lidx]
            end_x = mids[lidx + 1]
            hole_img = bw_data[:, start_x:end_x]
            for r in range(hole_img.shape[0]):
                if sum(hole_img[r, :] > 0) > 0:
                    # top found
                    tops.append(r)
                    break

        # find lowest top
        lowest = min(tops)
        start_search = lowest + TOP_OFFSET

        mask_thickness, depths_temp = [], []

        for lidx in range(len(mids) - 1):

            start_x = mids[lidx] + 1
            end_x = mids[lidx + 1]
            dif = end_x - start_x

            if "ignore_points" in params:
                ignore_points = params["ignore_points"]
                skip_hole = False
                offset = params["configuration_parameters"]["masking_offset"]
                for ip_x, ip_y in ignore_points:
                    if (start_x - offset < ip_x) and (end_x + offset > ip_x):
                        skip_hole = True
                if skip_hole:
                    continue

            if (dif < params["configuration_parameters"]["holes_diff"]):
                max_y = 0
                max_x = 0
                hole_img = bw_data[start_search:, start_x:end_x]

                this_hole_CD = []
                this_hole_CD_pts = []
                this_hole_center_ind = []

                top_ctr, bot_ctr = 0, 0
                window_size = params["configuration_parameters"]["smoothing_window_length_for_CDs"]
                es = []

                # find depth and if bbox is below the holes
                hole_img = bw_data[start_search:, start_x:end_x]
                #            white_limit_found = False
                hole_below_box = False
                step_size = 50
                #            while white_limit_found == False and step_size < len(bw_data):
                #                hole_img2 = cv2.GaussianBlur(bw_data[-step_size:, start_x:end_x], (5, 5), 0)
                hole_img2 = cv2.GaussianBlur(bw_data[:, start_x:end_x], (5, 5), 0)
                ret3, hole_img2 = cv2.threshold(hole_img2, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
                kernel = np.ones((5, 5), np.uint8)
                hole_img2 = cv2.morphologyEx(hole_img2, cv2.MORPH_OPEN, kernel)

                #            plt.figure()
                #            plt.imshow(hole_img2)
                #            plt.show()

                hole_below_box = params["configuration_parameters"]["holes_below_selected_box"]

                if hole_below_box == False:
                    white_indices = np.argwhere(hole_img2 == 255)
                    max_x = np.max(white_indices[:, 0]) - len(hole_img2)
                    max_y = white_indices[np.argmax(white_indices[:, 0]), 1]

                #            if 255 in hole_img2:
                #                white_limit_found = True
                #                if 255 in hole_img2[-5:-1, :]:
                #                    hole_below_box = True
                #                else:
                #                    white_indices = np.argwhere(hole_img2 == 255)
                #                    # print(white_indices)
                #                    max_x = np.max(white_indices[:, 0]) - len(hole_img2)
                #                    max_y = white_indices[np.argmax(white_indices[:, 0]), 1]
                #                else:
                #                    step_size -= 100

                # print(max_x,max_y)
                # plt.figure()
                # plt.imshow(hole_img2, cmap='gray')
                # plt.plot(max_y, max_x+len(hole_img2), "r*")
                # plt.show()

                #            preprocess_bottom(hole_bottom_img[:, x_offset + start_x:x_offset + end_x], params)

                if hole_below_box == True:
                    limit1 = 0
                    limit2 = hole_img.shape[0]
                else:
                    limit1 = 0
                    limit2 = hole_img.shape[0] + max_x

                for r in range(limit1, limit2 - 5):
                    upper_limit = max(0, r - window_size)
                    lower_limit = min(limit2, r + window_size)

                    hole_img_smooth = cv2.medianBlur(hole_img, 3)
                    row = np.mean(hole_img_smooth[upper_limit:lower_limit, :], 0)
                    # row = hole_img[r,:]
                    # plt.figure()
                    # plt.plot(np.arange(0,len(row)),row)
                    alpha1, alpha2, alpha3 = 0.55, 0.55, params['configuration_parameters'][
                        "linear_approximation_factor_for_CDs"]
                    # print(row)

                    if params['configuration_parameters']["CD"] == "inner":
                        point1, found1 = find_limit(row[0:int(len(row) / 2)][::-1], alpha1, alpha2, alpha3, plot=False)
                        point2, found2 = find_limit(row[int(len(row) / 2):], alpha1, alpha2, alpha3, plot=False)
                        e1 = int(len(row) / 2) - point1
                        e2 = int(len(row) / 2) - 1 + point2
                    elif params['configuration_parameters']["CD"] == "outer":
                        point1, found1 = find_limit(row[0:int(len(row) / 2)], alpha1, alpha2, alpha3, plot=False)
                        point2, found2 = find_limit(row[int(len(row) / 2):][::-1], alpha1, alpha2, alpha3, plot=False)
                        e1 = point1
                        e2 = int(len(row)) - point2

                    # calculate the center index at top of hole
                    if r == 0:
                        if found1 == True and found2 == True:
                            top_ctr = int(np.mean([e1, e2]))
                        else:
                            top_ctr = int(len(row) / 2)
                    if found1 == True and found2 == True:
                        this_hole_CD.append(e2 - e1)
                        this_hole_CD_pts.append(
                            [x_offset + start_x + e1, y_offset + start_search + r, x_offset + start_x + e2,
                             y_offset + start_search + r])
                        ctr_index = int(np.mean([e1, e2]))
                        this_hole_center_ind.append(ctr_index)
                        es.append([e1, e2])
                    # print(e1, e2)
                    # plt.figure()
                    # plt.plot(np.arange(len(row)), row)
                    # plt.plot(e1,row[e1], "r*")
                    # plt.plot(e2,row[e2], "g*")
                    # plt.show()
                    # break
                #            if lidx==6:
                #              plt.figure(figsize=(10,10))
                #              plt.imshow(hole_img, cmap='gray')
                #              plt.show()
                #
                #              plt.figure(figsize=(10,10))
                #              for i,j in enumerate(es):
                #                  plt.plot([j[0], j[1]],[i, i], "r-")
                #              plt.imshow(hole_img, cmap='gray')
                #              plt.show()

                # bottom of hole reached;
                # for each hole, calculate mask height and recess depth

                # bot_ctr is still 0 because didn't hit hole end during CD scan for loop - take last ctr point
                # bot_ctr = hole_info[lidx]['center_ind'][-1]
                bot_ctr = this_hole_center_ind[-1]
                # plt.plot(bot_ctr, y2, "g*")

                # plt.figure()
                # plt.imshow(img[:,x1+start_x:x1+end_x], cmap='gray')
                # plt.plot([bot_ctr, bot_ctr], [0,600], "r")
                # plt.plot([0,end_x-start_x], [y2,y2], "b")
                # plt.show()

                one_hole_top_img = hole_top_img[:, x_offset + start_x:x_offset + end_x]
                #          plt.figure()
                #          plt.imshow(one_hole_top_img, cmap='gray')
                #          plt.show()
                y = [top_ctr, bot_ctr]
                x = [y1, y2]
                alpha = (y[1] - y[0]) / (x[1] - x[0])
                beta = y[0] - alpha * x[0]
                x3 = 0
                y3 = int(round(alpha * x3 + beta))
                rr, cc = line(x3, y3, y1, top_ctr)
                # print(rr, cc)
                # one_hole_top_img[rr[:-2], cc[:-2]] = [255]
                profile_line = one_hole_top_img[rr[:-2], cc[:-2]]
                # plt.figure()
                # plt.imshow(one_hole_top_img, cmap='gray')
                # plt.show()
                alpha1, alpha2, alpha3 = 0.5, 0.5, 0.7
                top, found = find_limit(profile_line, alpha1, alpha2, alpha3, plot=False)
                top_pos = int(round(alpha * top + beta))

                # #find top
                # vert_slice = img_org_bin[:y1, x1+int(start_x + top_ctr - 1): x1+int(start_x + top_ctr + 1)]
                # # print(vert_slice)
                # col_sig = stats.mode(vert_slice, axis=1)[0]
                # col_sig = col_sig.flatten()
                # top = np.argwhere(col_sig == 255).flatten()[0]
                mask_thickness.append(y1 - top)
                # mask_thickness_points.append([x1 + start_x+  top_ctr, top, x1 + start_x + top_ctr, y1])
                mt_lm.append({"Points": [x1 + start_x + top_ctr, top, x1 + start_x + top_pos, y1], "Color": "cyan",
                              "Adjustable": 1, "Annotation": ""})

                # find bottom
                one_hole_bottom_img = hole_bottom_img[:, x_offset + start_x:x_offset + end_x]
                one_hole_bottom_img_processed = preprocess_bottom(
                    hole_bottom_img[:, x_offset + start_x:x_offset + end_x], params)
                # one_hole_bottom_img_mean = np.mean(one_hole_bottom_img_processed, axis = 1)

                #            plt.figure()
                #            plt.imshow(one_hole_bottom_img, cmap='gray')
                #            plt.show()
                #            plt.figure()
                #            plt.imshow(one_hole_bottom_img_processed, cmap='gray')
                #            plt.show()
                # print(method)

                # plt.figure()
                # plt.plot(np.arange(0,len(one_hole_bottom_img_mean)),one_hole_bottom_img_mean, 'r*')
                # plt.show()

                # find bottom
                if hole_below_box == True:
                    centering = bot_ctr
                    for x in range(2, len(one_hole_bottom_img_processed)):
                        hor_line = one_hole_bottom_img_processed[x, :]
                        #                    if hor_line.tolist().count(0)==len(hor_line):
                        #                        max_x = x
                        #                        max_y = centering
                        #                        break
                        if hor_line[centering - 2:centering + 2].tolist().count(255) == len(
                                hor_line[centering - 2:centering + 2]):
                            max_x = x - 1
                            max_y = centering
                            break
                        else:
                            if hor_line[centering] == 255:
                                right_limit = centering
                                left_limit = centering
                                for point in range(centering, len(hor_line)):
                                    if point == 255:
                                        right_limit = point
                                        break
                                for point in range(centering, 0, -1):
                                    if point == 255:
                                        left_limit = point
                                        break
                                centering = int(np.mean([left_limit, right_limit]))

                #            if max_x<15:
                #                max_y = bot_ctr
                # max_x = 0
                #            print("max")
                #            print(max_y,max_x)
                #            plt.figure()
                #            plt.imshow(one_hole_bottom_img, cmap='gray')
                #            plt.plot(max_y, max_x, 'r*')
                #            plt.show()

                depth_slice = img_org[y2:, x1 + int(start_x + bot_ctr - 2):x1 + int(start_x + bot_ctr + 1)]
                # col_sig = stats.mode(depth_slice, axis=1)[0]
                col_sig = np.mean(depth_slice, axis=1)
                col_sig = col_sig.flatten()
                bot = max_x  # np.argwhere(col_sig == 0).flatten()[0] #-1 # stop at last white pixel -- UNET typically rounds off bottom of holes, so don't subtract the 1 for now.
                # plt.figure()
                # plt.imshow(depth_slice, cmap='gray')
                # plt.show()
                depths_temp.append(bot)
                # depth_points.append([x1 + start_x+  bot_ctr, y2, x1 + start_x + bot_ctr, y2+bot])
                if max_y == 0:
                    max_y = bot_ctr
                depth_lm.append({"Points": [x1 + start_x + bot_ctr, y2, x1 + start_x + max_y, y2],
                                 "Color": "blue", "Adjustable": 1, "Annotation": ""})

                # bow_loc = np.argmax(hole_info[lidx]['CD'])
                # CDs = hole_info[lidx]['CD']
                CDs = np.array(this_hole_CD)
                # store this hole information
                all_CDs.append(CDs)
                CD_pts = np.array(this_hole_CD_pts)

                bow_loc = np.flatnonzero(CDs == CDs.max())[
                    0]  # if there is a tie, pick the first max -- the highest bow

                bow_cds.append(CDs[bow_loc])
                bow_cd_locs.append(bow_loc)
                bowpts = CD_pts[bow_loc]
                bow_lm.append({"Points": bowpts.tolist(), "Color": "green", "Adjustable": 1, "Annotation": ""})
                pinch_loc = np.flatnonzero(CDs == (CDs[np.nonzero(CDs)]).min())[
                    -1]  # if there is a tie, pick the LAST min -- the lowest pinch
                # print(CDs ==(CDs[np.nonzero(CDs)]).min())
                #print(pinch_loc)

                pinch_cds.append(CDs[pinch_loc])
                pinch_cd_locs.append(pinch_loc)
                pinch_pts = CD_pts[pinch_loc]
                pinch_lm.append({"Points": pinch_pts.tolist(), "Color": "red", "Adjustable": 1, "Annotation": ""})

                # add linemarkings for top CD and bottom CD this hole
                top_cd_pts = CD_pts[0]
                top_cd_lm.append({"Points": top_cd_pts.tolist(), "Color": "pink", "Adjustable": 1, "Annotation": ""})
                bot_cd_pts = CD_pts[-1]
                bot_cd_lm.append({"Points": bot_cd_pts.tolist(), "Color": "magenta", "Adjustable": 1, "Annotation": ""})

                ctr_drift_dist.append(top_ctr - bot_ctr)

                # for stats calculations, remove 0s
                CDs = CDs[np.nonzero(CDs)]

                # Calculate L2Norm -- 3 sigma of residuals of CDs & straight line fitted through CDs
                x = np.array(range(len(CDs))).reshape(-1, 1)
                y = CDs.reshape(-1, 1)  # np.array(hole_info[lidx]['CD']).reshape(-1,1)

                model = LinearRegression()
                model.fit(x, y)
                yy = model.predict(x)
                y = y.flatten()
                yy = yy.flatten()

                l2norm = 3 * math.sqrt(sum((y - yy.flatten()) ** 2))
                cd_cont.append(l2norm)
                #
                # Calculate LER = 3 sigma of residuals between vertical @ hole center @ top of hole & all other calculated hole centers
                # vector of the center at the top of hole, repeated for each CD calculation
                # vector of the center of the hole at each CD calculation (midpt between x2 and x1)
                # top_ctr_vec = np.array([top_ctr]*len(hole_info[lidx]['center_ind']))
                top_ctr_vec = np.array([top_ctr] * len(this_hole_center_ind))
                # smooth center indices
                # add smoothsizeprofile
                ctr = uniform_filter1d(this_hole_center_ind, size=11)
                LER = 3 * math.sqrt(sum((top_ctr_vec - ctr.flatten()) ** 2))  # test this
                ctr_drift.append(LER)

                # Calculate LER2 - fit line through hole centers & take 3 sigma of residuals w actual hole centers
                model = LinearRegression()
                xx = np.array(range(len(ctr))).reshape(-1, 1)
                model.fit(xx, ctr)
                ctr_fit = model.predict(xx)
                l2norm2 = 3 * math.sqrt(sum((ctr - ctr_fit.flatten()) ** 2))
                ctr_drift_angular.append(l2norm2)

        depths_temp_non_zero = [i for i in depths_temp if i != 0]
        std_of_depths_non_zero = np.std(depths_temp_non_zero)
        mean_of_depths_non_zero = np.mean(depths_temp_non_zero)
        #      print(depths_temp_non_zero)
        #      for i,depth in enumerate(depths_temp):
        #        if depth==0:
        #          depths_temp[i] = mean_of_depths
        std_of_depths = np.std(depths_temp)
        mean_of_depths = np.mean(depths_temp)

        #      print("depths")
        #      print(mean_of_depths, std_of_depths)
        #      print(depths_temp)

        depths = []
        for i, depth in enumerate(depths_temp):
            if abs(depth - mean_of_depths_non_zero) < 1.8 * std_of_depths_non_zero:
                depths.append(depth)
            else:
                depths.append(mean_of_depths)
            depth_lm[i]["Points"][3] = depth_lm[i]["Points"][3] + depths[i]  # +mean_of_depths

        #      print(depth_lm)
        #      print(depths)

        bow_cds = np.array(bow_cds)
        bow_cd_locs = np.array(bow_cd_locs)
        pinch_cds = np.array(pinch_cds)
        pinch_cd_locs = np.array(pinch_cd_locs)

        ctr_drift_dist = np.array(ctr_drift_dist)
        ctr_drift = np.array(ctr_drift)
        ctr_drift_angular = np.array(ctr_drift_angular)
        cd_cont = np.array(cd_cont)

        # add linemarkings data
        linemarkings.append({"Measurement": "Bow CD [nm]", "Linemarkings": bow_lm})
        linemarkings.append({"Measurement": "Pinch CD [nm]", "Linemarkings": pinch_lm})
        linemarkings.append({"Measurement": "Mask Height [nm]", "Linemarkings": mt_lm})
        linemarkings.append({"Measurement": "Depth [nm]", "Linemarkings": depth_lm})
        linemarkings.append({"Measurement": "Top CD [nm]", "Linemarkings": top_cd_lm})
        linemarkings.append({"Measurement": "Bottom CD [nm]", "Linemarkings": bot_cd_lm})

        # calculate the crossover location (from bow to pinch)
        # calculate the area before the crossover and the area after the crossover
        # calculate the cummulative difference between linear fit of CD averages and vector of CD averages
        # calculate the bow extent (ratio of ^diff to area under linear fit)*100

        # make df of all CDs for all holes -- align by top CD, drop the lowest CDs for all

        # shortest_hole = min([len(hi['CD']) for k,hi in hole_info.items()])
        shortest_hole = min([len(cds) for cds in all_CDs])

        CD_df = pd.DataFrame()
        for hidx, cds in enumerate(all_CDs):
            CD_df[hidx] = cds[:shortest_hole]

        # replace 0s with Nan so they will get ignored in averaging
        CD_df = CD_df.replace(0, np.NaN)

        CD_avgs = CD_df.mean(axis=1)
        CD_avgs = uniform_filter1d(CD_avgs.to_numpy(), size=51)

        top5_avg = np.mean(CD_avgs[:5])
        bot5_avg = np.mean(CD_avgs[-5:len(CD_avgs)])

        model = LinearRegression()
        model.fit(np.array([0, len(CD_avgs)]).reshape(-1, 1), np.array([top5_avg, bot5_avg]).reshape(-1, 1))
        yy = model.predict(np.arange(len(CD_avgs)).reshape(-1, 1))

        yy = yy.flatten()

        cumm_diff = sum(abs(yy - CD_avgs))

        # plt.figure()
        # plt.plot(np.arange(len(CD_avgs)), CD_avgs)
        # plt.plot(np.arange(len(CD_avgs)), yy)
        # plt.show()

        # to find crossover point, remove first 10 points and last 10 points, which can intersect with fit line due to fitting,
        # find where the CD_avgs vector intersects (crosses over) the fit straight line, add 10 for the first 10 removed pts
        yy_find = yy[10:-10]
        CD_avgs_find = CD_avgs[10:-10]

        t = 0.07
        index = np.argwhere(abs(yy_find - CD_avgs_find) < t)
        while (index.size == 0) and t < 0.5:  # try increasing thresholds until 0.5, then call it No Crossover
            t += 0.01
            # print(t)
            index = np.argwhere(abs(yy_find - CD_avgs_find) < t)
        # index = index[10:-10]
        # print(t)
        if index.size == 0:
            crossover = len(CD_avgs) - 1
            diff_right = 0
        else:
            # print(index)
            crossover = index.flatten()[0] + 10

            mean_vect_right = CD_avgs[crossover:]
            yy_right = yy[crossover:]

            x2_right = np.arange(len(yy_right))

            auc_right = np.trapz(mean_vect_right, x2_right)
            aul_right = np.trapz(yy_right, x2_right)

            diff_right = auc_right - aul_right

        # print(crossover)
        mean_vect_left = CD_avgs[:crossover]
        yy_left = yy[:crossover]
        x2_left = np.arange(len(yy_left))
        auc_left = np.trapz(mean_vect_left, x2_left)
        aul_left = np.trapz(yy_left, x2_left)
        diff_left = auc_left - aul_left

        AUC = np.trapz(CD_avgs, np.arange(len(CD_avgs)))
        AUL = np.trapz(yy, np.arange(len(yy)))
        diff = AUC - AUL

        #      print("debug")
        #      print(CD_avgs)
        #      print(yy)
        #      print(AUC, AUL)
        #      print(diff)
        #      print(diff/AUL * 100)
        isBow = diff > 0
        bowextent = diff / AUL * 100

        # LINEMARKINGS
        # Bow, Pinch CD for each hole
        # Average Bow location (vertical bar)
        # Average Pinch location (vertical bar)
        # Crossover location (horizontal bar)

        # avg_pinch_loc = np.mean([hole_info[lidx]['PinchLoc'] for lidx in hole_info.keys()])
        # avg_bow_loc = np.mean([hole_info[lidx]['BowLoc'] for lidx in hole_info.keys()])
        avg_pinch_loc = np.mean(pinch_cd_locs)
        avg_bow_loc = np.mean(bow_cd_locs)

        # add linemarkings for avg bow and pinch location, crossover

        linemarkings.append({"Measurement": "Crossover", "Linemarkings": [{
            "Points": [x_offset + mids[0], y_offset + start_search + crossover, x_offset + mids[-1] - 1,
                       y_offset + start_search + crossover],
            "Color": "yellow", "Adjustable": 0, "Annotation": ""}]})

        linemarkings.append({"Measurement": "Pinch CD Location", "Linemarkings": [
            {"Points": [x_offset + 15, y_offset + start_search, x_offset + 15, y_offset + start_search + avg_pinch_loc],
             "Color": "yellow", "Adjustable": 0, "Annotation": ""}]})

        linemarkings.append({"Measurement": "Bow CD Location", "Linemarkings": [
            {"Points": [x_offset + 20, y_offset + start_search, x_offset + 20, y_offset + start_search + avg_bow_loc],
             "Color": "yellow", "Adjustable": 0, "Annotation": ""}]})

        # top & bot CDs
        top_cds = np.array([cd[0] for cd in all_CDs])
        bot_cds = np.array([cd[-1] for cd in all_CDs])

        # print(type(all_CDs))
        all_CDs = np.array([np.array(l) for l in all_CDs])
        bow_cds = np.array(bow_cds)
        bow_cd_locs = np.array(bow_cd_locs)
        pinch_cds = np.array(pinch_cds)
        pinch_cd_locs = np.array(pinch_cd_locs)
        ctr_drift_dist = np.array(ctr_drift_dist)
        ctr_drift = np.array(ctr_drift)
        ctr_drift_angular = np.array(ctr_drift_angular)
        cd_cont = np.array(cd_cont)
        depths = np.array(depths)
        mask_thickness = np.array(mask_thickness)

        # record data collected for holes in measurements
        meas_list = (all_CDs * pixel_size).tolist()
        for i, meas_list_i in enumerate(meas_list):
            meas_list[i] = [round(elem, 5) for elem in meas_list_i]
        msmts.append({"Name": "CD [nm]", "Value": meas_list})
        msmts.append({"Name": "Bow CD [nm]", "Value": (bow_cds * pixel_size).tolist()})
        msmts.append({"Name": "Bow CD Location [nm]", "Value": (bow_cd_locs * pixel_size).tolist()})
        msmts.append({"Name": "Pinch CD [nm]", "Value": (pinch_cds * pixel_size).tolist()})
        msmts.append({"Name": "Pinch CD Location [nm]", "Value": (pinch_cd_locs * pixel_size).tolist()})
        msmts.append({"Name": "Center Drift Horizontal Distance [nm]", "Value": (ctr_drift_dist * pixel_size).tolist()})
        msmts.append({"Name": "Center Drift [nm]", "Value": (ctr_drift * pixel_size).tolist()})
        msmts.append({"Name": "Center Drift (Angular)", "Value": (ctr_drift_angular).tolist()})  # no pix size bc angles
        msmts.append({"Name": "CD Continuity [nm]", "Value": (cd_cont).tolist()})  # no pix size bc measure of residuals
        msmts.append({"Name": "Depth [nm]", "Value": (depths * pixel_size).tolist()})
        msmts.append({"Name": "Mask Height [nm]", "Value": (mask_thickness * pixel_size).tolist()})
        msmts.append({"Name": "Top CD [nm]", "Value": (top_cds * pixel_size).tolist()})
        msmts.append({"Name": "Bottom CD [nm]", "Value": (bot_cds * pixel_size).tolist()})
        #
        # print((bow_cds * pixel_size).tolist())
        # print((bow_cd_locs * pixel_size).tolist())
        # print((pinch_cds * pixel_size).tolist())
        # print((pinch_cd_locs * pixel_size).tolist())

        for i, msmt in enumerate(msmts):
            if msmt["Name"] != "CD [nm]":
                msmts[i]["Value"] = [round(elem, 5) for elem in msmt["Value"]]

        # calculate summary stats
        # print(np.shape(all_CDs))

        means = [np.mean(array) for array in all_CDs]

        summ_stats.append({"Name": "CD [nm]", "Value": np.mean(means), "Summarized_Measurement": "CD"})
        summ_stats.append({"Name": 'Average Bow CD [nm]', "Value": np.mean(bow_cds) * pixel_size,
                           "Summarized_Measurement": "Bow CD"})
        summ_stats.append({"Name": 'Average Bow Location [nm]', "Value": np.mean(bow_cd_locs) * pixel_size,
                           "Summarized_Measurement": "Bow Location"})
        summ_stats.append({"Name": 'Average Pinch CD [nm]', "Value": np.mean(pinch_cds) * pixel_size,
                           "Summarized_Measurement": "Pinch CD"})
        summ_stats.append({"Name": 'Average Pinch Location [nm]', "Value": np.mean(pinch_cd_locs) * pixel_size,
                           "Summarized_Measurement": "Pinch Location"})

        summ_stats.append({"Name": 'Crossover Location [nm]', "Value": crossover * pixel_size,
                           "Summarized_Measurement": "Crossover Location"})

        summ_stats.append({"Name": 'Average CD continuity [nm]', "Value": np.mean(cd_cont) * pixel_size,
                           "Summarized_Measurement": "CD Continuity"})
        summ_stats.append({"Name": "Average Center Drift [nm]", "Value": np.mean(ctr_drift) * pixel_size,
                           "Summarized_Measurement": "Center Drift"})
        summ_stats.append(
            {"Name": "Average Center Drift Horizontal Distance [nm]", "Value": np.mean(ctr_drift_dist) * pixel_size,
             "Summarized_Measurement": "Center Drift Horizontal Distance"})
        summ_stats.append({"Name": 'Average Center Drift Angular', "Value": np.mean(ctr_drift_angular),
                           "Summarized_Measurement": "Center Drift Angular"})
        summ_stats.append({"Name": 'Average Top CD [nm]', "Value": np.mean(top_cds) * pixel_size,
                           "Summarized_Measurement": "Top CD"})
        summ_stats.append({"Name": "Average Bottom CD [nm]", "Value": np.mean(bot_cds) * pixel_size,
                           "Summarized_Measurement": "Bottom CD"})
        summ_stats.append({"Name": 'isBow', "Value": isBow, "Summarized_Measurement": ""})
        summ_stats.append({"Name": 'BowExtent', "Value": bowextent, "Summarized_Measurement": ""})
        summ_stats.append(
            {"Name": 'Area Before Crossover [nm^2]', "Value": diff_left * pixel_size, "Summarized_Measurement": ""})
        summ_stats.append(
            {"Name": 'Area After Crossover [nm^2]', "Value": diff_right * pixel_size, "Summarized_Measurement": ""})
        summ_stats.append(
            {"Name": 'Cumulative Pixels From Linear Fit', "Value": cumm_diff, "Summarized_Measurement": ""})

        if bounding_box:
            summ_stats.append({"Name": 'Average Mask Height [nm]', "Value": np.mean(mask_thickness),
                               "Summarized_Measurement": "Mask Height"})
            summ_stats.append(
                {"Name": 'Average Depth [nm]', "Value": np.mean(depths), "Summarized_Measurement": "Depth"})

        #      print(summ_stats)
        for i, msmt in enumerate(summ_stats):
            if msmt["Name"] != "isBow":
                summ_stats[i]["Value"] = round(msmt["Value"], 5)
        #      print(summ_stats)

        #       # plot on mask
        #       fig = plt.figure(figsize=(15,15))
        #       plt.imshow(img_org, cmap='gray')
        #       for lm in linemarkings:
        # #          print("Displaying", lm['Measurement'])
        #           for lines in lm['Linemarkings']:
        #               x1, y1, x2, y2 = lines["Points"]
        #               plt.plot([x1, x2], [y1, y2], c=lines["Color"], linewidth=2)
        #       plt.show()
        #       plt.savefig("/dat/proj/AIM/Yannis/8_inner.png")

        # import csv

        # with open('/dat/proj/AIM/Yannis/8png_msmts.csv', 'w') as f:
        #     # using csv.writer method from CSV package
        #     write = csv.writer(f)
        #     write.writerow(meas_list)
        #     write.writerow((bow_cds * pixel_size).tolist())
        #     write.writerow((bow_cd_locs * pixel_size).tolist())
        #     write.writerow((pinch_cds * pixel_size).tolist())
        #     write.writerow((pinch_cd_locs * pixel_size).tolist())

        return msmts, summ_stats, linemarkings, (200, "Success.")

    except Exception as e:
        print(e)
        traceback.print_exc()
        return -1, -1, -1, (500, "Error in Full XSEM Measurement case.")

