def measure(img, pixel_size, params):
  msmts = [{"Name":"Test","Value":10}]
  lm = [{"Measurement":"Test","Linemarkings":[{"Points":[50,50,100,100],"Color":"red","adjustable":1,"annotation":"test"}]}]
  ss = [{"Name":"Test","Value":10,"Summarized_Measurement":"Test"}]
  return msmts,ss,lm, (200, "Success.")