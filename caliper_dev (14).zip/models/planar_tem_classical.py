from models.planar_tem_classical_measurement import measure as planar_tem_measurement
import numpy as np
import matplotlib.pyplot as plt
import cv2
from skimage import exposure
from models.planar_tem_classical_refine_edge import main_fine

def fill_holes(img):
    im_floodfill = img.copy()
    h, w = img.shape
    mask = np.zeros((h + 2, w + 2), np.uint8)
    for i in range(min(h,w)):
        if img[i,i]==0:
            cv2.floodFill(im_floodfill, mask, (i, i), 255)
            break
    im_floodfill_inv = cv2.bitwise_not(im_floodfill)
    im_out = img | im_floodfill_inv
    return im_out

def imclearborder(imgBW, radius):
    # Given a black and white image, first find all of its contours
    imgBWcopy = imgBW.copy()
    # print(np.shape(imgBWcopy))
    # imgBWcopy = cv2.cvtColor(imgBWcopy, cv2.COLOR_GRAY2RGB)
    # print(np.shape(imgBWcopy))
    contours,hierarchy = cv2.findContours(imgBWcopy.copy(), cv2.RETR_LIST, cv2.CHAIN_APPROX_SIMPLE)
    # Get dimensions of image
    imgRows = imgBW.shape[0]
    imgCols = imgBW.shape[1]
    contourList = [] # ID list of contours that touch the border
    # For each contour...
    for idx in np.arange(len(contours)):
        # Get the i'th contour
        cnt = contours[idx]
        # Look at each point in the contour
        for pt in cnt:
            rowCnt = pt[0][1]
            colCnt = pt[0][0]
            # If this is within the radius of the border
            # this contour goes bye bye!
            check1 = (rowCnt >= 0 and rowCnt < radius) or (rowCnt >= imgRows-1-radius and rowCnt < imgRows)
            check2 = (colCnt >= 0 and colCnt < radius) or (colCnt >= imgCols-1-radius and colCnt < imgCols)
            if check1 or check2:
                contourList.append(idx)
                break
    for idx in contourList:
        cv2.drawContours(imgBWcopy, contours, idx, (0,0,0), -1)
    return imgBWcopy

def bwareaopen(imgBW, areaPixels):
    # Given a black and white image, first find all of its contours
    imgBWcopy = imgBW.copy()
    contours,hierarchy = cv2.findContours(imgBWcopy.copy(), cv2.RETR_LIST, cv2.CHAIN_APPROX_SIMPLE)
    # For each contour, determine its total occupying area
    for idx in np.arange(len(contours)):
        area = cv2.contourArea(contours[idx])
        if (area >= 0 and area <= areaPixels):
            cv2.drawContours(imgBWcopy, contours, idx, (0,0,0), -1)
    return imgBWcopy

def complete_circles(img):
    contours, hierarchy = cv2.findContours(img, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_NONE)
    hull = []
    for i in range(len(contours)):
        hull.append(cv2.convexHull(contours[i], False))
    for i in range(len(contours)):
        color_contours = (0, 255, 0)  # green - color for contours
        color = (255, 0, 0)  # blue - color for convex hull
        cv2.drawContours(img, hull, i, color, -1)
    return img

def topdown_binarize(img, pixel_size, config, ignore_points):
    """
    Binarize holes as white and background as black from planar TEM image
    :param img: planar TEM image (numpy array)
    :param config: dictionary of configuration parameters
    :return: binary_image (numpy array of 1s and 0s)
    """
    medfil_img_crop = cv2.medianBlur(img, config['configuration_parameters']['MedianfilterSize'])
    p1, p2 = int(config['configuration_parameters']['enhance_min']*255), int(config['configuration_parameters']['enhance_max']*255)
    enhanced_img = exposure.rescale_intensity(medfil_img_crop, in_range=(p1, p2))
#    plt.figure()
#    plt.imshow(enhanced_img, cmap='gray')
#    plt.title("enhanced_img")
#    plt.show()
    binary_img = cv2.threshold(enhanced_img, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)[1]
#    plt.figure()
#    plt.imshow(binary_img, cmap='gray')
#    plt.title("binary_img")
#    plt.show()
    binary_img1 = fill_holes(binary_img)
    binary_img2 = imclearborder(binary_img1,1)
    binary_img3 = bwareaopen(binary_img2, config['configuration_parameters']['MinimumPixels'])
#    plt.figure()
#    plt.imshow(binary_img3, cmap='gray')
#    plt.title("binary_img3")
#    plt.show()
    output = complete_circles(binary_img3)
    output = remove_holes(output, ignore_points)
#    plt.figure()
#    plt.imshow(output, cmap='gray')
#    plt.title("output")
#    plt.show()
    kernel = np.ones((config['configuration_parameters']['smoothing_filter_size'], config['configuration_parameters']['smoothing_filter_size'])) / config['configuration_parameters']['smoothing_filter_size'] ** 2
    output = cv2.filter2D(output, -1, kernel)
#    plt.figure()
#    plt.imshow(output, cmap='gray')
#    plt.title("output")
#    plt.show()
    output = output > config['configuration_parameters']['Rethresh']*255
    output = output.astype(np.uint8)
#    plt.figure()
#    plt.imshow(output, cmap='gray')
#    plt.title("output")
#    plt.show()
    extra_output = {}
    output, extra_output = main_fine(img, output, extra_output, pixel_size, config)
#    plt.figure()
#    plt.imshow(output, cmap='gray')
#    plt.title('Final binarized image')
#    plt.show()
    return output

def remove_holes(img, ignore_points):
    contours, hierarchy = cv2.findContours(img, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_NONE)
#    ignore_points = [ignore_points]
#    print(ignore_points)
    if len(ignore_points[0])!=0:
      for point in ignore_points:
          for idx, contour in enumerate(contours):
              result = cv2.pointPolygonTest(contour, (point[0], point[1]), False)
              if result==1 or result==0:
                  cv2.drawContours(img, contours, idx, (0, 0, 0), -1)
                  break
    return img

def measure(img, pixel_size, params):
    """
    Binarize img
    :param img: grayscale planar TEM topdown image
    :param pixel_size: conversion factor, just pass to measure from draco_topdown_measurements
    :param params: parameters for binarization + bounding box to pass to measure from draco_topdown_measurements
    :return: function call to topdown_measurement will return according to Caliper API: msmst, summ, linemarkings, (errcode, errmsg)
    """
    if "ignore_points" in params:
      ignore_points = params["ignore_points"]
    else:
      ignore_points = []
    img_org = img.copy()
    
    if ('bounding_box' not in params) and ('polygon_bounding_box' not in params):
        return -1, -1, -1, (400, "Missing Bounding Box or Polygon Bounding Box.")
    try:
      x1 = 0
      y1 = 0
      if 'bounding_box' in params:
          cropbox_x1 = params['bounding_box'][0][0]
          cropbox_y1 = params['bounding_box'][0][1]
          x1,y1,x2,y2 = params['bounding_box'][0]
          img = img[y1:y2,x1:x2]
      final_ignore_points = []
      if len(ignore_points)!=0:
        for i, ignore_point in enumerate(ignore_points):
          if 'bounding_box' in params:
            if ignore_point[0] - x1>0 and ignore_point[1] - y1>0 and x2 - ignore_point[0]>0 and y2 - ignore_point[1]>0:
                ign_x = ignore_point[0] - x1
                ign_y = ignore_point[1] - y1
                final_ignore_points.append([ign_x, ign_y])
          else:
            ign_x = ignore_point[0]
            ign_y = ignore_point[1]
            final_ignore_points.append([ign_x, ign_y])
      if len(final_ignore_points)==0:
          final_ignore_points = [[]]
#      print("entered here2")
#      print(final_ignore_points)
      binary_image = topdown_binarize(img, pixel_size, params, final_ignore_points)
#      plt.figure()
#      plt.imshow(binary_image)
#      plt.show()
      if 'polygon_bounding_box' in params:
        contours,hierarchy = cv2.findContours(binary_image, cv2.RETR_LIST, cv2.CHAIN_APPROX_SIMPLE)
        # polygon bounding box: keep original image uncropped and later exclude holes from binarization which are outside bounds
        cropbox_x1 = 0
        cropbox_y1 = 0
        # create a mask of the polygon
        # do an & with the input image to get rid of all holes outside the mask
        xs = params['polygon_bounding_box'][::2]
        ys = params['polygon_bounding_box'][1::2]
        polypoints = np.array((ys,xs)).T
        mask = np.zeros(binary_image.shape[:2], dtype='uint8')  # black image the shape of original image
        # add white polygon to make mask
        cv2.drawContours(mask, [polypoints], 0, 255, -1)
        cv2.drawContours(mask, [polypoints], 0, 255, 2)
        # keep only segmented holes under polygon mask (mask is white and original img was white)
        binary_image = binary_image & mask      
#        plt.figure()
#        plt.imshow(binary_image)
#        plt.show()
        #take out contours that intersect
        for cntr in contours:
          for point in cntr:
            if binary_image[point[0][1]][point[0][0]]==0:
              cv2.drawContours(binary_image, [cntr], -1, color=(0, 0, 0), thickness=cv2.FILLED)
              break
#        plt.figure()
#        plt.imshow(binary_image)
#        plt.show()
        
      # Add functionality for edge intersects
      msmts, summ_stats, linemarkings, err = planar_tem_measurement(binary_image, pixel_size, params, cropbox_x1, cropbox_y1, final_ignore_points)
    except Exception as e:
#        print("There was an error: " + e.args[0] + ". The line where the code failed was " + str(traceback.extract_stack()[-1][1]))
        print("Error")
        print(e)
        traceback.print_exc()
        return -1, -1, -1, (500, "Measurement failed.")


    if err[0]==200:
      plt.figure()
      plt.imshow(img_org, cmap='gray')
      for lm in linemarkings:
         print("Displaying", lm['Measurement'])
         for lines in lm['Linemarkings']:
             x1,y1,x2,y2 = lines["Points"]
             plt.plot([x1,x2], [y1,y2], c = lines["Color"])

    return msmts, summ_stats, linemarkings, err
