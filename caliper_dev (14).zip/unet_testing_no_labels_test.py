## coding: utf-8
#
#""" 
#  Receives an image, performs ML inferencing and generates measurements, line markings, and 
#  summary statistics
#
#  Inputs 
#  -------------------
#  1. algo_id: LIMS DB algo_id received from UI for selected image
#  2. job_id: job_id from LIMS DB corresponding to the selected algo_id for an image
#  3. demo_id: LIMS DB demo_id received from UI for selected image
#  4. image: Name of image received from UI
#  5. imageObject: Image file object with which image needs to be pulled from LIMS DB
#  6. inputs: Dictionary of paramters obtained from configurable parameters on UI
#             {"inputs":{"bounding_box":[[0,0],[0,0]],
#                        "pixel_size":{},
#                        "measure":True/False}}
#  7. uuid: recevied from UI
#
#  Output
#  -------------------
#  final_result: Dataframe containing the following details:
#    1. UUID: Unique ID for every image to be measured
#    2. original_filepath: Input image NAS path
#    3. patch_flag: Indicated model used (1: Topdown, 0: XSEM)
#    4. y_pred: binary output image from the ML model
#    5. last_update_tsmp: 
#    6. measurements_file: Pickle file with line marking, measurements, and summary statistics
#"""
#
#__author__ = ["Divya Shankar","Srither Ranjan", "Samuel Joshua"]
#__version__ = 1.0

# Standard Library
import sys
import os
import datetime
import base64
import json
from nasapi import nasapi
import warnings
import requests
import re
import time
        
# Third Party Library
import uuid
import pickle
import tensorflow as tf
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from tensorflow.keras.metrics import Recall, Precision
import cv2
from tensorflow.keras.models import model_from_json
from sklearn.metrics import roc_curve
from sklearn.metrics import roc_auc_score
from sklearn.metrics import confusion_matrix
from sklearn.metrics import precision_recall_curve
from sklearn.metrics import f1_score
import skimage.transform

sys.path.append('/usr/local/lib/python3.6/dist-packages/IPython/extensions')
%load_ext autoreload
%autoreload
%matplotlib inline

# Application Specific Library
from utils import JobStatus, ImageProcessor
from config import time_zone, base_path, LOG, master_expected_input_keys, source_path_dev, source_measurements_path_dev
from config import lims_db_qa, lims_db_prod
from config import model_nasapi_path
from config import fxsem_imgs_nas_path,topdown_imgs_nas_path, y_pred_cdsw_path,y_pred_imgs_nasapi_path
from postprocessing import post_process_main
from models_beta import measure
from utils import Connector

#PROD CONFIG PATHS
#from config import time_zone, base_path, LOG, master_expected_input_keys, source_path_prd , source_measurements_path_prd
#from config import lims_db_prod
#from config import model_nasapi_path
#from config import fxsem_imgs_nas_path,topdown_imgs_nas_path, y_pred_cdsw_path,y_pred_imgs_nasapi_path

ns = nasapi.NasApi('development')
#ns = nasapi.NasApi('deployment')


def get_model_name(algo_id, demo_id):
  test_connection = None
  try:
    test_connection = Connector.create_connection()
    
    algo_record = pd.read_sql(f"SELECT algo_name, model_name, config_params FROM caliper.algo WHERE algo_id = {algo_id}",test_connection)
    algo_dct = algo_record.to_dict('r')[0]
    model_name = algo_dct['model_name']
    algo_name = algo_dct['algo_name']
    config_param = algo_dct['config_params']
    
    if model_name == 'None':
      df_demo = pd.read_sql(f"SELECT * FROM caliper.demo WHERE demo_id = '{demo_id}' AND algo_id = {algo_id}",test_connection)
      if df_demo.shape[0] == 0:
        LOG.info("No record found for given Demo ID + Algo ID in Demo Table")
        #timestamp = datetime.now(PST).strftime('%Y-%m-%d %H:%M:%S')
        timestamp = datetime.datetime.now(time_zone).strftime('%Y-%m-%d %H:%M:%S')
        temp_dict = {'demo_id': demo_id, 'algo_id': int(algo_id), 'model_id': None, 'updated_by':'cdswb','last_update_tsmp':timestamp}
        temp_dataframe = pd.DataFrame([temp_dict])
        
        engine = Connector.get_engine()
        temp_dataframe.to_sql('demo',con=engine,schema='caliper',if_exists='append',index=False)
        LOG.info("New record for Demo ID + Algo ID inserted into Demo table")
      else:
        LOG.info("Found record for given Demo ID + Algo ID")
    else:
      LOG.info("Deep Learning Model Used") 
        
    return model_name, algo_name, config_param
    
  except Exception as e:
    LOG.error(e)

  finally:
    if test_connection:
      test_connection.close()

      
def get_patch_flag(model_id,algo_id):
  test_connection = None
  try:
    test_connection = Connector.create_connection()
    
    model_demo = pd.read_sql(f"SELECT * FROM caliper.model WHERE model_id = {model_id}",test_connection)
    model_dct = model_demo.to_dict('r')[0]
    
    algo_demo = pd.read_sql(f"SELECT * FROM caliper.algo WHERE algo_id = {algo_id}",test_connection)
    algo_dct = algo_demo.to_dict('r')[0]
    
    return model_dct, algo_dct
    
  except Exception as e:
    LOG.error(e)

  finally:
    if test_connection:
      test_connection.close()
      

def get_patch_flag_model_id(algo_id, demo_id):
  test_connection = None
  try:
    test_connection = Connector.create_connection()        
    df_demo = pd.read_sql(f"SELECT * FROM caliper.demo WHERE demo_id = '{demo_id}' AND algo_id = {algo_id}",test_connection)
    if df_demo.shape[0] == 0:
        LOG.info("No record found for given Demo ID + Algo ID in Demo Table")
        LOG.info("Insert new record into Demo Table")
        
        get_modelNameInfo = pd.read_sql(f"SELECT model_name FROM caliper.algo WHERE algo_id = {algo_id}",test_connection)
        modelNameInfo = get_modelNameInfo.to_dict('r')[0]
        modelname = modelNameInfo['model_name']  
        
        get_latest_model = pd.read_sql("SELECT model_id FROM caliper.model WHERE name = '" + modelname + "'" + "order by model.update_tsmp desc limit 1", test_connection)
        getModelId = get_latest_model.to_dict('r')[0]
        model_id = getModelId['model_id']
        
        temp_dict = {'demo_id': demo_id, 'algo_id': int(algo_id), 'model_id': model_id}
        temp_dataframe = pd.DataFrame([temp_dict])
      
        engine = Connector.get_engine()
        temp_dataframe.to_sql('demo',con=engine,schema='caliper',if_exists='append',index=False)
        LOG.info("New record for Demo ID + Algo ID with latest Model ID inserted into Demo table")
        
        LOG.info("Get associated Model Information, Algorithm Information")
        model_table_record, algo_table_record = get_patch_flag(model_id, algo_id)
      
    else:
        LOG.info("Found record for given Demo ID + Algo ID")
        print(df_demo.iloc[0],"----------------------")
        demo_id, algo_id, model_id,updated_by,last_update_tsmp = df_demo.iloc[0]
        print(df_demo.iloc[0],"----------------------")
        
        LOG.info("Get associated Model Information, Algorithm Information") 
        model_table_record, algo_table_record = get_patch_flag(model_id, algo_id) 
    
    return model_id,model_table_record, algo_table_record
  
  except Exception as e:
    return {"error":"get patch flag model method error","error_msg":str(e)}
    LOG.error(e)

  finally:
    if test_connection:
      test_connection.close()
      
class NumpyEncoder(json.JSONEncoder):
    """
    Note: Converting all the numpy data types to python object type (numpy arrat to python list)
    """
    def default(self, obj):
        if isinstance(obj, np.integer):
            return int(obj)
        elif isinstance(obj, np.floating):
            return float(obj)
        elif isinstance(obj, np.ndarray):
            return obj.tolist()
        elif isinstance(obj, np.bool_):
            return bool(obj)
        elif np.isnan(obj):
            return "null"
        return json.JSONEncoder.default(self, obj)
      
def job_run_status_update(uuid,msg,msgerror):
    """
    Insert or update the status to job run table
    """
    test_connection = None
    try:
      
        test_connection = Connector.create_connection() 
        engine = Connector.get_engine()
        cursor = test_connection.cursor()
        db_uuid = pd.read_sql(f"SELECT uuid FROM caliper.job_run",test_connection)
        db_uuid_list=list(db_uuid['uuid'])
        print(uuid,"uuid")
        
        if uuid in db_uuid_list:
            if msgerror==None:
              print("uuid already present",uuid)
              sql = f"UPDATE caliper.job_run set status = '{msg}',error=null where uuid = '{uuid}'"
            else:
              sql = f"UPDATE caliper.job_run set status = '{msg}',error='{msgerror}' where uuid = '{uuid}'"
        else:    
            print("generated uuid",uuid)
            sql = f"INSERT INTO caliper.job_run (uuid,status) VALUES ('{uuid}','{msg}')"
        print("sql",sql)
        cursor.execute(sql)
        LOG.info("job_run table status updated successfully")
        test_connection.commit()
   
    except Exception as e:
        return {"error":"job_run status update method","error_msg":str(e)}
        LOG.error(e)
    finally:
        if test_connection:
            test_connection.close()
      
def insert_update_job_run(result_dict):
    """
    Insert or update the record to job run table based on uuid
    """
    test_connection = None
    try:
        test_connection = Connector.create_connection()   
        engine = Connector.get_engine()
        cursor = test_connection.cursor()
        print("inside insert")
        measure_json = json.dumps(result_dict["var_measurements"],cls=NumpyEncoder) 
        bounding_box = json.dumps(result_dict["var_bounding_box"],default=str)
        pixel_size = json.dumps(result_dict["var_pixel_size"],default=str)        
        uuid = result_dict['var_uuid']
        print(uuid,"--------------------------------uuid")
        
        db_uuid_id = pd.read_sql(f"SELECT uuid FROM caliper.job_run",test_connection)
        db_uuid_id=list(db_uuid_id['uuid'])
        if uuid in db_uuid_id:
            print("inside if",bounding_box)
            
            if result_dict["var_image_id"]==None:
              result_dict["var_image_id"] = "null"
            #print("result_from_db",result_from_db) 
            """  if uuid exists update or insert """
            sql = f"UPDATE caliper.job_run set job_id = '{result_dict['var_job_id']}', demo_id = '{result_dict['var_demo_id']}',image_filename = '{result_dict['var_image_filename']}',image_id = {result_dict['var_image_id'] }, algo_id = {result_dict['var_algo_id']},binary_op = '{result_dict['var_binary_op']}',rotation_angle = {result_dict['var_rotation_angle']},bounding_box = '{bounding_box}',pixel_size = '{pixel_size}',output_binary_values= '{result_dict['var_output_binary_values']}',config = '{result_dict['var_config']}',start_ts = '{result_dict['var_start_ts']}',end_ts = '{result_dict['var_end_ts']}',error = '{result_dict['var_error']}',sample_id ='{result_dict['var_sample_id']}',measurements_file= '{result_dict['var_measurements_file']}',status= '{result_dict['var_status']}',measurements = '{measure_json}' where uuid = '{uuid}'"
          
            cursor.execute(sql)
            print(True)
           
            LOG.info("updated")
        
        else:
            if result_dict["var_image_id"]==None:
              result_dict["var_image_id"] = "null"
            sql = f"INSERT INTO caliper.job_run (uuid,job_id,demo_id,image_filename,image_id,algo_id,binary_op,rotation_angle,bounding_box,pixel_size,output_binary_values,config,start_ts, end_ts,error,sample_id, measurements_file,status,measurements) VALUES ('{result_dict['var_uuid']}','{result_dict['var_job_id']}','{result_dict['var_demo_id']}','{result_dict['var_image_filename']}',{result_dict['var_image_id']},{result_dict['var_algo_id']},'{result_dict['var_binary_op']}',{result_dict['var_rotation_angle']},'{bounding_box}','{pixel_size}','{result_dict['var_output_binary_values']}','{result_dict['var_config']}','{result_dict['var_start_ts']}','{result_dict['var_end_ts']}','{result_dict['var_error']}','{result_dict['var_sample_id']}','{result_dict['var_measurements_file']}',null,'{measure_json}')"
            LOG.info("inserted")
            cursor.execute(sql)
       
        test_connection.commit()
        LOG.info("done")
        if test_connection:
            test_connection.close()
    except:
        if test_connection:
            test_connection.close()
        message = job_run_status_update(uuid_id,"error in dtype","postgres db not updated")
        return {"error":"insert job run table method error","error_msg":str(e)}
        
            
def getting_matched_uuid(job_id,demo_id,img_name):
    """
    Get the uuid value based on job_id,demo_id and image_filename
    
    Note: 
         1)request having image_id:
         If job_id,demo_id and image_filename is already exists oin job_run table return the same record uuid
         else return a empty string
         
         2)request having image_object:
         If image_filename is already exists in job_run table return the same record uuid
         else return a empty string
    """
    test_connection = None
    try:
      
        test_connection = Connector.create_connection() 
        engine = Connector.get_engine()
        cursor = test_connection.cursor()
        db_uuid = pd.read_sql(f"SELECT job_id,demo_id,image_filename FROM caliper.job_run",test_connection)
        db_job_id_list = list(db_uuid['job_id'])
        db_demo_id_list = list(db_uuid['demo_id'])
        db_image_name_list = list(db_uuid['image_filename'])
        if (job_id in db_job_id_list) & (demo_id in db_demo_id_list) & (img_name in db_image_name_list):
            uuid_record = pd.read_sql(f"SELECT uuid from caliper.job_run where job_id = '{job_id}' and demo_id = '{demo_id}' and image_filename = '{img_name}'",test_connection)
            if uuid_record.shape[0]!=0:
                uuid = uuid_record.to_dict('r')[0]
                uuid = uuid["uuid"] 
                return uuid
            else:
                return ""
        elif img_name in db_image_name_list:
          uuid_record = pd.read_sql(f"SELECT uuid from caliper.job_run where image_filename = '{img_name}'",test_connection)
          if uuid_record.shape[0]!=0:
              uuid = uuid_record.to_dict('r')[0]
              uuid = uuid["uuid"] 
              return uuid
          else:
              return ""
            
        else:
            return ""
          
    except Exception as e:
        raise e
        
    finally:
        if test_connection:
            test_connection.close()
          
def measure_image(args):
    """
    Measure images using either Topdown or FXSEM model:
    1. Input parameters: encoded image, image name, and patch flag
    2. Checks patch_flag, and accordingly retrieve the image from the correct path, call the appropriate model
    3. patch_flag = 1, call topdown model
    4. patch_flag = 0, call FXSEM model
    """
    final_result = dict() 
    
    job = JobStatus(None, 0)
    print(job)
    LOG.info("Job Started")
    start_time = datetime.datetime.now(time_zone)
    
    de_uuid = str(uuid.uuid4())
    
    if isinstance(args,dict) == True:
      actual_input_keys = set(args.keys())
      if len(actual_input_keys) == len(master_expected_input_keys):
        LOG.info("Input is proper")

        algo_id = args.get('algo_id')
        
        job_id = args.get('job_id')
        job_id = job_id.strip()
        
        demo_id = args.get('demo_id')
        
        img_id = args.get('image') # getting image id
      
        
        img_name = args.get('image_name')
        img_name = img_name.strip()
        db_img_name = img_name
        
        enc_image = args.get('imageObject')
        print("enc_image",type(enc_image))
        
        params_input = args.get('inputs') 
        
        user_id = args.get('user_id')
        
        uuid_id = args.get('uuid')
        
        x_limstoken =  args.get('x_limstoken')
        
        config_param = params_input["config_param"]
#        print(config_param)
        
        rotate = params_input["rotate"]
        
        pixel_size = params_input["pixel_size"]
                            

      elif len(actual_input_keys) >= len(master_expected_input_keys):
        missing_keys = actual_input_keys.difference(master_expected_input_keys)
        job.update_status(-1,"Extra Keys in input")
        LOG.info("Missing keys in master: ", missing_keys)
        return {"status":"error","message":f"Extra Keys {missing_keys}" }
        
      else:
        missing_keys = master_expected_input_keys.difference(actual_input_keys)
        job.update_status(-1,"Keys missing in input")
        LOG.info("Missing keys in input: ", missing_keys)
        return {"status":"error", "message":f"Missing Keys {missing_keys}" }
        
    else:
      LOG.info("Invalid input type")
      job.update_status(-1,"Invalid Input Type")
      return {"status":"error","message":"Invalid input type"}
    #------------------------------------------  
    try:
    
      key=""
      bounding_box_param = params_input["bounding_box"]
      point_bounding_box = list()
      epoint_bounding_box = list()
      bounding_box_value = list()  
      bounding_box_keys=list()
      if "rectangle" not in bounding_box_param.keys():
        bounding_box_param["rectangle"]=[]
      if len(bounding_box_param["rectangle"])!=0:
        key = "rectangle"
        bounding_box_keys.append(key)
      else:
        bounding_box_value = [0,0,0,0]
    
      if len(bounding_box_param["line"])!=0:
        key = "line"
        bounding_box_keys.append(key)
      if "point" not in bounding_box_param.keys():
        bounding_box_param["point"]=[]
      if len(bounding_box_param["point"])!=0:
        key = "point"
        bounding_box_keys.append(key)
      else:
        point_bounding_box=[]
      if "exclude-point" not in bounding_box_param.keys():
        bounding_box_param["exclude-point"]=[]
      if len(bounding_box_param["exclude-point"])!=0:
        key = "exclude-point"
        bounding_box_keys.append(key)
      else:
        epoint_bounding_box=[]

      if len(bounding_box_param["polygon"])!=0:
        key = "polygon"
        bounding_box_keys.append(key)
      print(bounding_box_keys)
      
      if len(bounding_box_keys)!=0:
        for key in bounding_box_keys:
          if key=="rectangle":
            bounding_box_value.append(int(bounding_box_param[key][0]["x1"]))
            bounding_box_value.append(int(bounding_box_param[key][0]["y1"]))
            bounding_box_value.append(int(bounding_box_param[key][0]["x2"]))
            bounding_box_value.append(int(bounding_box_param[key][0]["y2"]))
            print(bounding_box_value,"bounding_box_value")
          if key=='point':
            point_bounding_box.append(int(bounding_box_param[key][0]['x']))
            point_bounding_box.append(int(bounding_box_param[key][0]['y']))
            print(point_bounding_box," point bounding_box_value")
          if key=='exclude-point':
            epoint_bounding_box.append(int(bounding_box_param[key][0]['x']))
            epoint_bounding_box.append(int(bounding_box_param[key][0]['y']))
            print(epoint_bounding_box,"epoint bounding_box_value") 
           
    except:
      print("invalid bounding box request")
      message = job_run_status_update(uuid_id,"error","invalid bounding box request")
      return {"error":"invalid bounding box request"}
    
    if img_id == None:
          img_id == "null"
    if uuid_id=="":
      uuid_id = getting_matched_uuid(job_id,demo_id,img_name)
      if uuid_id =="":
        de_uuid = str(uuid.uuid4())
        uuid_id = de_uuid
        
    try:
      print("inside try-----")
      if "planar_tem" in config_param.keys():
        if (config_param["planar_tem"] == 'True') or (config_param["planar_tem"] == 'true') or (config_param["planar_tem"] == True):
          config_param["planar_tem"] = True
        else:
          config_param["planar_tem"] = False
      else:
        print("Configuration Parameters",config_param)
      
      if "globalbinarize" in config_param.keys():
        if (config_param["globalbinarize"] == 'True') or (config_param["globalbinarize"] == 'true') or (config_param["globalbinarize"] == True):
          config_param["globalbinarize"] = True
        else:
          config_param["globalbinarize"] = False
      else:
        print("Configuration Parameters",config_param)
      
      params = {}
      params["configuration_parameters"] = config_param
      params["bounding_box"] = bounding_box_value
      params["ignore_points"] = epoint_bounding_box
      params["reference_point"] = [point_bounding_box]
      print(params,"params--------------------------------")
      
      pixelsize = pixel_size['pixelSize']
      print("-----Pixel Size------",pixelsize)
    except Exception as e:
      print("invalid config param")
      message = job_run_status_update(uuid_id,"error","invalid config parameters or invalid params in request")
      return {"error":"invalid config param"}
    #Update the job_run table status field
    message = job_run_status_update(uuid_id,"in progress",None)
    
    #-------------------- Check if model name is None/Topdown/FXSEM ----------------
    sub_model_name, msmt_type, config_params = get_model_name(algo_id, demo_id)
    print("sub_model_name", sub_model_name)
    print("Measurement Algorithm Name: ", msmt_type)
    print("Measurement Algorithm config_params: ", config_params,type(config_params))
    print("config_param",type(config_param))
   
  
    if len(config_param.keys())==0:
      config_param = config_params
      print(config_param)
    
    
    #----- If model name = Topdown/FXSEM: extract latest model version, patch flag details and call DL models -----
    
    if sub_model_name != 'None':
      LOG.info("Extracting measurement algorithm name, model filename, patch_flag for given Demo ID + Algo ID")
      model_id, model_dct, algo_dct = get_patch_flag_model_id(algo_id,demo_id)
      if 1==1:
        msmt_type = algo_dct["algo_name"]
        print("Measurement Algorithm Name: ", msmt_type,type(algo_dct))
        print("Measurement Algorithm config_params: ", algo_dct['config_params'])
        print("algo_dict_record",algo_dct)
        print(config_param,type(config_param))

        if len(config_param.keys())==0:
          config_param = algo_dct["config_params"]
          print(config_param)

        file_name_h5 = model_dct["file_name"]
        print("Model Filename: ",file_name_h5)

        file_name_json = model_dct["json_file_name"]
        print("Model Architecture Filename: ",file_name_json)

        patch_flag = model_dct["patch_flag"]
        print("Patch Flag: ",patch_flag)
      else:
        message = job_run_status_update(uuid_id,"error","invalid config param request")
        return {"error":"invalid config param"}

      if patch_flag==1:
        LOG.info("Topdown")
        pre_process_time = time.time()
        if img_id != None:
            LOG.info("Getting Image from LIMS...")

            lims_prod_url = lims_db_prod+str(img_id)
            lims_qa_url = lims_db_qa+str(img_id)

            payload={}

            bearer_token = 'Bearer ' + x_limstoken # using x-LimsToken from request args
            headers = {'Authorization': bearer_token}

            lims_prod_response = requests.request("GET", lims_prod_url, headers=headers, data=payload)
            lims_qa_response = requests.request("GET", lims_qa_url, headers=headers, data=payload)

            if lims_prod_response.status_code == 200:
              print("Image is from LIMS PROD")
              image_path = '/home/cdsw/imgs/' + 'topdown/' + img_name
              with open(image_path, "wb+") as f:
                f.write(lims_prod_response.content)
              print("data read to image file successfully")
            elif lims_qa_response.status_code == 200:
              print("Image is from LIMS PROD")
              image_path = '/home/cdsw/imgs/' + 'topdown/' + img_name
              with open(image_path, "wb+") as f:
                f.write(lims_qa_response.content)
              print("data read to image file successfully")
            else:
                print("inside else")
                LOG.error({"error":"get image id api"})
                print({"error":"get image id api error","message":"image id or x_limstoken not valid"})
                return {"status":"error","error":"get image id api error","message":"image id or x_limstoken not valid"}

        else:
          print("Local Upload Image")

          """Since image_name is a filepath, splitting and creating name"""
          tmp_imgname, tmp_imgext = os.path.splitext(img_name)
          temp_img_name = re.sub(r'[^a-zA-Z0-9-. ]','_',tmp_imgname)
          temp_image_name = temp_img_name  + tmp_imgext
          img_name = temp_image_name
          print(temp_image_name)

          image_path = '/home/cdsw/imgs/' + 'fxsem/' + temp_image_name
          print("image_path:",image_path)

          try:
            LOG.info("Fetching image from NAS")
            fetch_data = ns.fetch_data(input_images_nasapi_path,[img_name])

            for filename, filecontent in fetch_data.items():
              with open(image_path,"wb") as f:
                f.write(filecontent.getbuffer())
                f.close()
              LOG.info("Fetched and loaded: %s",filename)

            LOG.info("Successfully fetched image")

          except Exception as e:
            LOG.info("Failed fetching image from NAS")
            LOG.error(e)
      

        #Rotate the original image before pushing into NAS
        if rotate != 0:
          rotate = -1 * rotate
          img_to_rotate = cv2.imread(image_path,0)
          img_rotated = skimage.transform.rotate(img_to_rotate,rotate,resize=True,mode='constant',preserve_range=True)
          cv2.imwrite(image_path, img_rotated.astype(np.uint8))
        else:
          print("Rotation Angle 0, no rotation required")

        i_temp = cv2.imread(image_path,0)
        print("Size of i_temp",np.shape(i_temp))
        original_image_shape = np.shape(i_temp)
#        print("----------------Time to download/read,rotate image----------------: ",time.time()-pre_process_time)
        nas_image_path = topdown_imgs_nas_path
        #nas push image
        start1 = time.time()
        psh_data = ns.push_data([img_name],nas_image_path,'imgs/' + 'topdown/')
#        print("----------------Time taken to push input image to secure NAS api:------------ ",time.time()-start1)
        nas_image_path = nas_image_path + img_name
        print("nas_image_path-------------------",nas_image_path)
        # TO-DO: pass file_name_json in ImageProcessor.measure_topwdown_imgs()
        deep_learning_time = time.time()
        measure_topdown_output = ImageProcessor.measure_topwdown_imgs(nas_image_path,patch_flag,file_name_h5,file_name_json)
  #      print(measure_topdown_output,"measure_topdown_output")
#        print("------------Time taken for Inference:------------- ",time.time()-deep_learning_time)
        print("length",len(measure_topdown_output))
        print("Topdown Deep Learning Model status",measure_topdown_output[2])
        if measure_topdown_output[2]["status"]=="success":
          x = measure_topdown_output[0]
          y_pred = measure_topdown_output[1]
          y_pred_ls = y_pred.tolist()
          LOG.info("topdown model inference generated")    
          result_error = "No"
          result_status = "success"
        else:
          LOG.info("Error in Deep Learning Algorithm")
          job_run_status_update(str(uuid_id),"error","Error in Deep Learning Algorithm")
  #        return {"status":"error", "message":measure_topdown_output[2]["error_msg"]}
          result_error = "error in deep learning algorithm"   
          result_status = "error"
          x=[]
          y_pred = []
      else:
        pre_process = time.time()
        print("fxsem")
        print("img_id",img_id)
        if img_id != None:

            lims_prod_url = lims_db_prod+str(img_id)
            lims_qa_url = lims_db_qa+str(img_id)         
            payload={}

            bearer_token = 'Bearer ' + x_limstoken # using x-LimsToken from request args
            headers = {'Authorization': bearer_token}      
            lims_prod_response = requests.request("GET", lims_prod_url, headers=headers, data=payload)
            lims_qa_response = requests.request("GET", lims_qa_url, headers=headers, data=payload)
            if lims_prod_response.status_code == 200:
                print("Image is from LIMS PROD")
                image_path = '/home/cdsw/imgs/' + 'fxsem/' + img_name
                print("img_path",image_path)
                with open(image_path, "wb+") as f:
                    f.write(lims_prod_response.content)
                print("data read to image file successfully")
            elif lims_qa_response.status_code == 200:
                print("Image is from LIMS PROD")
                image_path = '/home/cdsw/imgs/' + 'fxsem/' + img_name
                print("img_path",image_path)
                with open(image_path, "wb+") as f:
                    f.write(lims_qa_response.content)
                print("data read to image file successfully")
            else:
                print("inside else")
                LOG.error({"error":"get image id api"})
                print({"error":"get image id api error","message":"image id or x_limstoken not valid"})
                return ({"status":"error","error":"get image id api error","message":"image id or x_limstoken not valid"})

        else: 
          print("Local Upload Image")

          """Since image_name is a filepath, splitting and creating name"""
          tmp_imgname, tmp_imgext = os.path.splitext(img_name)
          temp_img_name = re.sub(r'[^a-zA-Z0-9-. ]','_',tmp_imgname)
          temp_image_name = temp_img_name  + tmp_imgext
          img_name = temp_image_name
          print(temp_image_name)

          image_path = '/home/cdsw/imgs/' + 'fxsem/' + temp_image_name
          print("image_path:",image_path)

          try:
            LOG.info("Fetching image from NAS")
            fetch_data = ns.fetch_data(input_images_nasapi_path,[img_name])

            for filename, filecontent in fetch_data.items():
              with open(image_path,"wb") as f:
                f.write(filecontent.getbuffer())
                f.close()
              LOG.info("Fetched and loaded: %s",filename)

            LOG.info("Successfully fetched image")

          except Exception as e:
            LOG.info("Failed fetching image from NAS")
            LOG.error(e)
            

        #Rotate the original image before pushing into NAS
        if rotate != 0:
          rotate = -1 * rotate
          img_to_rotate = cv2.imread(image_path,0)
          img_rotated = skimage.transform.rotate(img_to_rotate,rotate,resize=True,mode='constant',preserve_range=True)
          cv2.imwrite(image_path, img_rotated.astype(np.uint8))
        else:
          print("Rotation Angle 0, no rotation required")

        i_temp = cv2.imread(image_path,0)
        print("Size of i_temp",np.shape(i_temp))
        original_image_shape = np.shape(i_temp)
        nas_image_path = fxsem_imgs_nas_path
        #nas push image
        start2 = time.time()
        psh_data = ns.push_data([img_name],nas_image_path,'imgs/' + 'fxsem/')
#        print("--------------Time taken to push input image to NAS:----------- ",time.time()-start2)

        nas_image_path = nas_image_path + img_name
        print("nas_image_path-------------------",nas_image_path)
#        print("--------------pre process time ----------",time.time()-pre_process)
        deep_learn = time.time()
        measure_fxsem_output = ImageProcessor.measure_fxsem_imgs(nas_image_path,patch_flag,file_name_h5,file_name_json)
        print("length",len(measure_fxsem_output))
        print("XSEM Deep Learning Model status",measure_fxsem_output[2])
        if measure_fxsem_output[2]["status"]=="success":
          x = measure_fxsem_output[0]
          y_pred = measure_fxsem_output[1]
          y_pred_ls = y_pred.tolist()
        else:
          LOG.info("Error in Deep Learning Algorithm")
          job_run_status_update(str(uuid_id),"error","Error in Deep Learning Algorithm")
  #        return {"status":"error", "message":measure_fxsem_output[2]["error_msg"]}
          result_error = "error in deep learning algorithm"   
          result_status = "error"
          x=[]
          y_pred = []
#        print("-------------deep_learn----------",time.time()-deep_learn)
        
    else:
      print("Classical Image Processing!")
      pre_process_time = time.time()
      if img_id != None:

          lims_prod_url = lims_db_prod+str(img_id)
          lims_qa_url = lims_db_qa+str(img_id)         
          payload={}

          bearer_token = 'Bearer ' + x_limstoken # using x-LimsToken from request args
          headers = {'Authorization': bearer_token}      
          lims_prod_response = requests.request("GET", lims_prod_url, headers=headers, data=payload)
          lims_qa_response = requests.request("GET", lims_qa_url, headers=headers, data=payload)

          if lims_prod_response.status_code == 200:
              print("Image is from LIMS PROD")
              image_path = '/home/cdsw/imgs/' + 'cip/' + img_name
              print("img_path",image_path)
              with open(image_path, "wb+") as f:
                  f.write(lims_prod_response.content)
              print("data read to image file successfully")
          elif lims_qa_response.status_code == 200:
              print("Image is from LIMS PROD")
              image_path = '/home/cdsw/imgs/' + 'cip/' + img_name
              print("img_path",image_path)
              with open(image_path, "wb+") as f:
                  f.write(lims_qa_response.content)
              print("data read to image file successfully")
          else:
              print("inside else")
              LOG.error({"error":"get image id api"})
              print({"error":"get image id api error","message":"image id or x_limstoken not valid"})
              return ({"status":"error","error":"get image id api error","message":"image id or x_limstoken not valid"})

      else:
        print("Local Upload Image")

        """Since image_name is a filepath, splitting and creating name"""
        tmp_imgname, tmp_imgext = os.path.splitext(img_name)
        temp_img_name = re.sub(r'[^a-zA-Z0-9-. ]','_',tmp_imgname)
        temp_image_name = temp_img_name  + tmp_imgext
        img_name = temp_image_name
        print(temp_image_name)

        image_path = '/home/cdsw/imgs/' + 'fxsem/' + temp_image_name
        print("image_path:",image_path)

        try:
          LOG.info("Fetching image from NAS")
          fetch_data = ns.fetch_data(input_images_nasapi_path,[img_name])

          for filename, filecontent in fetch_data.items():
            with open(image_path,"wb") as f:
              f.write(filecontent.getbuffer())
              f.close()
            LOG.info("Fetched and loaded: %s",filename)

          LOG.info("Successfully fetched image")

        except Exception as e:
          LOG.info("Failed fetching image from NAS")
          LOG.error(e)
          

      #Rotate the original image before pushing into NAS
      if rotate != 0:
        rotate = -1 * rotate
        img_to_rotate = cv2.imread(image_path,0)
        img_rotated = skimage.transform.rotate(img_to_rotate,rotate,resize=True,mode='constant',preserve_range=True)
        cv2.imwrite(image_path, img_rotated.astype(np.uint8))
      else:
        print("Rotation Angle 0, no rotation required")

#      print("----------------Time to download/read, rotate:--------------- ",time.time()-pre_process_time)
      x=[0]
      y_pred=[0]
      y_pred_ls = []
      
#      nas_image_path = fxsem_imgs_nas_path
#      #nas push image
#      start5 = time.time()
#      psh_data = ns.push_data([img_name],nas_image_path,'imgs/' + 'cip/')
#      print("Time taken to push input image to NAS: ",time.time()-start5)
         
         
    try:       
        print("insidetry------------------------------------------------")
        print(len(x),len(y_pred),"length of x and ypred")
        if len(x)!=0 or len(y_pred)!=0:
            #if ("topdown" in msmt_type.casefold()) or ("xsem" in msmt_type.casefold()):
            if sub_model_name!='None':
              print("Output of Deep learning")
              y_pred = skimage.transform.resize(y_pred,original_image_shape)
  #            y_pred = y_pred[:,:,0]
  #            y_pred = skimage.transform.resize(y_pred,(x.shape[0],x.shape[1]))
              print("y_pred Shape: ",np.shape(y_pred))

              print("Saving y_pred: ")
              y_pred_temp = y_pred * 255

              temp_image_name = 'y_pred_'+img_name
              print(temp_image_name)
              y_pred_img_name = temp_image_name
              #NAS Path where image to be store
              y_pred_img_path = y_pred_cdsw_path + y_pred_img_name
              print("y_pred_img cdsw path: ",y_pred_img_path)
              y_pred_write_status = cv2.imwrite(y_pred_img_path, y_pred_temp)
              print("y_pred Saved", y_pred_write_status)
              # Push from /home/cdsw/y_pred_imgs to nas drive 
              start3 = time.time()
              psh_data = ns.push_data([y_pred_img_name],y_pred_imgs_nasapi_path,y_pred_cdsw_path)
#              print("-----------Time taken to push y_pred image to NAS:------------- ",time.time()-start3)
              original_img = cv2.imread(image_path)
            else:
              print("Classical Image Processing Case")
              original_img = cv2.imread(image_path)
              print("Shape of Original Image",np.shape(original_img))
              
            try:  
              print("in try")
              original_img = cv2.cvtColor(original_img, cv2.COLOR_BGR2GRAY)
              print("Shape of Original Image",np.shape(original_img))
              
            except Exception as e:
              print("except:",str(e))
            
            print(type(params),"typeparams--------------------------------")
            print(image_path,"image_path----")
            
            """ 
              Run the post-processing code for Topdown/FXSEM images
                Input to Postprocessing code: Original image,y_pred,msmt_type,pixel_size, params
                Output of Postprocessing code: img_processed, error_msg, extra_output
            """   
            
            #if ("topdown" in msmt_type.casefold()) or ("xsem" in msmt_type.casefold()):
            if sub_model_name!='None':
              post_process = time.time()
              img_processed, error_msg, extra_output = post_process_main(original_img,y_pred,msmt_type,pixelsize, params)
              print("errormsg",error_msg,"Post processing Status")
              print("error_status_code",error_msg[0])
#              print("---------------Time taken for Post Processing: -------------",time.time()-post_process)
              """Saving Post Processed Image into NAS"""
              temp_image_name = 'img_post_processed_'+img_name
              print(temp_image_name)

              post_processed_img_name = temp_image_name
              #NAS Path where image to be store
              post_processed_img_path = y_pred_cdsw_path + post_processed_img_name
              print("post_processed_img_name cdsw path: ",post_processed_img_path)
              post_processed_write_status = cv2.imwrite(post_processed_img_path, img_processed)
              print("post_processed_img_name Saved", post_processed_write_status)
              # Push from /home/cdsw/y_pred_imgs to nas drive
              post_process_nas = time.time()
              psh_data = ns.push_data([post_processed_img_name],y_pred_imgs_nasapi_path,y_pred_cdsw_path)
#              print("--------------Time taken to push post processed image----------------: ",time.time()-post_process_nas)
            else:
              LOG.info("Classical Image Processing - Skip Post process")
              img_processed = original_img
              error_msg = (200,'Success')
        
            if error_msg[0] == 200:
              """ 
              Run the measurement algorithm and store Line Markings, Measurements, Summary Statistics in a pickle file
              """
              algo_time = time.time()
              if sub_model_name != 'None':
              #if ("topdown" in msmt_type.casefold()) or ("xsem" in msmt_type.casefold()):
                print("Topdown/FXSEM Image")
                return_params = measure(img_processed,msmt_type,pixelsize,{"bounding_box":bounding_box_value})
#                print("------------algo_time --------------",time.time()-algo_time)
              else:
                print("Classical Image--------------")
#                print(params)
                return_params = measure(img_processed,msmt_type,pixelsize,params)
#                print(return_params)
               
#                print("------------algo_time --------------",time.time()-algo_time)
              
              print("length of return param",len(return_params))
              print("status",return_params[3])

              if return_params[3][0] == 200:
                measurements_summary_dict={"Measurements":return_params[0],
                                            "Summary Statistics":return_params[1],
                                            "Line Markings":return_params[2]
                                          }
                result_error = str(return_params[3][1]) # by the way the success message is return by all the algo.py so we can use success directly
                result_status = "success"
              else:
                measurements_summary_dict = {"Measurements":-1,"Line Markings":-1,"Summary Statistics":-1}
                result_error = str(return_params[3][1]) # draco topdown.py file returning (500,"measure failed") only. Here we cant see exact algo name and exact error message so better we can use like above line
                result_status = "error"
                
            else:
                measurements_summary_dict = {"Measurements":-1,"Line Markings":-1,"Summary Statistics":-1}
                result_error = error_msg[1] #error_msg from post_process
                result_status = "error"
            
            # Optimise
            pickle_filename = "measurements/" + uuid_id+"_measurments.pkl"
            file_to_write = open(pickle_filename,"wb+")
            pickle.dump(measurements_summary_dict, file_to_write)
            file_to_write.close()
            
#            psh_data = ns.push_data([pickle_filename], source_measurements_path_dev, '/home/cdsw/')
#            
##            psh_data = ns.push_data([pickle_filename], source_measurements_path_prd, '/home/cdsw/')
#            # Check if measurement pickle file is pushed to NAS and then delete
#            psh_status_data = psh_data[1]
#            measurements_pickle_push_status = list(psh_status_data.values())[0]
#            if measurements_pickle_push_status == 'Success':
#              LOG.info("Measurements Pickle file pushed to NAS path successfully")
#              os.remove(pickle_filename)
#            else:
#              result_error = "Error pushing measurements pickle to NAS"
#              result_status = "error"
            
            end_time = datetime.datetime.now(time_zone)
            table_time = time.time()
            job.update_status(2)
            result_dict= dict()
#            print(result_status)
            
            result_dict['var_uuid'] = str(uuid_id)
            result_dict["var_job_id"]= str(job_id)         
            result_dict["var_demo_id"]=str(demo_id)
            result_dict["var_image_filename"]=db_img_name
            result_dict["var_image_id"] = img_id
            result_dict["var_algo_id"] =  int(algo_id)
            result_dict["var_binary_op"]="0"
            result_dict["var_rotation_angle"] = params_input["rotate"]
            result_dict["var_bounding_box"] = params_input["bounding_box"]
            result_dict["var_pixel_size"] = params_input["pixel_size"]
            result_dict["var_output_binary_values"] = str(y_pred_ls)
            result_dict["var_config"] = json.dumps(config_param,cls=NumpyEncoder)
#            print(result_dict["var_config"])
          
            result_dict["var_start_ts"] = str(start_time)
            result_dict["var_end_ts"] = str(end_time)
            
            
            result_dict["var_error"] = result_error
            result_dict["var_sample_id"] = "0"
            result_dict["var_measurements_file"] = pickle_filename
            result_dict["var_status"] = result_status
           
            if measurements_summary_dict['Summary Statistics']!=-1:
              di1=measurements_summary_dict['Summary Statistics']
              df = pd.DataFrame.from_dict(di1)
              df=df.fillna('null')
              df=df.to_dict('r')
              measurements_summary_dict['Summary Statistics']=df
              di1=measurements_summary_dict['Line Markings']
              df = pd.DataFrame.from_dict(di1)
              df=df.fillna('null')
              df=df.to_dict('r')
              measurements_summary_dict['Line Markings'] =  df
              
           
            result_dict["var_measurements"] = measurements_summary_dict
          
            print("insert working")
            
            sample = insert_update_job_run(result_dict) 
            print(sample)
            print("--------------table time ----------------",time.time()-table_time)
            #job_run_status_update(str(uuid_id),"complete")
            return {"status":"success","uuid":str(uuid_id)}

        else:
            LOG.info("condition failed")
            end_time = datetime.datetime.now(time_zone)
            result_dict= dict()
            result_dict['var_uuid'] = str(uuid_id)
            result_dict["var_job_id"]= str(job_id)
            result_dict["var_demo_id"]=str(demo_id)
            result_dict["var_image_filename"]=db_img_name
            result_dict["var_image_id"] = img_id
            result_dict["var_algo_id"] =  int(algo_id)
            result_dict["var_algo_id"] =  int(algo_id)
            result_dict["var_binary_op"]="0"
            result_dict["var_rotation_angle"] = params_input["rotate"]
            result_dict["var_bounding_box"] = params_input["bounding_box"]
            result_dict["var_pixel_size"] = params_input["pixel_size"]
            result_dict["var_output_binary_values"] = str([])
            
            result_dict["var_config"] = json.dumps(config_param,default='str')
            result_dict["var_start_ts"] = str(start_time)
            result_dict["var_end_ts"] = str(end_time)
            result_dict["var_error"] = result_error
            result_dict["var_sample_id"] = "0"
            result_dict["var_measurements_file"] = "error"
            result_dict["var_status"] = result_status
            result_dict["var_measurements"] = {"Measurements":-1,"Line Markings":-1,"Summary Statistics":-1}
            print("else part insert working")
            insert_update_job_run(result_dict)
            
            return {"status":"error","uuid":str(uuid_id),"message":str(result_error)}
    except:  
        
        #job.update_status(-1, str(e))
        message = job_run_status_update(uuid_id,"error","algorithm error")

#input_images_nasapi_path = '/var/lib/cdsw/calipalgdev/input_imgs/classical/'
input_images_nasapi_path = '/var/lib/cdsw/calipalgdev/input_imgs/Full_XSEM_CIP_Test/'
#input_images_nasapi_path = '/var/lib/cdsw/calipalgdev/input_imgs/raw_tem/'

if __name__ == "__main__":
  
### PLEASE ADD A NEW PRINT MEASURE IMAGE COMMAND LINE IF YOU WANT TO TEST BUT KEEP THE EXISTING ONES###

#  print(measure_image(    {
#        "algo_id": 6,
#        "job_id": "",
#        "demo_id": "",
#        "image": None,
#        "image_name": "G415-4-1 Ceta 43.0 kx Ceta.TIF",
#		    "imageObject": "",
#        "x_limstoken":"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJodHRwOi8vc2NoZW1hcy54bWxzb2FwLm9yZy93cy8yMDA1LzA1L2lkZW50aXR5L2NsYWltcy9uYW1lIjoiQU1BVFxceDAxMjM5NDMiLCJqdGkiOiJkYTUyNmZiNy1jNTkyLTRlMjUtOTVkOC1iNTdkYjRhNmVlNjIiLCJleHAiOjE2NDM3OTQ2MTB9.tNtFcaGf_6H3zlVn-elUysPd9oGzvi-K_wGdoHKOXAA",
#        "inputs": {
#            "bounding_box": {
#                "rectangle": [
#                  {
#                    "x1": 99,
#                    "y1": 979,
#                    "x2": 1681,
#                    "y2": 256,
#                  }
#                ],
#                "line": [],
#                "point": [],
#                "exclude-point": [],
#                "polygon": []
#            },
#            "pixel_size": {
#                "x1": 459.25, 
#                "x2": 1377.75, 
#                "y1": 918.5, 
#                "y2": 918.5, 
#                "length": "50", 
#                "units": "nm", 
#                "pixelSize": 0.05443658138268917
#            },
#            "rotate": 0,
#            "config_param": {
#                            "globalbinarize": True
#        }
#        },
#        "user_id": "user_id",
#        "uuid": "de849be4-0093-4ff4-940e-0441093b5516",
#        "measured": False
#    }))

#  print(measure_image({
#        "algo_id": 8,
#        "job_id": "",
#        "demo_id": "",
#        "image": None,
#        "image_name": "R57-TOPCeta88_0kxCeta - Copy.png",
#		    "imageObject": "",
#        "x_limstoken":"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJodHRwOi8vc2NoZW1hcy54bWxzb2FwLm9yZy93cy8yMDA1LzA1L2lkZW50aXR5L2NsYWltcy9uYW1lIjoiQU1BVFxceDAxMjM5NDMiLCJqdGkiOiJlOTgxNzFiYy1iZGQxLTQzNGQtYmQyOS03ZWU3NzVmZmQ0MGQiLCJleHAiOjE2NDQzODg1NDV9.rnYbX6VmZ9OlRwfrGFh5PZhkoFOzDHyKxM2REgp5Vmk",
#        "inputs": {
#            "bounding_box": {
#                "rectangle": [
#                  {
#                    "x1": 0,
#                    "x2": 1257,
#                    "y1": 0,
#     ccccccuencdnklvvtfjjgkkbvchlkckjtvdukhrtcldt
ccccccuencdnicvggfcdbhlddcitkcgkcjtrfluhunlr
"y2": 1041
#                  }
#                ],
#                "line": [],
#                "point": [],
#                "exclude-point": [{"x":84,"y":198}],
#                "polygon": []
#            },
#            "pixel_size": {
#				        "x1": 180.25,
#                "x2": 540.75,
#                "y1": 276.5,
#                "y2": 276.5,
#                "length": "1",
#                "units": "nm",
#                "pixelSize": 0.5291666
#            },
#            "rotate": 0,
#            "config_param": {
#               'MedianfilterSize': 21,
#               'enhance_min': 0.05,
#               'enhance_max': 0.6,
#               'smoothing_filter_size': 51,
#               'Rethresh': 0.45,
#               'MaximumPixels': 500,
#               "radius_division_ratio" : 2.5,
#               "linear_approximation_factor" : 0.1,
#               "radius_to_measure" : "interior"
#            }
#        },
#        "user_id": "user_id",
#        "uuid": "8859381b-5392-429c-9491-9fb4753a9c06",
#        "measured": False
#    }))
  
# print(measure_image({
#        "algo_id": 7,
#        "job_id": "",
#        "demo_id": "",
#        "image": None,
#        "image_name": "F157-2.TIF",
#        "imageObject": "",
#        "x_limstoken":"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJodHRwOi8vc2NoZW1hcy54bWxzb2FwLm9yZy93cy8yMDA1LzA1L2lkZW50aXR5L2NsYWltcy9uYW1lIjoiQU1BVFxceDAxMjM5NDMiLCJqdGkiOiJjNTYxMTg1OS03ZjA4LTQ2MjAtOTZmZS1lNmM4YjI4MTc1ZGYiLCJleHAiOjE2NDI3NDg4NDN9.7GKdY77WI2lAOR6r7ThaTYcZ2t6SMzeSdX1UHUAebW0",
#        "inputs": {
#            "bounding_box": {
#                "rectangle": [
#                  {
#                    "x1": 67,
#                    "y1": 97,
#                    "x2": 688,
#                    "y2": 473
#                  }
#                ],
#                "line": [],
#                "point": [{"x":148,"y":161}],
#                "exclude-point": [],
#                "polygon": []
#            },
#            "pixel_size": {
#                "x1": 497,
#                "x2": 780,
#                "y1": 561,
#                "y2": 561,
#                "length": 300,
#                "units": "nm",
#                "pixelSize": 0.5291005291005291
#            },
#            "rotate": 0,
#            "config_param": {
#              "linear_approximation_factor": 0.15,
#              "threshold_signal_to_mean_ratio":0.2,
#              "diffuse_filter":True, 
#              "smoothing_window_length_for_CDs":10,
#              "median_filter_size":[9,3],
#              "rectangular_kernel_filter_size":[15,5],
#              "bottom_binarization_threshold":0.1,
#              "holes_below_selected_box": True
#            }
#        },
#        "user_id": "user_id",
#        "uuid": "",
#        "measured": False
#    }))
      
#  print(measure_image({
#        "algo_id": 7,
#        "job_id": "",
#        "demo_id": "",
#        "image": None,
#        "image_name": "F191-4.TIF",
#        "imageObject": "",
#        "x_limstoken":"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJodHRwOi8vc2NoZW1hcy54bWxzb2FwLm9yZy93cy8yMDA1LzA1L2lkZW50aXR5L2NsYWltcy9uYW1lIjoiQU1BVFxceDAxMjM5NDMiLCJqdGkiOiJjNTYxMTg1OS03ZjA4LTQ2MjAtOTZmZS1lNmM4YjI4MTc1ZGYiLCJleHAiOjE2NDI3NDg4NDN9.7GKdY77WI2lAOR6r7ThaTYcZ2t6SMzeSdX1UHUAebW0",
#        "inputs": {
#            "bounding_box": {
#                "rectangle": [
#                  {
#                    "x1": 90,
#                    "y1": 123,
#                    "x2": 702,
#                    "y2": 505
#                  }
#                ],
#                "line": [],
#                "point": [{"x":210,"y":270}],
#                "exclude-point": [],
#                "polygon": []
#            },
#            "pixel_size": {
#                "x1": 497,
#                "x2": 780,
#                "y1": 561,
#                "y2": 561,
#                "length": 300,
#                "units": "nm",
#                "pixelSize": 0.5291005291005291
#            },
#            "rotate": 0,
#            "config_param": {
#              "linear_approximation_factor_for_CDs": 0.15,
#              "threshold_signal_to_mean_ratio":0.2,
#              "diffuse_filter":True, 
#              "smoothing_window_length_for_CDs":10,
#              "median_filter_size":[9,3],
#              "rectangular_kernel_filter_size":[15,5],
#              "bottom_binarization_threshold":0.3,
#              "holes_below_selected_box": True
#            }
#        },
#        "user_id": "user_id",
#        "uuid": "",
#        "measured": False
#    }))

    print(measure_image({
        "algo_id": 7,
        "job_id": "",
        "demo_id": "",
        "image": None,
        "image_name": "19.png",
        "imageObject": "",
        "x_limstoken":"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJodHRwOi8vc2NoZW1hcy54bWxzb2FwLm9yZy93cy8yMDA1LzA1L2lkZW50aXR5L2NsYWltcy9uYW1lIjoiQU1BVFxceDAxMjM5NDMiLCJqdGkiOiJjNTYxMTg1OS03ZjA4LTQ2MjAtOTZmZS1lNmM4YjI4MTc1ZGYiLCJleHAiOjE2NDI3NDg4NDN9.7GKdY77WI2lAOR6r7ThaTYcZ2t6SMzeSdX1UHUAebW0",
        "inputs": {
            "bounding_box": {
                "rectangle": [
                  {
                    "x1": 91,
                    "y1": 58,
                    "x2": 695,
                    "y2": 393
                  }
                ],
                "line": [],
                "point": [{"x":181,"y":119}],
                "exclude-point": [],
                "polygon": []
            },
            "pixel_size": {
                "x1": 497,
                "x2": 780,
                "y1": 561,
                "y2": 561,
                "length": 300,
                "units": "nm",
                "pixelSize": 0.5291005291005291
            },
            "rotate": 0,
            "config_param": {
              "linear_approximation_factor_for_CDs": 0.15,
              "threshold_signal_to_mean_ratio":0.2,
              "diffuse_filter":True, 
              "smoothing_window_length_for_CDs":10,
              "median_filter_size":[9,3],
              "rectangular_kernel_filter_size":[15,5],
              "bottom_binarization_threshold":0.3,
              "holes_below_selected_box": True
            }
        },
        "user_id": "user_id",
        "uuid": "",
        "measured": False
    }))
